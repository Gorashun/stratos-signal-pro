import React, { useState } from 'react';
import { useStratOS } from '../components/stratos/useStratOS';
import TopBar from '../components/stratos/TopBar';
import Sidebar from '../components/stratos/Sidebar';
import DashboardPage from '../components/stratos/DashboardPage';
import SignalsPage from '../components/stratos/SignalsPage';
import StrategyPage from '../components/stratos/StrategyPage';
import UniversePage from '../components/stratos/UniversePage';
import WatchlistPage from '../components/stratos/WatchlistPage';
import LogsPage from '../components/stratos/LogsPage';
import SettingsPage from '../components/stratos/SettingsPage';

import PortfolioPage from '../components/stratos/PortfolioPage.jsx';
import PortfolioSuggestionPage from '../components/stratos/PortfolioSuggestionPage.jsx';

export default function StratOS() {
  const [activePage, setActivePage] = useState('dashboard');
  const {
    marketData, signals, regime, strategy, setStrategy,
    activeMarkets, toggleMarket, fetching, fetchProgress,
    fetchData, generateSignals, runCycle, logs, log,
  } = useStratOS();

  const [logsState, setLogsState] = useState([]);
  const allLogs = [...logs, ...logsState];

  const marketDataCount = Object.keys(marketData).length;

  const renderPage = () => {
    switch (activePage) {
      case 'dashboard':
        return <DashboardPage marketData={marketData} signals={signals} regime={regime} strategy={strategy} fetchData={fetchData} />;
      case 'signals':
        return <SignalsPage signals={signals} onRunSignals={generateSignals} onFetchData={fetchData} marketDataCount={marketDataCount} marketData={marketData} regime={regime} />;
      case 'portfolio':
        return <PortfolioPage marketData={marketData} signals={signals} />;
      case 'portfolio_suggestion':
        return <PortfolioSuggestionPage strategy={strategy} />;
      case 'strategy':
        return <StrategyPage strategy={strategy} onStrategyChange={setStrategy} log={log} signals={signals} />;
      case 'universe':
        return <UniversePage activeMarkets={activeMarkets} marketData={marketData} />;
      case 'watchlist':
        return <WatchlistPage activeMarkets={activeMarkets} marketData={marketData} signals={signals} regime={regime} />;
      case 'logs':
        return <LogsPage logs={logs} onClear={() => {}} />;
      case 'settings':
        return <SettingsPage activeMarkets={activeMarkets} onToggleMarket={toggleMarket} />;
      default:
        return <DashboardPage marketData={marketData} signals={signals} regime={regime} strategy={strategy} />;
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: '#080c10',
      color: '#dce8f5',
      fontFamily: "'DM Sans', sans-serif",
      position: 'relative',
    }}>
      {/* Grid background */}
      <div style={{
        position: 'fixed', inset: 0, zIndex: 0, pointerEvents: 'none',
        backgroundImage: 'linear-gradient(rgba(62,207,255,0.025) 1px, transparent 1px), linear-gradient(90deg, rgba(62,207,255,0.025) 1px, transparent 1px)',
        backgroundSize: '32px 32px',
      }} />

      <div style={{ position: 'relative', zIndex: 1 }}>
        <TopBar
          regime={regime}
          fetching={fetching}
          fetchProgress={fetchProgress}
          onRunCycle={runCycle}
          onFetchData={fetchData}
          onGenerateSignals={generateSignals}
        />

        <div style={{ display: 'flex', minHeight: 'calc(100vh - 54px)' }}>
          <Sidebar
            activePage={activePage}
            onNavigate={setActivePage}
            signals={signals}
            marketDataCount={marketDataCount}
          />
          <main style={{ flex: 1, overflowY: 'auto' }}>
            {renderPage()}
          </main>
        </div>
      </div>

      

      <style>{`
        * { box-sizing: border-box; }
        select option { background: #131b24; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: #080c10; }
        ::-webkit-scrollbar-thumb { background: #253649; border-radius: 2px; }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}