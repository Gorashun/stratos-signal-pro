import React, { useState } from 'react';
import { useAuth } from '../lib/AuthContext';

export default function LoginPage() {
  const { signIn, signUp } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mode, setMode] = useState('login'); // 'login' | 'signup'
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handle = async () => {
    if (!email || !password) return;
    setLoading(true);
    setError('');
    setSuccess('');
    try {
      const fn = mode === 'login' ? signIn : signUp;
      const { error } = await fn(email, password);
      if (error) throw error;
      if (mode === 'signup') setSuccess('Konto skapat! Kontrollera din e-post för att bekräfta.');
    } catch (e) {
      setError(e.message || 'Något gick fel');
    }
    setLoading(false);
  };

  return (
    <div style={{
      minHeight: '100vh', background: '#080c10', display: 'flex',
      alignItems: 'center', justifyContent: 'center',
      fontFamily: "'DM Sans', sans-serif", color: '#dce8f5',
    }}>
      {/* Grid bg */}
      <div style={{
        position: 'fixed', inset: 0, pointerEvents: 'none',
        backgroundImage: 'linear-gradient(rgba(62,207,255,0.025) 1px, transparent 1px), linear-gradient(90deg, rgba(62,207,255,0.025) 1px, transparent 1px)',
        backgroundSize: '32px 32px',
      }} />

      <div style={{ position: 'relative', zIndex: 1, width: '100%', maxWidth: 380, padding: 24 }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 40 }}>
          <div style={{ fontSize: 36, fontWeight: 800, letterSpacing: '-1px' }}>
            Strat<span style={{ color: '#3ecfff' }}>OS</span>
          </div>
          <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', marginTop: 6 }}>
            // Signal Intelligence Platform
          </div>
        </div>

        {/* Card */}
        <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 12, padding: 28 }}>
          <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 20 }}>
            {mode === 'login' ? 'Logga in' : 'Skapa konto'}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <input
              type="email"
              placeholder="E-postadress"
              value={email}
              onChange={e => setEmail(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handle()}
              style={{
                padding: '10px 14px', background: '#131b24',
                border: '1px solid #253649', borderRadius: 7,
                color: '#dce8f5', fontSize: 13, outline: 'none',
                fontFamily: 'inherit',
              }}
            />
            <input
              type="password"
              placeholder="Lösenord"
              value={password}
              onChange={e => setPassword(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handle()}
              style={{
                padding: '10px 14px', background: '#131b24',
                border: '1px solid #253649', borderRadius: 7,
                color: '#dce8f5', fontSize: 13, outline: 'none',
                fontFamily: 'inherit',
              }}
            />

            {error && (
              <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#e74c3c', padding: '8px 12px', background: 'rgba(231,76,60,0.1)', borderRadius: 6, border: '1px solid rgba(231,76,60,0.2)' }}>
                {error}
              </div>
            )}
            {success && (
              <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#2ecc71', padding: '8px 12px', background: 'rgba(46,204,113,0.1)', borderRadius: 6, border: '1px solid rgba(46,204,113,0.2)' }}>
                {success}
              </div>
            )}

            <button
              onClick={handle}
              disabled={loading}
              style={{
                background: '#3ecfff', color: '#080c10', border: 'none',
                borderRadius: 7, padding: '11px', fontWeight: 700,
                fontSize: 13, cursor: loading ? 'not-allowed' : 'pointer',
                opacity: loading ? 0.7 : 1, marginTop: 4,
                fontFamily: 'inherit',
              }}
            >
              {loading ? '…' : mode === 'login' ? 'Logga in' : 'Skapa konto'}
            </button>
          </div>

          <div style={{ marginTop: 18, textAlign: 'center', fontFamily: 'monospace', fontSize: 11, color: '#5a7a94' }}>
            {mode === 'login' ? 'Inget konto? ' : 'Har redan konto? '}
            <button
              onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setError(''); setSuccess(''); }}
              style={{ color: '#3ecfff', background: 'transparent', border: 'none', cursor: 'pointer', fontSize: 11, fontFamily: 'monospace' }}
            >
              {mode === 'login' ? 'Registrera dig' : 'Logga in'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
