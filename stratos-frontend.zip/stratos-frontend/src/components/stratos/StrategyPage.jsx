import React, { useState } from 'react';
import { invokeFunction } from '@/api/supabaseClient';
import { defRules } from './signalEngine';
import BacktestResults from './BacktestResults';

export default function StrategyPage({ strategy, onStrategyChange, log, signals = [] }) {
  const [timeframe, setTimeframe]     = useState('swing');
  const [direction, setDirection]     = useState('long_only');
  const [focus, setFocus]             = useState('all');
  const [riskProfile, setRiskProfile] = useState('balanced');
  const [generating, setGenerating]   = useState(false);
  const [status, setStatus]           = useState('');
  const [backtesting, setBacktesting] = useState(false);
  const [backtestResult, setBacktestResult] = useState(null);

  const rules = strategy?.rules || defRules();

  const generate = async () => {
    setGenerating(true);
    setStatus('Genererar via AI…');
    try {
      const res = await invokeFunction('generate-strategy', { timeframe, direction, focus, riskProfile });
      const strat = res?.strategy;
      if (strat?.name) {
        onStrategyChange({ name: strat.name, rules: strat });
        setStatus(`✓ ${strat.name}`);
        log?.('INFO', `AI-strategi: "${strat.name}"`);
      } else {
        throw new Error('Ingen strategi returnerades');
      }
    } catch (e) {
      loadDefault();
      setStatus('⚠ AI ej tillgänglig — standard laddad');
      log?.('WARN', 'AI strategi: ' + e.message);
    }
    setGenerating(false);
  };

  const loadDefault = () => {
    const r = defRules();
    onStrategyChange({ name: r.name, rules: r });
    setStatus('✓ Standard laddad');
    log?.('INFO', 'Standardstrategi laddad');
  };

  const runBacktest = async () => {
    setBacktesting(true);
    setBacktestResult(null);
    setStatus('Backtesting…');
    try {
      const tickers = signals
        .filter(s => s.status === 'APPROVED' && s.ticker)
        .slice(0, 12)
        .map(s => ({ ticker: s.ticker, market: s.market }));

      const res = await invokeFunction('backtest', {
        strategy: rules,
        tickers: tickers.length ? tickers : [{ ticker: 'ERIC-B', market: 'sweden' }, { ticker: 'VOLV-B', market: 'sweden' }],
        range: '2y',
      });
      setBacktestResult(res);
      setStatus(`✓ Backtest klart — ${res.total_trades} affärer`);
      log?.('INFO', `Backtest: ${res.total_trades} affärer, win rate ${(res.win_rate * 100).toFixed(0)}%`);
    } catch (e) {
      setStatus('⚠ Backtest misslyckades: ' + e.message);
    }
    setBacktesting(false);
  };

  const Sel = ({ label, value, onChange, opts }) => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
      <div style={{ fontFamily: 'monospace', fontSize: 10, color: '#5a7a94', letterSpacing: 1 }}>{label.toUpperCase()}</div>
      <select value={value} onChange={e => onChange(e.target.value)} style={{ background: '#131b24', border: '1px solid #253649', color: '#dce8f5', padding: '7px 10px', borderRadius: 6, fontSize: 12, outline: 'none' }}>
        {opts.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </select>
    </div>
  );

  return (
    <div style={{ padding: 24, fontFamily: "'DM Sans', sans-serif" }}>
      <div style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>Strategi</div>
      <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', marginBottom: 24 }}>
        {strategy?.name ? `Aktiv: ${strategy.name}` : 'Ingen strategi laddad'}
      </div>

      {/* Generator */}
      <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, padding: 20, marginBottom: 18 }}>
        <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 16 }}>AI-generator</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 18 }}>
          <Sel label="Tidshorisont" value={timeframe} onChange={setTimeframe} opts={[['day','Daghandel'],['swing','Swing (2-10d)'],['position','Position (veckor)']]} />
          <Sel label="Riktning" value={direction} onChange={setDirection} opts={[['long_only','Köp (Long)'],['short_only','Blankning'],['both','Båda']]} />
          <Sel label="Fokus" value={focus} onChange={setFocus} opts={[['momentum','Momentum'],['mean_reversion','Mean Reversion'],['breakout','Utbrott'],['all','Blandad']]} />
          <Sel label="Riskprofil" value={riskProfile} onChange={setRiskProfile} opts={[['conservative','Försiktig 0.3%'],['balanced','Balanserad 0.5%'],['aggressive','Aggressiv 1%']]} />
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <button onClick={generate} disabled={generating}
            style={{ background: '#3ecfff', color: '#080c10', border: 'none', borderRadius: 7, padding: '8px 18px', fontWeight: 700, fontSize: 12, cursor: generating ? 'not-allowed' : 'pointer', opacity: generating ? 0.7 : 1 }}>
            {generating ? '⟳ Genererar…' : '✦ Generera strategi'}
          </button>
          <button onClick={loadDefault}
            style={{ background: 'transparent', border: '1px solid #253649', color: '#dce8f5', borderRadius: 7, padding: '8px 18px', fontWeight: 700, fontSize: 12, cursor: 'pointer' }}>
            Standard
          </button>
          {status && <span style={{ fontFamily: 'monospace', fontSize: 11, color: status.startsWith('✓') ? '#2ecc71' : '#f1c40f' }}>{status}</span>}
        </div>
      </div>

      {/* Current rules */}
      {strategy && (
        <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, padding: 20, marginBottom: 18 }}>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 14 }}>{strategy.name}</div>
          {strategy.rules?.description && (
            <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', marginBottom: 14 }}>{strategy.rules.description}</div>
          )}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
            {[
              { label: 'Risk/affär', value: `${((strategy.rules?.position_sizing?.risk_per_trade || 0.005) * 100).toFixed(1)}%` },
              { label: 'Max positioner', value: strategy.rules?.position_sizing?.max_positions || 10 },
              { label: 'Max sektor', value: `${((strategy.rules?.position_sizing?.max_sector_exposure || 0.25) * 100).toFixed(0)}%` },
              { label: 'Stop', value: `${strategy.rules?.exits?.[0]?.atr_mult || 2.5}× ATR` },
              { label: 'Take Profit', value: `${strategy.rules?.exits?.[1]?.atr_mult || 3.5}× ATR` },
              { label: 'Max drawdown', value: `${((strategy.rules?.risk?.max_drawdown || 0.12) * 100).toFixed(0)}%` },
            ].map(({ label, value }) => (
              <div key={label} style={{ background: '#131b24', borderRadius: 6, padding: '10px 14px' }}>
                <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94', letterSpacing: 1, marginBottom: 4 }}>{label.toUpperCase()}</div>
                <div style={{ fontFamily: 'monospace', fontSize: 14, fontWeight: 700, color: '#3ecfff' }}>{value}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Backtest */}
      <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, padding: 20 }}>
        <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 12 }}>Backtest</div>
        <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', marginBottom: 14 }}>
          Testar strategin på historisk data (2 år) för aktiva signaler
        </div>
        <button onClick={runBacktest} disabled={backtesting}
          style={{ background: 'transparent', border: '1px solid #9b59b6', color: '#9b59b6', borderRadius: 7, padding: '8px 18px', fontWeight: 700, fontSize: 12, cursor: backtesting ? 'not-allowed' : 'pointer', opacity: backtesting ? 0.5 : 1 }}>
          {backtesting ? '⟳ Kör backtest…' : '◉ Kör backtest'}
        </button>
        {backtestResult && <BacktestResults result={backtestResult} />}
      </div>
    </div>
  );
}
