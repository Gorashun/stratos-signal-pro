import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts';

function MetricCard({ label, value, subtitle, color }) {
  return (
    <div style={{
      background: '#131b24', border: '1px solid #1e2d3d',
      borderRadius: 8, padding: '12px 14px', textAlign: 'center',
    }}>
      <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 6 }}>
        {label}
      </div>
      <div style={{ fontFamily: 'monospace', fontSize: 19, fontWeight: 700, color: color || '#dce8f5' }}>
        {value}
      </div>
      {subtitle && (
        <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94', marginTop: 4 }}>{subtitle}</div>
      )}
    </div>
  );
}

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: '#0d1219', border: '1px solid #253649', borderRadius: 7,
      padding: '10px 14px', fontFamily: 'monospace', fontSize: 11,
    }}>
      <div style={{ color: '#5a7a94', marginBottom: 6 }}>{label}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ color: p.color, marginBottom: 2 }}>
          {p.name}: <strong>{p.value?.toFixed(1)}</strong>
        </div>
      ))}
      {payload.length === 2 && (
        <div style={{ color: payload[0].value > payload[1].value ? '#2ecc71' : '#e74c3c', marginTop: 4, borderTop: '1px solid #1e2d3d', paddingTop: 4 }}>
          Alpha: {(payload[0].value - payload[1].value).toFixed(1)}
        </div>
      )}
    </div>
  );
};

export default function BacktestResults({ results, onClose }) {
  const {
    totalReturn, benchmarkReturn, sharpe, maxDrawdown,
    winRate, numTrades, profitFactor, monthlyData,
    period, benchmark, tickersUsed,
  } = results;

  const outperformance = totalReturn - benchmarkReturn;

  const returnColor = totalReturn > 0 ? '#2ecc71' : '#e74c3c';
  const alphaColor = outperformance > 0 ? '#2ecc71' : '#e74c3c';
  const sharpeColor = sharpe > 1 ? '#2ecc71' : sharpe > 0.5 ? '#f1c40f' : '#e74c3c';
  const drawdownColor = maxDrawdown < 10 ? '#2ecc71' : maxDrawdown < 20 ? '#f1c40f' : '#e74c3c';
  const winColor = winRate >= 55 ? '#2ecc71' : winRate >= 45 ? '#f1c40f' : '#e74c3c';
  const pfColor = profitFactor > 1.5 ? '#2ecc71' : profitFactor > 1 ? '#f1c40f' : '#e74c3c';

  return (
    <div style={{
      marginTop: 20, background: '#0a1118',
      border: '1px solid rgba(62,207,255,0.2)',
      borderRadius: 10, padding: 22,
    }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
        <div>
          <div style={{ fontWeight: 800, fontSize: 16, color: '#dce8f5', marginBottom: 4 }}>
            📊 Backtestresultat
          </div>
          <div style={{ fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>
            {period} &nbsp;·&nbsp; Benchmark: {benchmark} &nbsp;·&nbsp; {tickersUsed?.length || 0} instrument
          </div>
        </div>
        <button onClick={onClose} style={{
          background: 'transparent', border: '1px solid #253649', color: '#5a7a94',
          padding: '5px 12px', borderRadius: 5, cursor: 'pointer', fontSize: 11, fontWeight: 700,
        }}>✕ Stäng</button>
      </div>

      {/* Primary metrics */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, marginBottom: 10 }}>
        <MetricCard
          label="Total avkastning"
          value={`${totalReturn > 0 ? '+' : ''}${totalReturn?.toFixed(1)}%`}
          subtitle={`Benchmark: ${benchmarkReturn > 0 ? '+' : ''}${benchmarkReturn?.toFixed(1)}%`}
          color={returnColor}
        />
        <MetricCard
          label="Alpha vs benchmark"
          value={`${outperformance > 0 ? '+' : ''}${outperformance?.toFixed(1)}%`}
          subtitle={outperformance > 0 ? '▲ Överträffar index' : '▼ Underträffar index'}
          color={alphaColor}
        />
        <MetricCard
          label="Sharpekvot"
          value={sharpe?.toFixed(2)}
          subtitle={sharpe > 1.5 ? 'Utmärkt' : sharpe > 1 ? 'Bra' : sharpe > 0.5 ? 'Acceptabel' : 'Svag'}
          color={sharpeColor}
        />
        <MetricCard
          label="Max Drawdown"
          value={`-${maxDrawdown?.toFixed(1)}%`}
          subtitle={maxDrawdown < 10 ? 'Låg risk' : maxDrawdown < 20 ? 'Moderat' : 'Hög risk'}
          color={drawdownColor}
        />
      </div>

      {/* Secondary metrics */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, marginBottom: 18 }}>
        <MetricCard
          label="Träffsäkerhet"
          value={`${winRate?.toFixed(1)}%`}
          subtitle={winRate >= 55 ? 'Stark' : winRate >= 45 ? 'OK' : 'Svag'}
          color={winColor}
        />
        <MetricCard
          label="Antal affärer"
          value={numTrades}
          subtitle={numTrades < 10 ? 'Statistiskt svag' : 'Statistiskt OK'}
          color={numTrades >= 10 ? '#dce8f5' : '#f1c40f'}
        />
        <MetricCard
          label="Profit Factor"
          value={profitFactor?.toFixed(2) ?? '—'}
          subtitle={profitFactor > 1.5 ? 'Stark strategi' : profitFactor > 1 ? 'Lönsam' : 'Olönsam'}
          color={pfColor}
        />
        <MetricCard
          label="Riskjusterat R:R"
          value={profitFactor != null ? `${(profitFactor).toFixed(1)}:1` : '—'}
          subtitle="Vinster / förluster"
          color="#90aabf"
        />
      </div>

      {/* Equity curve chart */}
      {monthlyData?.length > 0 && (
        <div style={{ marginBottom: 18 }}>
          <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 10 }}>
            Värdeutveckling — Startindex 100
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={monthlyData} margin={{ top: 5, right: 5, left: -10, bottom: 0 }}>
              <defs>
                <linearGradient id="stratGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3ecfff" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#3ecfff" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="benchGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f1c40f" stopOpacity={0.1} />
                  <stop offset="95%" stopColor="#f1c40f" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1a2535" />
              <XAxis dataKey="label" tick={{ fontFamily: 'monospace', fontSize: 9, fill: '#3d5a72' }} />
              <YAxis tick={{ fontFamily: 'monospace', fontSize: 9, fill: '#3d5a72' }} domain={['auto', 'auto']} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontFamily: 'monospace', fontSize: 10, color: '#90aabf' }} />
              <ReferenceLine y={100} stroke="#253649" strokeDasharray="4 4" />
              <Area type="monotone" dataKey="strategy" name="Strategi" stroke="#3ecfff" strokeWidth={2} fill="url(#stratGrad)" dot={false} />
              <Area type="monotone" dataKey="benchmark" name="SPY" stroke="#f1c40f" strokeWidth={1.5} fill="url(#benchGrad)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Interpretation */}
      <div style={{
        background: '#131b24', border: '1px solid #1e2d3d', borderRadius: 7,
        padding: '12px 14px', marginBottom: 14,
      }}>
        <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 8 }}>
          📋 Tolkning
        </div>
        <div style={{ fontSize: 11, color: '#90aabf', lineHeight: 1.8 }}>
          {sharpe > 1.5
            ? '✓ Stark riskjusterad avkastning — strategin genererar god avkastning per riskenhet.'
            : sharpe > 0.5
            ? '◦ Godkänd Sharpekvot — strategin fungerar men kan förbättras.'
            : '⚠ Svag Sharpekvot — justera regler via Optimera för bättre risk/belöning.'}
          {' '}
          {maxDrawdown < 10
            ? 'Drawdown är välkontrollerad och kapital är välskyddat.'
            : maxDrawdown < 20
            ? 'Moderat drawdown — överväg att skärpa stop-nivåerna.'
            : 'Hög drawdown — minska risk per affär eller skärpa stopp-kriterierna.'}
          {' '}
          {outperformance > 5
            ? 'Strategin genererar tydlig alpha mot S&P 500.'
            : outperformance > 0
            ? 'Strategin slår index marginellt — bra start.'
            : 'Strategin underträffar index — optimera reglerna.'}
        </div>
      </div>

      {/* Tickers used */}
      {tickersUsed?.length > 0 && (
        <div>
          <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 8 }}>
            Instrument i backtestet
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            {tickersUsed.map(t => (
              <span key={t} style={{
                fontFamily: 'monospace', fontSize: 10, padding: '3px 8px', borderRadius: 3,
                background: 'rgba(62,207,255,0.06)', border: '1px solid rgba(62,207,255,0.15)', color: '#3ecfff',
              }}>{t}</span>
            ))}
          </div>
          <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', marginTop: 8 }}>
            * Backtesting är simulering baserat på historisk data. Tidigare avkastning är ingen garanti för framtida resultat.
          </div>
        </div>
      )}
    </div>
  );
}