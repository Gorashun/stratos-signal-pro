import React from 'react';

export default function LogsPage({ logs, onClear }) {
  return (
    <div style={{ padding: 24 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <div>
          <div style={{ fontSize: 22, fontWeight: 800 }}>Loggar</div>
          <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', marginTop: 3 }}>Revisionsspår</div>
        </div>
        <button onClick={onClear} style={{
          background: 'transparent', border: '1px solid #253649', color: '#dce8f5',
          padding: '6px 14px', borderRadius: 6, cursor: 'pointer', fontSize: 12, fontWeight: 700,
        }}>Rensa</button>
      </div>
      <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, overflow: 'hidden' }}>
        {logs.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 32, color: '#5a7a94', fontFamily: 'monospace', fontSize: 11 }}>
            Inga loggar än
          </div>
        ) : (
          logs.map((entry, i) => (
            <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'baseline', padding: '8px 13px', borderBottom: '1px solid rgba(30,45,61,0.4)', fontFamily: 'monospace', fontSize: 11 }}>
              <span style={{ color: '#3d5a72', minWidth: 70 }}>{entry.time}</span>
              <span style={{
                minWidth: 40,
                color: entry.level === 'INFO' ? '#3ecfff' : entry.level === 'WARN' ? '#f1c40f' : '#e74c3c',
              }}>{entry.level}</span>
              <span style={{ color: '#dce8f5' }}>{entry.msg}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}