import React, { useState } from 'react';
import SignalCard from './SignalCard';
import SignalDetailedAnalysis from './SignalDetailedAnalysis';

export default function SignalsPage({ signals, onRunSignals, onFetchData, marketDataCount, marketData, regime }) {
  const [activeTab, setActiveTab] = useState('sweden');

  const swedishSignals = signals.filter(s => s.market === 'sweden');
  const globalSignals = signals.filter(s => s.market !== 'sweden');
  const allApproved = signals.filter(s => s.status === 'APPROVED');
  const globalApproved = globalSignals.filter(s => s.status === 'APPROVED');

  const displaySignals = activeTab === 'sweden' ? swedishSignals
    : activeTab === 'global' ? globalSignals
    : signals;

  const handleGenerateSignals = async () => {
    // If no market data, fetch first
    if (!marketDataCount || marketDataCount === 0) {
      await onFetchData();
    }
    onRunSignals();
  };

  return (
    <div style={{ padding: 24 }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20 }}>
        <div>
          <div style={{ fontSize: 22, fontWeight: 800 }}>Signaler</div>
          <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', marginTop: 3 }}>
            Klicka på en signal för teknisk analys & indikatordiagram
          </div>
        </div>
        <button
          onClick={handleGenerateSignals}
          style={{ background: '#3ecfff', border: '1px solid #3ecfff', color: '#080c10', padding: '6px 14px', borderRadius: 6, cursor: 'pointer', fontSize: 12, fontWeight: 700 }}
        >⚡ Generera signaler</button>
      </div>

      {/* Summary strip */}
      <div style={{ display: 'flex', gap: 0, marginBottom: 18, background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, overflow: 'hidden' }}>
        {[
          { label: 'Totalt', value: signals.length, color: '#dce8f5' },
          { label: 'Godkända', value: allApproved.length, color: '#2ecc71' },
          { label: 'Sverige', value: swedishSignals.filter(s => s.status === 'APPROVED').length, color: '#3ecfff' },
          { label: 'Globalt', value: globalApproved.length, color: '#ff6b35' },
        ].map((item, i) => (
          <div key={i} style={{ flex: 1, padding: '10px 13px', borderRight: i < 3 ? '1px solid #1e2d3d' : 'none' }}>
            <div style={{ fontFamily: 'monospace', fontSize: 9, letterSpacing: 1.5, color: '#3d5a72', textTransform: 'uppercase', marginBottom: 4 }}>{item.label}</div>
            <div style={{ fontFamily: 'monospace', fontSize: 16, fontWeight: 700, color: item.color }}>{item.value}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 2, background: '#131b24', border: '1px solid #1e2d3d', borderRadius: 8, padding: 3, marginBottom: 16, width: 'fit-content' }}>
        {[
          { id: 'sweden', label: '🇸🇪 Sverige', count: swedishSignals.filter(s => s.status === 'APPROVED').length },
          { id: 'global', label: '🌍 Globalt', count: globalApproved.length },
          { id: 'all', label: 'Alla', count: allApproved.length },
        ].map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{
            padding: '5px 14px', borderRadius: 5, fontSize: 12, fontWeight: 600, cursor: 'pointer',
            border: 'none',
            background: activeTab === tab.id ? '#1a2535' : 'transparent',
            color: activeTab === tab.id ? '#dce8f5' : '#5a7a94',
          }}>
            {tab.label} {tab.count > 0 && <span style={{ marginLeft: 4, background: '#3ecfff', color: '#080c10', fontFamily: 'monospace', fontSize: 9, padding: '1px 5px', borderRadius: 9 }}>{tab.count}</span>}
          </button>
        ))}
      </div>

      {/* Signals list */}
      <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, overflow: 'hidden' }}>
        {displaySignals.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 42, color: '#5a7a94' }}>
            <div style={{ fontSize: 28, marginBottom: 7 }}>⚡</div>
            <div style={{ fontWeight: 700 }}>Inga signaler</div>
            <div style={{ fontFamily: 'monospace', fontSize: 11 }}>Kör signalcykel för att generera</div>
          </div>
        ) : (
          <div>
            {/* Header row */}
            <div style={{ display: 'grid', gridTemplateColumns: '160px 100px 100px 100px 100px 80px 60px 130px 110px 32px', padding: '9px 13px', background: '#131b24', borderBottom: '1px solid #1e2d3d', gap: 0 }}>
              {['Bolag', 'Marknad', 'Ingång', 'Stop', 'TP', 'Risk/affär', 'RSI', 'Regel', 'Status', ''].map(h => (
                <div key={h} style={{ fontFamily: 'monospace', fontSize: 9, letterSpacing: 1.5, color: '#3d5a72', textTransform: 'uppercase' }}>{h}</div>
              ))}
            </div>
            {displaySignals.map((s, i) => (
              <div key={`${s.ticker}-${i}`}>
                <SignalCard s={s} marketData={marketData} regime={regime} />
                {s.status === 'APPROVED' && marketData && regime && (
                  <SignalDetailedAnalysis signal={s} marketData={marketData} regime={regime} />
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}