import React, { useState } from 'react';
import { invokeFunction, Trade, Watchlist, Instrument, Signal } from '@/api/supabaseClient';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const SECTOR_COLORS = [
  '#3ecfff', '#2ecc71', '#f1c40f', '#e74c3c', '#9b59b6',
  '#ff6b35', '#1abc9c', '#e67e22', '#3498db', '#e91e63',
];

const RISK_COLOR = { Låg: '#2ecc71', Medium: '#f1c40f', Hög: '#e74c3c' };
const MARKET_FLAG = { sweden: '🇸🇪', usa: '🇺🇸', europe: '🇪🇺', asia: '🌏' };
const MARKET_LABEL = { sweden: 'Sverige', usa: 'USA', europe: 'Europa', asia: 'Asien' };

function Tag({ children, color }) {
  return (
    <span style={{
      fontFamily: 'monospace', fontSize: 9, padding: '2px 7px', borderRadius: 10,
      background: `${color}18`, border: `1px solid ${color}44`, color,
    }}>{children}</span>
  );
}

function ScoreBar({ value }) {
  const color = value >= 80 ? '#2ecc71' : value >= 60 ? '#f1c40f' : '#e74c3c';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <div style={{ flex: 1, height: 6, background: '#1a2535', borderRadius: 3, overflow: 'hidden' }}>
        <div style={{ width: `${value}%`, height: '100%', background: color, borderRadius: 3 }} />
      </div>
      <span style={{ fontFamily: 'monospace', fontSize: 12, color, fontWeight: 700, minWidth: 32 }}>{value}</span>
    </div>
  );
}

export default function PortfolioSuggestionPage({ strategy }) {
  const [riskProfile, setRiskProfile] = useState('balanced');
  const [marketFocus, setMarketFocus] = useState(['sweden', 'usa']);
  const [sectors, setSectors] = useState([]);
  const [capitalAmount, setCapitalAmount] = useState('');
  const [investmentHorizon, setInvestmentHorizon] = useState('1–3 år');
  const [loading, setLoading] = useState(false);
  const [portfolio, setPortfolio] = useState(null);
  const [error, setError] = useState('');

  const allMarkets = [
    { id: 'sweden', label: 'Sverige 🇸🇪' },
    { id: 'usa', label: 'USA 🇺🇸' },
    { id: 'europe', label: 'Europa 🇪🇺' },
    { id: 'asia', label: 'Asien 🌏' },
  ];

  const allSectors = [
    'Teknik', 'Finans', 'Industri', 'Hälsovård', 'Konsument', 'Energi', 'Fastigheter', 'Material', 'Telekom', 'Verktyg'
  ];

  const toggleMarket = (id) => setMarketFocus(prev => prev.includes(id) ? prev.filter(m => m !== id) : [...prev, id]);
  const toggleSector = (s) => setSectors(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);

  const generate = async () => {
    setLoading(true);
    setError('');
    setPortfolio(null);
    try {
      const res = await invokeFunction('generatePortfolioSuggestion', {
        riskProfile, marketFocus, sectors, capitalAmount, investmentHorizon,
        strategy: strategy?.name,
      });
      if (res.data?.error) throw new Error(res.data.error);
      setPortfolio(res.data?.portfolio);
    } catch (e) {
      setError(e.message);
    }
    setLoading(false);
  };

  // Build pie data from sector_breakdown
  const pieData = portfolio?.sector_breakdown
    ? Object.entries(portfolio.sector_breakdown).map(([name, value]) => ({ name, value }))
    : [];

  return (
    <div style={{ padding: 24, maxWidth: 960 }}>
      <div style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>Portföljförslag</div>
      <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', marginBottom: 24 }}>
        AI konstruerar en diversifierad portfölj baserat på dina parametrar
      </div>

      {/* Configuration panel */}
      <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, padding: 22, marginBottom: 20 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, marginBottom: 18 }}>
          {/* Risk profile */}
          <div>
            <div style={labelStyle}>Riskprofil</div>
            <select value={riskProfile} onChange={e => setRiskProfile(e.target.value)} style={selectStyle}>
              <option value="conservative">Konservativ — låg risk, stabila utdelningar</option>
              <option value="balanced">Balanserad — tillväxt + stabilitet</option>
              <option value="aggressive">Aggressiv — hög tillväxt, hög volatilitet</option>
              <option value="income">Inkomst — fokus på hög direktavkastning</option>
            </select>
          </div>

          {/* Investment horizon */}
          <div>
            <div style={labelStyle}>Investeringshorisont</div>
            <select value={investmentHorizon} onChange={e => setInvestmentHorizon(e.target.value)} style={selectStyle}>
              <option value="&lt;1 år">Kortfristig (&lt; 1 år)</option>
              <option value="1–3 år">Medelfristig (1–3 år)</option>
              <option value="3–7 år">Långfristig (3–7 år)</option>
              <option value="7+ år">Mycket långfristig (7+ år)</option>
            </select>
          </div>

          {/* Capital */}
          <div>
            <div style={labelStyle}>Kapital (SEK, valfritt)</div>
            <input
              type="number"
              value={capitalAmount}
              onChange={e => setCapitalAmount(e.target.value)}
              placeholder="t.ex. 100000"
              style={{ ...selectStyle, outline: 'none' }}
            />
          </div>
        </div>

        {/* Market focus toggles */}
        <div style={{ marginBottom: 16 }}>
          <div style={labelStyle}>Marknadsfokus</div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {allMarkets.map(m => (
              <button key={m.id} onClick={() => toggleMarket(m.id)} style={{
                padding: '6px 14px', borderRadius: 20, fontSize: 12, cursor: 'pointer', fontWeight: 600,
                border: `1px solid ${marketFocus.includes(m.id) ? '#3ecfff' : '#253649'}`,
                background: marketFocus.includes(m.id) ? 'rgba(62,207,255,0.1)' : 'transparent',
                color: marketFocus.includes(m.id) ? '#3ecfff' : '#5a7a94',
              }}>{m.label}</button>
            ))}
          </div>
        </div>

        {/* Sector preference */}
        <div style={{ marginBottom: 20 }}>
          <div style={labelStyle}>Sektorfokus (valfritt — lämna tomt för alla)</div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {allSectors.map(s => (
              <button key={s} onClick={() => toggleSector(s)} style={{
                padding: '5px 12px', borderRadius: 20, fontSize: 11, cursor: 'pointer', fontWeight: 600,
                border: `1px solid ${sectors.includes(s) ? '#f1c40f' : '#253649'}`,
                background: sectors.includes(s) ? 'rgba(241,196,15,0.1)' : 'transparent',
                color: sectors.includes(s) ? '#f1c40f' : '#5a7a94',
              }}>{s}</button>
            ))}
          </div>
        </div>

        <button
          onClick={generate}
          disabled={loading}
          style={{
            background: loading ? '#1a2535' : '#3ecfff', border: 'none', color: loading ? '#5a7a94' : '#080c10',
            padding: '10px 22px', borderRadius: 7, cursor: loading ? 'not-allowed' : 'pointer',
            fontSize: 13, fontWeight: 800, letterSpacing: 0.5,
          }}
        >
          {loading ? '⌛ Genererar portfölj via AI…' : '✦ Generera portföljförslag'}
        </button>

        {error && (
          <div style={{ marginTop: 12, fontFamily: 'monospace', fontSize: 11, color: '#e74c3c' }}>⚠ {error}</div>
        )}
      </div>

      {/* Portfolio result */}
      {portfolio && (
        <div>
          {/* Header */}
          <div style={{ background: '#0a1118', border: '1px solid rgba(62,207,255,0.25)', borderRadius: 10, padding: 22, marginBottom: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
              <div>
                <div style={{ fontSize: 18, fontWeight: 800, color: '#dce8f5', marginBottom: 4 }}>
                  {portfolio.portfolio_name}
                </div>
                <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                  <Tag color="#2ecc71">Förväntad avkastning: {portfolio.expected_annual_return}</Tag>
                  <Tag color="#3ecfff">Diversifiering: {portfolio.diversification_score}/100</Tag>
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', marginBottom: 4, textTransform: 'uppercase', letterSpacing: 1.5 }}>Diversifieringspoäng</div>
                <ScoreBar value={portfolio.diversification_score} />
              </div>
            </div>

            <div style={{ fontSize: 12, color: '#90aabf', lineHeight: 1.8, marginBottom: 12 }}>{portfolio.rationale}</div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <div style={{ background: '#131b24', border: '1px solid #1e2d3d', borderRadius: 7, padding: '10px 14px' }}>
                <div style={labelStyle}>Riskbedömning</div>
                <div style={{ fontSize: 11, color: '#dce8f5', lineHeight: 1.6 }}>{portfolio.risk_assessment}</div>
              </div>
              <div style={{ background: '#131b24', border: '1px solid #1e2d3d', borderRadius: 7, padding: '10px 14px' }}>
                <div style={labelStyle}>Rebalanseringsrekommendation</div>
                <div style={{ fontSize: 11, color: '#dce8f5', lineHeight: 1.6 }}>{portfolio.rebalance_suggestion}</div>
              </div>
            </div>
          </div>

          {/* Chart + sector breakdown */}
          {pieData.length > 0 && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
              <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, padding: 18 }}>
                <div style={labelStyle}>Sektorfördelning</div>
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={75} stroke="none">
                      {pieData.map((_, i) => <Cell key={i} fill={SECTOR_COLORS[i % SECTOR_COLORS.length]} />)}
                    </Pie>
                    <Tooltip
                      formatter={(v) => `${v}%`}
                      contentStyle={{ background: '#0d1219', border: '1px solid #253649', fontFamily: 'monospace', fontSize: 11 }}
                    />
                    <Legend wrapperStyle={{ fontFamily: 'monospace', fontSize: 10, color: '#90aabf' }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, padding: 18 }}>
                <div style={labelStyle}>Sektorer — viktning</div>
                {pieData.sort((a, b) => b.value - a.value).map((s, i) => (
                  <div key={s.name} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
                    <div style={{ width: 8, height: 8, borderRadius: 2, background: SECTOR_COLORS[i % SECTOR_COLORS.length], flexShrink: 0 }} />
                    <div style={{ flex: 1, fontSize: 12, color: '#90aabf' }}>{s.name}</div>
                    <div style={{ fontFamily: 'monospace', fontSize: 12, color: '#dce8f5', fontWeight: 600 }}>{s.value}%</div>
                    <div style={{ width: 80, height: 4, background: '#1a2535', borderRadius: 2, overflow: 'hidden' }}>
                      <div style={{ width: `${s.value}%`, height: '100%', background: SECTOR_COLORS[i % SECTOR_COLORS.length], borderRadius: 2 }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Holdings list */}
          <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, overflow: 'hidden' }}>
            <div style={{ background: '#131b24', borderBottom: '1px solid #1e2d3d', padding: '10px 16px' }}>
              <div style={{ fontFamily: 'monospace', fontSize: 10, letterSpacing: 1.5, color: '#3d5a72', textTransform: 'uppercase' }}>
                Portföljpositioner — {portfolio.holdings?.length} innehav
              </div>
            </div>

            {(portfolio.holdings || []).map((h, i) => {
              const sectorIdx = pieData.findIndex(p => p.name === h.sector);
              const sectorColor = SECTOR_COLORS[sectorIdx >= 0 ? sectorIdx % SECTOR_COLORS.length : i % SECTOR_COLORS.length];
              return (
                <div key={i} style={{
                  display: 'grid', gridTemplateColumns: '1fr 80px 90px 80px 90px',
                  alignItems: 'center', padding: '14px 16px', gap: 12,
                  borderBottom: i < portfolio.holdings.length - 1 ? '1px solid rgba(30,45,61,0.5)' : 'none',
                }}>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                      <span style={{ fontFamily: 'monospace', fontWeight: 700, fontSize: 13 }}>{h.ticker}</span>
                      <Tag color={sectorColor}>{h.sector}</Tag>
                      <Tag color={RISK_COLOR[h.risk_level] || '#5a7a94'}>{h.risk_level}</Tag>
                    </div>
                    <div style={{ fontSize: 11, color: '#90aabf', marginBottom: 4 }}>{h.company_name}</div>
                    <div style={{ fontSize: 11, color: '#5a7a94', lineHeight: 1.5 }}>{h.rationale}</div>
                  </div>

                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', marginBottom: 3, textTransform: 'uppercase' }}>Marknad</div>
                    <div style={{ fontSize: 12 }}>{MARKET_FLAG[h.market]} {MARKET_LABEL[h.market] || h.market}</div>
                  </div>

                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', marginBottom: 3, textTransform: 'uppercase' }}>Vikt</div>
                    <div style={{ fontFamily: 'monospace', fontSize: 16, fontWeight: 700, color: '#3ecfff' }}>{h.weight_pct?.toFixed(1)}%</div>
                    <div style={{ width: '100%', height: 3, background: '#1a2535', borderRadius: 2, marginTop: 4, overflow: 'hidden' }}>
                      <div style={{ width: `${h.weight_pct}%`, height: '100%', background: '#3ecfff', borderRadius: 2 }} />
                    </div>
                  </div>

                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', marginBottom: 3, textTransform: 'uppercase' }}>Direktavk.</div>
                    <div style={{ fontFamily: 'monospace', fontSize: 13, color: h.dividend_yield_est > 0 ? '#2ecc71' : '#5a7a94' }}>
                      {h.dividend_yield_est > 0 ? `${h.dividend_yield_est?.toFixed(1)}%` : '—'}
                    </div>
                  </div>

                  {capitalAmount && (
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', marginBottom: 3, textTransform: 'uppercase' }}>Belopp</div>
                      <div style={{ fontFamily: 'monospace', fontSize: 12, color: '#dce8f5' }}>
                        {Math.round(Number(capitalAmount) * h.weight_pct / 100).toLocaleString('sv-SE')} kr
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', marginTop: 12, lineHeight: 1.7 }}>
            * Detta är ett AI-genererat förslag och utgör inte finansiell rådgivning. Gör alltid din egen analys innan du investerar.
          </div>
        </div>
      )}
    </div>
  );
}

const labelStyle = {
  fontFamily: 'monospace', fontSize: 9, letterSpacing: 1.5, color: '#5a7a94',
  textTransform: 'uppercase', marginBottom: 7,
};

const selectStyle = {
  background: '#131b24', border: '1px solid #253649', borderRadius: 7,
  padding: '9px 12px', color: '#dce8f5', fontSize: 13, width: '100%',
};