import React, { useState } from 'react';
import { MARKETS } from './instruments';
import SignalDetailedAnalysis from './SignalDetailedAnalysis';
import SignalAnalysisPanel from './SignalAnalysisPanel';

// Mini sparkline chart using SVG
function MiniChart({ price, ema20, ema50, entry, stop, tp }) {
  if (!price || !ema20 || !ema50) return null;

  // Simulate a price path around EMA values for visual context
  const basePrice = ema50;
  const range = Math.max(tp - stop, price * 0.1);
  const low = stop * 0.99;
  const high = tp * 1.01;
  const totalRange = high - low;

  const toY = (val) => Math.round(((high - val) / totalRange) * 56);
  const toX = (i) => Math.round((i / 9) * 160);

  // Fake 10-point price path ending at entry
  const path = [
    ema50 * 0.97, ema50 * 0.98, ema50 * 0.985, ema50 * 0.99,
    ema50, ema20 * 0.99, ema20, ema20 * 1.002, price * 0.999, price
  ];

  const pricePathD = path.map((v, i) => `${i === 0 ? 'M' : 'L'}${toX(i)},${toY(v)}`).join(' ');
  const ema20Line = `M0,${toY(ema50)} L160,${toY(ema20)}`;
  const ema50Line = `M0,${toY(ema50)} L160,${toY(ema50)}`;

  return (
    <svg width="164" height="60" style={{ display: 'block' }}>
      <rect width="164" height="60" rx="4" fill="#0d1219" />
      {/* TP/Stop zones */}
      <rect x="0" y={toY(tp)} width="164" height={Math.max(1, toY(entry) - toY(tp))} fill="rgba(46,204,113,0.06)" />
      <rect x="0" y={toY(entry)} width="164" height={Math.max(1, toY(stop) - toY(entry))} fill="rgba(231,76,60,0.06)" />
      {/* TP line */}
      <line x1="0" y1={toY(tp)} x2="164" y2={toY(tp)} stroke="#2ecc71" strokeWidth="1" strokeDasharray="2,2" opacity="0.5" />
      {/* Stop line */}
      <line x1="0" y1={toY(stop)} x2="164" y2={toY(stop)} stroke="#e74c3c" strokeWidth="1" strokeDasharray="2,2" opacity="0.5" />
      {/* EMA50 */}
      <path d={ema50Line} stroke="#f1c40f" strokeWidth="1.2" fill="none" opacity="0.6" />
      {/* EMA20 */}
      <path d={ema20Line} stroke="#3ecfff" strokeWidth="1.2" fill="none" opacity="0.7" />
      {/* Price path */}
      <path d={pricePathD} stroke="#dce8f5" strokeWidth="1.5" fill="none" />
      {/* Current price dot */}
      <circle cx="160" cy={toY(price)} r="3" fill="#dce8f5" />
      {/* Labels */}
      <text x="3" y="8" fill="#2ecc71" fontSize="7" fontFamily="monospace" opacity="0.8">TP {tp?.toFixed(1)}</text>
      <text x="3" y="56" fill="#e74c3c" fontSize="7" fontFamily="monospace" opacity="0.8">SL {stop?.toFixed(1)}</text>
      <text x="100" y="8" fill="#3ecfff" fontSize="7" fontFamily="monospace" opacity="0.7">EMA20</text>
      <text x="100" y="17" fill="#f1c40f" fontSize="7" fontFamily="monospace" opacity="0.6">EMA50</text>
    </svg>
  );
}

function formatRule(s) {
  if (!s.rule_name && !s.rule) return null;
  const rn = s.rule_name || s.rule || '';
  const conditions = [];
  if (s.ema20 && s.ema50) {
    if (s.ema20 > s.ema50) conditions.push('EMA20 > EMA50 (bullish korsning)');
    else conditions.push('EMA20 < EMA50 (bearish)');
  }
  if (s.rsi != null) {
    if (s.rsi > 50 && s.rsi < 70) conditions.push(`RSI ${s.rsi?.toFixed(0)} — momentum`);
    else if (s.rsi < 40) conditions.push(`RSI ${s.rsi?.toFixed(0)} — översåld`);
    else if (s.rsi > 70) conditions.push(`RSI ${s.rsi?.toFixed(0)} — överköpt`);
  }
  if (s.price && s.ema50 && s.price > s.ema50) conditions.push('Pris > EMA50');
  return { name: rn, conditions };
}

export default function SignalCard({ s, compact = false, marketData = {}, regime = 'neutral' }) {
  const [expanded, setExpanded] = useState(false);
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState(null);
  const [loadingAI, setLoadingAI] = useState(false);
  const m = MARKETS[s.market];
  const isApproved = s.status === 'APPROVED';
  const ruleInfo = formatRule(s);
  const rr = s.entry && s.stop && s.tp ? ((s.tp - s.entry) / (s.entry - s.stop)) : null;

  const rsiColor = s.rsi > 70 ? '#e74c3c' : s.rsi < 30 ? '#2ecc71' : '#5a7a94';

  // Load AI analysis when expanded
  const loadAIAnalysis = async () => {
    if (aiAnalysis || loadingAI) return;
    setLoadingAI(true);
    try {
      const res = await fetch(window.location.origin + '/api/functions/invoke', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          functionName: 'analyzeSignalAI',
          payload: { signal: s }
        })
      });
      const data = await res.json();
      if (res.ok) setAiAnalysis(data);
    } catch (e) {
      console.error('AI analysis failed:', e);
    }
    setLoadingAI(false);
  };

  return (
    <div style={{ borderBottom: '1px solid rgba(30,45,61,0.5)', background: expanded ? 'rgba(62,207,255,0.02)' : 'transparent' }}>
      {/* Main row */}
      <div
        onClick={() => { setExpanded(e => !e); if (!aiAnalysis && isApproved) setTimeout(loadAIAnalysis, 100); }}
        style={{ display: 'grid', gridTemplateColumns: compact ? '140px 80px 90px 90px 90px 70px 60px 100px 90px 32px' : '160px 100px 100px 100px 100px 80px 60px 130px 110px 32px', alignItems: 'center', padding: '10px 13px', cursor: 'pointer', gap: 0 }}
      >
        <div>
          <div style={{ fontFamily: 'monospace', fontWeight: 700, fontSize: 13 }}>{s.ticker}</div>
          <div style={{ fontSize: 10, color: '#5a7a94' }}>{s.name || s.company_name}</div>
        </div>
        <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94' }}>{m?.flag} {m?.label}</div>
        <div style={{ fontFamily: 'monospace', fontSize: 12 }}>
          {s.entry?.toFixed(2)} <span style={{ fontSize: 10, color: '#5a7a94' }}>{s.currency}</span>
        </div>
        <div style={{ fontFamily: 'monospace', fontSize: 12, color: '#e74c3c' }}>{s.stop?.toFixed(2)}</div>
        <div style={{ fontFamily: 'monospace', fontSize: 12, color: '#2ecc71' }}>{(s.tp || s.take_profit)?.toFixed(2)}</div>
        <div style={{ fontFamily: 'monospace', fontSize: 12 }}>{((s.riskPct || s.risk_pct || 0) * 100).toFixed(1)}%</div>
        <div style={{ fontFamily: 'monospace', fontSize: 12, color: rsiColor }}>{s.rsi?.toFixed(1)}</div>
        <div>
          <span style={{ fontFamily: 'monospace', fontSize: 9, padding: '2px 6px', borderRadius: 3, background: 'rgba(62,207,255,0.08)', color: '#3ecfff', border: '1px solid rgba(62,207,255,0.15)' }}>
            {s.rule_name || s.rule || '—'}
          </span>
        </div>
        <div>
          {isApproved
            ? <span style={{ color: '#2ecc71', fontFamily: 'monospace', fontSize: 10 }}>✓ GODKÄND</span>
            : <span style={{ color: '#e74c3c', fontFamily: 'monospace', fontSize: 10 }}>✗ {s.reject_reason || s.reason}</span>
          }
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          {isApproved && (
            <button
              onClick={(e) => { e.stopPropagation(); setShowAnalysis(true); }}
              style={{
                background: 'rgba(62,207,255,0.08)', border: '1px solid rgba(62,207,255,0.2)',
                color: '#3ecfff', padding: '4px 8px', borderRadius: 4, cursor: 'pointer',
                fontSize: 10, fontWeight: 700, whiteSpace: 'nowrap',
              }}
              title="Visa varför denna signal utgavs"
            >
              ✦ Analys
            </button>
          )}
          <div style={{ color: '#3d5a72', fontSize: 14, textAlign: 'center' }}>{expanded ? '▲' : '▼'}</div>
        </div>
      </div>

      {/* Analysis Panel */}
      {showAnalysis && (
        <SignalAnalysisPanel
          ticker={s.ticker}
          signal={s}
          marketData={marketData[`${s.market}:${s.ticker}`] || marketData[s.ticker] || {}}
          onClose={() => setShowAnalysis(false)}
        />
      )}

      {/* Expanded detail panel */}
      {expanded && (
        <div style={{ padding: '0 13px 16px 13px' }}>
          <div>
            {/* What is this signal */}
            <div style={{ background: 'rgba(62,207,255,0.06)', border: '1px solid rgba(62,207,255,0.2)', borderRadius: 7, padding: '10px 14px', marginBottom: 10 }}>
              <div style={{ fontFamily: 'monospace', fontSize: 9, letterSpacing: 1.5, color: '#3ecfff', textTransform: 'uppercase', marginBottom: 6 }}>📊 Vad betyder denna signal?</div>
              <div style={{ fontSize: 11, color: '#dce8f5', lineHeight: 1.6 }}>
                <strong>Köpsignal</strong> — AI:n rekommenderar att <strong>köpa</strong> denna aktie nu. 
                <br />Signalen utgår från teknisk analys: aktien visar <strong>uppåtgående trend</strong> och <strong>momentum</strong>. 
                <br />Du kan köpa på nivån <strong>{s.entry?.toFixed(2)} {s.currency}</strong>, sälja övervinster på <strong>{(s.tp || s.take_profit)?.toFixed(2)}</strong>, 
                och stoppa på <strong>{s.stop?.toFixed(2)}</strong> för att begränsa förluster.
              </div>
            </div>

            {/* Technical trigger */}
            {ruleInfo && (
              <div style={{ background: '#131b24', border: '1px solid #1e2d3d', borderRadius: 7, padding: '10px 14px', marginBottom: 10 }}>
                <div style={{ fontFamily: 'monospace', fontSize: 9, letterSpacing: 1.5, color: '#3d5a72', textTransform: 'uppercase', marginBottom: 8 }}>⚡ Teknisk utlösare — {ruleInfo.name}</div>
                {ruleInfo.conditions.map((c, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 5 }}>
                    <span style={{ color: '#3ecfff', fontSize: 10 }}>▸</span>
                    <span style={{ fontFamily: 'monospace', fontSize: 11, color: '#90aabf' }}>{c}</span>
                  </div>
                ))}
              </div>
            )}

            {/* AI Analysis (auto-loaded) */}
            {loadingAI ? (
              <div style={{ background: '#131b24', border: '1px solid rgba(62,207,255,0.15)', borderRadius: 7, padding: '10px 14px', marginBottom: 10, textAlign: 'center', color: '#5a7a94', fontFamily: 'monospace', fontSize: 11 }}>
                ⏳ Läser in AI-analys…
              </div>
            ) : aiAnalysis ? (
              <div style={{ background: '#131b24', border: '1px solid rgba(62,207,255,0.2)', borderRadius: 7, padding: '10px 14px', marginBottom: 10 }}>
                <div style={{ fontFamily: 'monospace', fontSize: 9, letterSpacing: 1.5, color: '#3ecfff', textTransform: 'uppercase', marginBottom: 8 }}>✦ AI Motivering & Sannolikhet</div>
                <div style={{ fontSize: 12, color: '#dce8f5', lineHeight: 1.7, marginBottom: 10 }}>{aiAnalysis.reasoning}</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                  <div style={{ background: '#0d1219', borderRadius: 5, padding: '8px 12px' }}>
                    <div style={{ fontFamily: 'monospace', fontSize: 8, color: '#3d5a72', textTransform: 'uppercase', marginBottom: 4 }}>Sannolikhet (Lönsam)</div>
                    <div style={{ fontFamily: 'monospace', fontSize: 18, fontWeight: 700, color: aiAnalysis.confidence >= 70 ? '#2ecc71' : aiAnalysis.confidence >= 50 ? '#f1c40f' : '#e74c3c' }}>
                      {aiAnalysis.confidence}%
                    </div>
                  </div>
                  <div style={{ background: '#0d1219', borderRadius: 5, padding: '8px 12px', fontSize: 10, color: '#5a7a94', lineHeight: 1.5 }}>
                    {aiAnalysis.confidence_explanation}
                  </div>
                </div>
              </div>
            ) : isApproved ? (
              <div style={{ background: '#131b24', border: '1px solid rgba(62,207,255,0.15)', borderRadius: 7, padding: '10px 14px', marginBottom: 10, color: '#5a7a94', fontSize: 11 }}>
                <span style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72' }}>💡 AI-analys visas när du expanderar</span>
              </div>
            ) : null}

            {/* Reasoning / why this signal */}
            {s.reasoning && (
              <div style={{ background: '#131b24', border: '1px solid rgba(255,107,53,0.15)', borderRadius: 7, padding: '10px 14px', marginBottom: 10 }}>
                <div style={{ fontFamily: 'monospace', fontSize: 9, letterSpacing: 1.5, color: '#ff6b35', textTransform: 'uppercase', marginBottom: 7 }}>💡 Regel-motivering</div>
                <div style={{ fontSize: 12, color: '#dce8f5', lineHeight: 1.7 }}>{s.reasoning}</div>
              </div>
            )}

            {/* Risk/reward metrics */}
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 12 }}>
              {[
                { label: 'R:R', value: rr ? `1:${rr.toFixed(1)}` : '—', color: rr && rr >= 2 ? '#2ecc71' : '#f1c40f' },
                { label: 'EMA20', value: s.ema20?.toFixed(2) || '—', color: '#3ecfff' },
                { label: 'EMA50', value: s.ema50?.toFixed(2) || '—', color: '#f1c40f' },
                { label: 'ATR', value: s.atr?.toFixed(2) || '—', color: '#5a7a94' },
              ].map(item => (
                <div key={item.label} style={{ background: '#131b24', border: '1px solid #1e2d3d', borderRadius: 6, padding: '6px 12px', textAlign: 'center' }}>
                  <div style={{ fontFamily: 'monospace', fontSize: 8, color: '#3d5a72', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 3 }}>{item.label}</div>
                  <div style={{ fontFamily: 'monospace', fontSize: 13, fontWeight: 700, color: item.color }}>{item.value}</div>
                </div>
              ))}
            </div>

            {/* Mini chart */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 12 }}>
              <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', letterSpacing: 1.5, textTransform: 'uppercase' }}>Indikatoröversikt</div>
              <MiniChart
                price={s.entry || s.price}
                ema20={s.ema20}
                ema50={s.ema50}
                entry={s.entry}
                stop={s.stop}
                tp={s.tp || s.take_profit}
              />
              <div style={{ fontSize: 10, color: '#3d5a72', fontFamily: 'monospace', lineHeight: 1.8 }}>
                <span style={{ color: '#3ecfff' }}>—</span> EMA20 &nbsp;
                <span style={{ color: '#f1c40f' }}>—</span> EMA50 &nbsp;
                <span style={{ color: '#2ecc71' }}>- -</span> TP &nbsp;
                <span style={{ color: '#e74c3c' }}>- -</span> SL
              </div>
            </div>
            </div>
            </div>
            )}
            </div>
            );
            }