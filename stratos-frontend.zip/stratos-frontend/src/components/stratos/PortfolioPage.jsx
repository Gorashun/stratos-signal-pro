import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { invokeFunction, Trade, Watchlist, Instrument, Signal } from '@/api/supabaseClient';
import TradeForm from './portfolio/TradeForm';
import TradeHistory from './portfolio/TradeHistory';
import { PnLBarChart, AllocationPieChart } from './portfolio/PortfolioCharts';
import PortfolioRecommendations from './portfolio/PortfolioRecommendations';
import RiskExposureBar from './portfolio/RiskExposureBar';

const SECTOR_COLORS = {
  'Teknik': '#3ecfff', 'Finans': '#2ecc71', 'Hälsa': '#9b59b6',
  'Industri': '#f1c40f', 'Konsument': '#ff6b35', 'Energi': '#e74c3c',
  'Material': '#1abc9c', 'Fastigheter': '#e67e22', 'Telecom': '#3498db', 'Övrigt': '#5a7a94',
};

async function fetchFxRates() {
  try {
    const res = await fetch('https://api.frankfurter.app/latest?from=SEK&to=USD,EUR,GBP,JPY,HKD');
    const data = await res.json();
    const rates = {};
    for (const [ccy, rate] of Object.entries(data.rates || {})) rates[ccy] = 1 / rate;
    rates['SEK'] = 1;
    rates['GBp'] = (rates['GBP'] || 13) / 100;
    return rates;
  } catch {
    return { SEK: 1, USD: 10.5, EUR: 11.2, GBP: 13.3, GBp: 0.133, JPY: 0.072, HKD: 1.35 };
  }
}

// Build positions from Trade records (FIFO)
function buildPositionsFromTrades(trades) {
  const positions = {};
  const sorted = [...trades].sort((a, b) => a.date.localeCompare(b.date));
  for (const t of sorted) {
    const key = t.ticker;
    if (!positions[key]) {
      positions[key] = {
        ticker: t.ticker, company_name: t.company_name || t.ticker,
        market: t.market || 'sweden', sector: t.sector || 'Övrigt',
        currency: t.currency || 'SEK', lots: [], realizedPnl: 0,
      };
    }
    const pos = positions[key];
    if (t.type === 'BUY') {
      pos.lots.push({ shares: t.shares, price: t.price });
    } else {
      let toSell = t.shares;
      while (toSell > 0 && pos.lots.length > 0) {
        const lot = pos.lots[0];
        const sold = Math.min(toSell, lot.shares);
        pos.realizedPnl += sold * (t.price - lot.price);
        lot.shares -= sold;
        toSell -= sold;
        if (lot.shares <= 0) pos.lots.shift();
      }
    }
  }
  return Object.values(positions).map(pos => {
    const shares = pos.lots.reduce((s, l) => s + l.shares, 0);
    const totalCost = pos.lots.reduce((s, l) => s + l.shares * l.price, 0);
    return { ...pos, shares, totalCost, avgCost: shares > 0 ? totalCost / shares : 0 };
  }).filter(p => p.shares > 0.0001);
}

// Build positions from Holding records (agent-managed)
function buildPositionsFromHoldings(holdings) {
  return holdings.map(h => ({
    ticker: h.ticker,
    company_name: h.company_name || h.ticker,
    market: h.market || 'sweden',
    sector: h.sector || 'Övrigt',
    currency: h.currency || 'SEK',
    shares: h.shares,
    avgCost: h.avg_price,
    totalCost: h.shares * h.avg_price,
    realizedPnl: 0,
    source: 'holding',
    holdingId: h.id,
  }));
}

const fmt = (n) => Math.round(n).toLocaleString('sv-SE');
const fmtDec = (n, d = 2) => n.toLocaleString('sv-SE', { minimumFractionDigits: d, maximumFractionDigits: d });

export default function PortfolioPage({ marketData: parentMarketData, signals = [] }) {
  const [trades, setTrades] = useState([]);
  const [holdings, setHoldings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editTrade, setEditTrade] = useState(null);
  const [fxRates, setFxRates] = useState({ SEK: 1 });
  const [tab, setTab] = useState('overview');
  const [analysis, setAnalysis] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [watchlist, setWatchlist] = useState([]);
  const [instruments, setInstruments] = useState([]);
  const [marketData, setMarketData] = useState(() => ({ ...parentMarketData }));
  const [aiInsights, setAiInsights] = useState(null);
  const [generatingInsights, setGeneratingInsights] = useState(false);

  // Quick holding entry
  const [quickTicker, setQuickTicker] = useState('');
  const [quickShares, setQuickShares] = useState('');
  const [quickPrice, setQuickPrice] = useState('');
  const [quickCurrency, setQuickCurrency] = useState('SEK');
  const [quickName, setQuickName] = useState('');
  const [savingQuick, setSavingQuick] = useState(false);
  const [quickSource, setQuickSource] = useState('manual'); // 'manual', 'watchlist', 'universe'
  const [showQuickSelection, setShowQuickSelection] = useState(false);

  // Simulation state
  const [simTicker, setSimTicker] = useState('');
  const [simType, setSimType] = useState('BUY');
  const [simShares, setSimShares] = useState('');
  const [simPrice, setSimPrice] = useState('');
  const [simResult, setSimResult] = useState(null);

  useEffect(() => {
    Promise.all([
      Trade.list('-date', 5000),
      Trade.list(),
      Watchlist.list('-created_date', 5000),
      Instrument.list('-created_date', 5000),
      fetchFxRates(),
    ]).then(([t, h, w, i, rates]) => {
      setTrades(t);
      setHoldings(h);
      setWatchlist(w);
      setInstruments(i);
      setFxRates(rates);
      setLoading(false);
    });
  }, []);

  const refreshPortfolioPrices = useCallback(async (posToRefresh) => {
    if (!posToRefresh || !posToRefresh.length) return;
    try {
      const tickers = posToRefresh.map(p => ({
        ticker: p.ticker,
        market: p.market,
        yahooSymbol: p.ticker + (p.market === 'sweden' ? '.ST' : ''),
      }));
      
      const res = await invokeFunction('fetchMarketData', { tickers });
      const results = res.data?.results || [];
      
      // Update marketData with fresh prices
      if (results.some(r => r.ok)) {
        setMarketData(prev => {
          const updated = { ...prev };
          results.forEach(r => {
            if (r.ok) {
              const key = `${r.market}:${r.ticker}`;
              updated[key] = { ...updated[key], ...r };
            }
          });
          return updated;
        });
      }
    } catch (e) {
      console.error('Price refresh error:', e);
    }
  }, []);

  const toSEK = (amount, currency) => amount * (fxRates[currency] || 1);

  // Merge: trades-derived positions + holding positions (dedup by ticker, trades take priority)
  const tradePositions = useMemo(() => buildPositionsFromTrades(trades), [trades]);
  const holdingPositions = useMemo(() => buildPositionsFromHoldings(holdings), [holdings]);
  const tradeKeys = new Set(tradePositions.map(p => p.ticker));
  const allPositions = useMemo(() => [
    ...tradePositions,
    ...holdingPositions.filter(p => !tradeKeys.has(p.ticker)),
  ], [tradePositions, holdingPositions]);

  // Auto-refresh portfolio prices every 5 minutes
  useEffect(() => {
    const interval = setInterval(() => {
      refreshPortfolioPrices(allPositions);
    }, 5 * 60 * 1000); // 5 minutes
    
    return () => clearInterval(interval);
  }, [refreshPortfolioPrices, allPositions]);

  const enriched = allPositions.map(p => {
    const key = `${p.market}:${p.ticker}`;
    const md = marketData[key];
    const fxRate = fxRates[p.currency] || 1;
    const currentPrice = md?.price ?? null;
    const costSEK = toSEK(p.totalCost, p.currency);
    const valueNative = currentPrice != null ? currentPrice * p.shares : p.totalCost;
    const valueSEK = valueNative * fxRate;
    const pnlNative = currentPrice != null ? (currentPrice - p.avgCost) * p.shares : null;
    const pnlSEK = pnlNative != null ? pnlNative * fxRate : null;
    const pnlPct = currentPrice != null ? ((currentPrice - p.avgCost) / p.avgCost) * 100 : null;
    const realizedPnlSEK = (p.realizedPnl || 0) * fxRate;
    return { ...p, md, fxRate, currentPrice, costSEK, valueSEK, pnlNative, pnlSEK, pnlPct, realizedPnlSEK, hasLive: currentPrice != null };
  });

  const totalCostSEK  = enriched.reduce((s, h) => s + h.costSEK, 0);
  const totalValueSEK = enriched.reduce((s, h) => s + h.valueSEK, 0);
  const totalPnlSEK   = enriched.reduce((s, h) => s + (h.pnlSEK ?? 0), 0);
  const totalRealizedSEK = enriched.reduce((s, h) => s + h.realizedPnlSEK, 0);
  const pnlPctTotal   = totalCostSEK > 0 ? (totalPnlSEK / totalCostSEK) * 100 : 0;
  const liveCount     = enriched.filter(h => h.hasLive).length;

  const sectorMap = {};
  enriched.forEach(h => { const sec = h.sector || 'Övrigt'; sectorMap[sec] = (sectorMap[sec] || 0) + h.valueSEK; });
  const sectorBreakdown = Object.entries(sectorMap)
    .map(([sector, value]) => ({ sector, value, pct: totalValueSEK ? (value / totalValueSEK) * 100 : 0 }))
    .sort((a, b) => b.value - a.value);

  const runAnalysis = useCallback(async () => {
    if (!enriched.length) return;
    setAnalyzing(true);
    setAnalysis(null);
    const res = await invokeFunction('generate-signals', {
      prompt: `Du är en erfaren svensk portföljanalytiker. Analysera följande aktieportfölj på svenska.
PORTFÖLJ (${fmt(totalValueSEK)} SEK, P&L: ${totalPnlSEK >= 0 ? '+' : ''}${fmt(totalPnlSEK)} SEK):
${JSON.stringify(enriched.map(h => ({ ticker: h.ticker, valueSEK: Math.round(h.valueSEK), pnlPct: h.pnlPct?.toFixed(1), sector: h.sector })), null, 2)}
SEKTORER: ${sectorBreakdown.map(s => `${s.sector}: ${s.pct.toFixed(1)}%`).join(', ')}
Ge: sammanfattning, sektoranalys, koncentrationsrisk, diversifiering, riskprofil, 3-5 rekommendationer.`,
      response_json_schema: {
        type: 'object', properties: {
          overall_score: { type: 'number' },
          summary: { type: 'string' }, sector_analysis: { type: 'string' },
          concentration_risk: { type: 'string' }, diversification: { type: 'string' },
          risk_profile: { type: 'string', enum: ['Offensiv', 'Balanserad', 'Defensiv'] },
          recommendations: { type: 'array', items: { type: 'object', properties: { priority: { type: 'string', enum: ['Hög', 'Medium', 'Låg'] }, action: { type: 'string' }, reason: { type: 'string' } } } },
        }
      }
    });
    setAnalysis(res);
    setAnalyzing(false);
  }, [enriched.length, totalValueSEK, totalPnlSEK]);

  const generateAdvancedInsights = useCallback(async () => {
    if (!enriched.length) return;
    setGeneratingInsights(true);
    setAiInsights(null);
    const res = await invokeFunction('generate-signals', {
      prompt: `Du är en avancerad portföljoptimeringexpert. Analysera denna portfölj och ge djupa insikter på svenska:

PORTFÖLJ (${fmt(totalValueSEK)} SEK):
${JSON.stringify(enriched.map(h => ({ ticker: h.ticker, shares: h.shares, avgCost: h.avgCost, currentPrice: h.currentPrice, valueSEK: Math.round(h.valueSEK), pnlPct: h.pnlPct?.toFixed(1), sector: h.sector, weight: ((h.valueSEK/totalValueSEK)*100).toFixed(1) })), null, 2)}

SEKTORER: ${sectorBreakdown.map(s => `${s.sector}: ${s.pct.toFixed(1)}%`).join(', ')}
Totalt P&L: ${pnlPctTotal.toFixed(2)}%

Ge MYCKET SPECIFIKA insikter för:
1. Predictive scenarios - 2-3 möjliga prisscenarier (upp/ned) för nästa 3-6 mån för top 3 innehav med konkreta prismål
2. Rebalancing - exakt vilka aktier att sälja/köpa för att optimera risk-belöning baserat på sektorvikt
3. Alerts - vilka sektorer är överexponerade (>25%) eller underexponerade (<5%), specifika risker per position, underperformare`,
      response_json_schema: {
        type: 'object',
        properties: {
          price_scenarios: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                ticker: { type: 'string' },
                current_price: { type: 'number' },
                bullish_target: { type: 'number' },
                bearish_target: { type: 'number' },
                bullish_reason: { type: 'string' },
                bearish_reason: { type: 'string' },
                timeframe_months: { type: 'number' }
              }
            }
          },
          rebalancing_strategy: {
            type: 'object',
            properties: {
              summary: { type: 'string' },
              actions: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    action: { type: 'string' },
                    ticker: { type: 'string' },
                    reason: { type: 'string' },
                    impact: { type: 'string' }
                  }
                }
              }
            }
          },
          sector_alerts: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                sector: { type: 'string' },
                current_weight: { type: 'number' },
                status: { type: 'string', enum: ['overexposed', 'underexposed', 'balanced'] },
                risk: { type: 'string' },
                recommendation: { type: 'string' }
              }
            }
          },
          position_alerts: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                ticker: { type: 'string' },
                alert_type: { type: 'string' },
                message: { type: 'string' },
                action: { type: 'string' }
              }
            }
          }
        }
      }
    });
    setAiInsights(res);
    setGeneratingInsights(false);
  }, [enriched, totalValueSEK, sectorBreakdown, pnlPctTotal]);

  // Auto-run analysis on load
  useEffect(() => {
    if (loading || enriched.length === 0) return;
    const t = setTimeout(() => runAnalysis(), 800);
    return () => clearTimeout(t);
  }, [loading, enriched.length]);

  const handleSaveTrade = async (data) => {
    if (editTrade) {
      const updated = await Trade.update(editTrade.id, data);
      setTrades(prev => prev.map(t => t.id === editTrade.id ? updated : t));
    } else {
      const created = await Trade.create(data);
      setTrades(prev => [...prev, created]);
    }
    setShowForm(false);
    setEditTrade(null);
  };

  const handleEdit = (t) => { setEditTrade(t); setShowForm(true); };
  const handleDelete = async (id) => {
    await Trade.delete(id);
    setTrades(prev => prev.filter(t => t.id !== id));
  };
  const handleDeleteHolding = async (id) => {
    await Trade.delete(id);
    setHoldings(prev => prev.filter(h => h.id !== id));
  };

  const handleQuickAdd = async () => {
    if (!quickTicker || !quickShares || !quickPrice) return;
    setSavingQuick(true);
    const holding = await Trade.create({
      ticker: quickTicker.toUpperCase(),
      company_name: quickName || quickTicker.toUpperCase(),
      shares: +quickShares,
      avg_price: +quickPrice,
      currency: quickCurrency,
      market: 'sweden',
    });
    setHoldings(prev => [...prev, holding]);
    setQuickTicker(''); setQuickShares(''); setQuickPrice(''); setQuickName('');
    setSavingQuick(false);
  };

  // Simulate a scenario
  const runSimulation = () => {
    if (!simTicker || !simShares || !simPrice) return;
    const shares = +simShares;
    const price = +simPrice;
    const existing = enriched.find(h => h.ticker.toUpperCase() === simTicker.toUpperCase());
    const currency = existing?.currency || 'SEK';
    const fxRate = fxRates[currency] || 1;
    const tradeValueSEK = shares * price * fxRate;

    let newTotalCostSEK = totalCostSEK;
    let newTotalValueSEK = totalValueSEK;
    let newPositionValueSEK = 0;
    let newPositionCostSEK = 0;
    let newAvgCost = price;
    let newShares = shares;

    if (simType === 'BUY') {
      newTotalCostSEK += tradeValueSEK;
      // Use live price if available, else use sim price as estimate
      const livePrice = existing?.currentPrice ?? price;
      const addedValueSEK = shares * livePrice * fxRate;
      newTotalValueSEK += addedValueSEK;

      if (existing) {
        newShares = existing.shares + shares;
        newPositionCostSEK = existing.costSEK + tradeValueSEK;
        newAvgCost = (existing.totalCost + shares * price) / newShares;
        newPositionValueSEK = newShares * (existing.currentPrice ?? price) * fxRate;
      } else {
        newPositionCostSEK = tradeValueSEK;
        newPositionValueSEK = shares * price * fxRate;
      }
    } else {
      // SELL: only if we have position
      if (!existing || shares > existing.shares) {
        setSimResult({ error: `Kan inte sälja ${shares} aktier — innehar ${existing?.shares ?? 0}` });
        return;
      }
      newShares = existing.shares - shares;
      const sellValueSEK = shares * (existing.currentPrice ?? price) * fxRate;
      newTotalValueSEK -= sellValueSEK;
      newTotalCostSEK -= shares * existing.avgCost * fxRate;
      newPositionCostSEK = newShares * existing.avgCost * fxRate;
      newPositionValueSEK = newShares * (existing.currentPrice ?? price) * fxRate;
      newAvgCost = existing.avgCost;
    }

    const newPnlSEK = newTotalValueSEK - newTotalCostSEK;
    const newPnlPct = newTotalCostSEK > 0 ? (newPnlSEK / newTotalCostSEK) * 100 : 0;
    const newWeight = newTotalValueSEK > 0 ? (newPositionValueSEK / newTotalValueSEK) * 100 : 0;

    setSimResult({
      ticker: simTicker.toUpperCase(), type: simType, shares, price, currency,
      tradeValueSEK,
      newShares,
      newAvgCost,
      newPositionValueSEK,
      newPositionCostSEK,
      newPositionPnlSEK: newPositionValueSEK - newPositionCostSEK,
      newTotalValueSEK,
      newTotalCostSEK,
      newPnlSEK,
      newPnlPct,
      newWeight,
      deltaValueSEK: newTotalValueSEK - totalValueSEK,
      deltaPnlPct: newPnlPct - pnlPctTotal,
    });
  };

  const tabStyle = (id) => ({
    padding: '6px 14px', borderRadius: 5, cursor: 'pointer', fontSize: 12, fontWeight: 600,
    border: tab === id ? '1px solid rgba(62,207,255,0.3)' : '1px solid #253649',
    background: tab === id ? 'rgba(62,207,255,0.07)' : 'transparent',
    color: tab === id ? '#3ecfff' : '#5a7a94',
  });

  const inputStyle = {
    background: '#0d1219', border: '1px solid #253649', borderRadius: 6,
    color: '#dce8f5', padding: '7px 10px', fontSize: 12, outline: 'none', width: '100%',
  };

  return (
    <div style={{ padding: 24 }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 18 }}>
        <div>
          <div style={{ fontSize: 22, fontWeight: 800 }}>Portfölj</div>
          <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', marginTop: 3 }}>
            {enriched.length} aktiva positioner
            {trades.length > 0 && <span style={{ marginLeft: 8 }}>({trades.length} transaktioner)</span>}
            {holdings.length > 0 && <span style={{ color: '#9b59b6', marginLeft: 8 }}>+ {holdingPositions.filter(p => !tradeKeys.has(p.ticker)).length} agent-innehav</span>}
            {liveCount > 0 && <span style={{ color: '#2ecc71', marginLeft: 8 }}>● {liveCount} live</span>}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          {[
            { id: 'overview', label: 'Översikt' },
            { id: 'recommendations', label: `⚡ Råd${signals.filter(s => s.status === 'APPROVED').length > 0 ? ` (${signals.filter(s => s.status === 'APPROVED').length})` : ''}` },
            { id: 'simulate', label: '⚗ Simulera' },
            { id: 'ai_insights', label: '🔮 AI-insikter' },
            { id: 'history', label: 'Historik' },
          ].map(({ id, label }) => (
            <button key={id} style={tabStyle(id)} onClick={() => setTab(id)}>{label}</button>
          ))}
          <button onClick={() => { if (tab === 'ai_insights') generateAdvancedInsights(); else runAnalysis(); }} disabled={(tab === 'ai_insights' ? generatingInsights : analyzing) || !enriched.length} style={{
            background: 'rgba(62,207,255,0.1)', border: '1px solid rgba(62,207,255,0.3)',
            color: '#3ecfff', padding: '6px 14px', borderRadius: 5, cursor: 'pointer', fontSize: 12, fontWeight: 700,
            opacity: (tab === 'ai_insights' ? generatingInsights : analyzing) || !enriched.length ? 0.5 : 1,
          }}>
            {(tab === 'ai_insights' ? generatingInsights : analyzing) ? '⏳ …' : '✦ AI'}
          </button>
          <button onClick={() => { setShowForm(s => !s); setEditTrade(null); }} style={{
            background: '#3ecfff', border: 'none', color: '#080c10', padding: '6px 14px', borderRadius: 5, cursor: 'pointer', fontSize: 12, fontWeight: 700,
          }}>+ Transaktion</button>
        </div>
      </div>

      {showForm && (
        <TradeForm trade={editTrade} onSave={handleSaveTrade} onCancel={() => { setShowForm(false); setEditTrade(null); }} />
      )}

      {/* Quick holding entry */}
      <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, padding: '14px 18px', marginBottom: 18 }}>
        <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 10 }}>
          Snabbt lägg till innehav
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end', marginBottom: 10 }}>
          {['manual', 'watchlist', 'universe'].map(src => (
            <button key={src} onClick={() => setQuickSource(src)} style={{
              padding: '5px 12px', borderRadius: 4, cursor: 'pointer', fontSize: 10, fontWeight: 600,
              border: quickSource === src ? '1px solid rgba(62,207,255,0.4)' : '1px solid #253649',
              background: quickSource === src ? 'rgba(62,207,255,0.08)' : 'transparent',
              color: quickSource === src ? '#3ecfff' : '#5a7a94',
            }}>
              {src === 'manual' ? 'Manuell' : src === 'watchlist' ? 'Från Bevakningslista' : 'Från Universum'}
            </button>
          ))}
        </div>
        {quickSource !== 'manual' && (
          <div style={{ marginBottom: 12, display: 'grid', gridTemplateColumns: quickSource === 'watchlist' ? '1fr 1fr 1fr 1fr auto' : '1fr 1fr 1fr 1fr auto', gap: 8 }}>
            {quickSource === 'watchlist' ? (
              <>
                <select onChange={(e) => {
                  const w = watchlist.find(item => item.ticker === e.target.value);
                  if (w) {
                    setQuickTicker(w.ticker);
                    setQuickName(w.company_name);
                    setQuickCurrency(w.currency || 'SEK');
                  }
                }} style={{ background: '#131b24', border: '1px solid #253649', borderRadius: 6, color: '#dce8f5', padding: '7px 10px', fontSize: 12, outline: 'none' }}>
                  <option value="">Välj från bevakningslista...</option>
                  {watchlist.map(w => <option key={w.id} value={w.ticker}>{w.ticker} — {w.company_name}</option>)}
                </select>
                <input type="number" placeholder="Antal aktier" value={quickShares} onChange={e => setQuickShares(e.target.value)} style={{ background: '#131b24', border: '1px solid #253649', borderRadius: 6, color: '#dce8f5', padding: '7px 10px', fontSize: 12, outline: 'none' }} />
                <input type="number" placeholder="Inköpspris" value={quickPrice} onChange={e => setQuickPrice(e.target.value)} style={{ background: '#131b24', border: '1px solid #253649', borderRadius: 6, color: '#dce8f5', padding: '7px 10px', fontSize: 12, outline: 'none' }} />
                <select value={quickCurrency} onChange={e => setQuickCurrency(e.target.value)} style={{ background: '#131b24', border: '1px solid #253649', borderRadius: 6, color: '#dce8f5', padding: '7px 10px', fontSize: 12 }}>
                  {['SEK', 'USD', 'EUR', 'GBP'].map(c => <option key={c} value={c}>{c}</option>)}
                </select>
                <button onClick={handleQuickAdd} disabled={savingQuick || !quickTicker || !quickShares || !quickPrice} style={{
                  background: savingQuick ? '#1a2535' : 'rgba(46,204,113,0.12)', border: '1px solid rgba(46,204,113,0.3)',
                  color: '#2ecc71', padding: '7px 16px', borderRadius: 6, cursor: 'pointer', fontSize: 12, fontWeight: 700,
                  opacity: !quickTicker || !quickShares || !quickPrice ? 0.5 : 1,
                }}>
                  {savingQuick ? '…' : '+ Lägg till'}
                </button>
              </>
            ) : (
              <>
                <select onChange={(e) => {
                  const inst = instruments.find(item => item.ticker === e.target.value);
                  if (inst) {
                    setQuickTicker(inst.ticker);
                    setQuickName(inst.company_name);
                    setQuickCurrency(inst.currency || 'SEK');
                  }
                }} style={{ background: '#131b24', border: '1px solid #253649', borderRadius: 6, color: '#dce8f5', padding: '7px 10px', fontSize: 12, outline: 'none' }}>
                  <option value="">Välj från universum...</option>
                  {instruments.map(i => <option key={i.ticker} value={i.ticker}>{i.ticker} — {i.company_name}</option>)}
                </select>
                <input type="number" placeholder="Antal aktier" value={quickShares} onChange={e => setQuickShares(e.target.value)} style={{ background: '#131b24', border: '1px solid #253649', borderRadius: 6, color: '#dce8f5', padding: '7px 10px', fontSize: 12, outline: 'none' }} />
                <input type="number" placeholder="Inköpspris" value={quickPrice} onChange={e => setQuickPrice(e.target.value)} style={{ background: '#131b24', border: '1px solid #253649', borderRadius: 6, color: '#dce8f5', padding: '7px 10px', fontSize: 12, outline: 'none' }} />
                <select value={quickCurrency} onChange={e => setQuickCurrency(e.target.value)} style={{ background: '#131b24', border: '1px solid #253649', borderRadius: 6, color: '#dce8f5', padding: '7px 10px', fontSize: 12 }}>
                  {['SEK', 'USD', 'EUR', 'GBP'].map(c => <option key={c} value={c}>{c}</option>)}
                </select>
                <button onClick={handleQuickAdd} disabled={savingQuick || !quickTicker || !quickShares || !quickPrice} style={{
                  background: savingQuick ? '#1a2535' : 'rgba(46,204,113,0.12)', border: '1px solid rgba(46,204,113,0.3)',
                  color: '#2ecc71', padding: '7px 16px', borderRadius: 6, cursor: 'pointer', fontSize: 12, fontWeight: 700,
                  opacity: !quickTicker || !quickShares || !quickPrice ? 0.5 : 1,
                }}>
                  {savingQuick ? '…' : '+ Lägg till'}
                </button>
              </>
            )}
          </div>
        )}
        {quickSource === 'manual' && (
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            {[
              { placeholder: 'Ticker (ex. ERIC-B)', value: quickTicker, onChange: setQuickTicker, width: 130 },
              { placeholder: 'Bolagsnamn (valfritt)', value: quickName, onChange: setQuickName, width: 170 },
              { placeholder: 'Antal aktier', value: quickShares, onChange: setQuickShares, type: 'number', width: 110 },
              { placeholder: 'Inköpspris', value: quickPrice, onChange: setQuickPrice, type: 'number', width: 110 },
            ].map((f, i) => (
              <input key={i} type={f.type || 'text'} placeholder={f.placeholder} value={f.value}
                onChange={e => f.onChange(e.target.value)}
                style={{ background: '#131b24', border: '1px solid #253649', borderRadius: 6, color: '#dce8f5', padding: '7px 10px', fontSize: 12, outline: 'none', width: f.width }}
              />
            ))}
            <select value={quickCurrency} onChange={e => setQuickCurrency(e.target.value)}
              style={{ background: '#131b24', border: '1px solid #253649', borderRadius: 6, color: '#dce8f5', padding: '7px 10px', fontSize: 12 }}>
              {['SEK', 'USD', 'EUR', 'GBP'].map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <button onClick={handleQuickAdd} disabled={savingQuick || !quickTicker || !quickShares || !quickPrice} style={{
              background: savingQuick ? '#1a2535' : 'rgba(46,204,113,0.12)', border: '1px solid rgba(46,204,113,0.3)',
              color: '#2ecc71', padding: '7px 16px', borderRadius: 6, cursor: 'pointer', fontSize: 12, fontWeight: 700,
              opacity: !quickTicker || !quickShares || !quickPrice ? 0.5 : 1,
            }}>
              {savingQuick ? '…' : '+ Lägg till'}
            </button>
          </div>
        )}
      </div>

      {loading ? (
        <div style={{ padding: 60, textAlign: 'center', color: '#5a7a94', fontFamily: 'monospace' }}>Laddar…</div>
      ) : enriched.length === 0 ? (
        <div style={{ padding: 60, textAlign: 'center', color: '#3d5a72', fontFamily: 'monospace', fontSize: 13 }}>
          <div style={{ fontSize: 28, marginBottom: 8 }}>📊</div>
          Inga innehav ännu — lägg till transaktioner eller använd AI-agenten
        </div>
      ) : (
        <>
          {/* Summary stats bar */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, overflow: 'hidden', marginBottom: 18 }}>
            {[
              { label: 'Investerat', value: `${fmt(totalCostSEK)} SEK`, color: '#5a7a94', sub: 'Totalt inköpsvärde' },
              { label: 'Dagsvärde', value: `${fmt(totalValueSEK)} SEK`, color: '#dce8f5', sub: liveCount > 0 ? `${liveCount} live-kurser` : 'Senast kända' },
              { label: 'Orealiserad P&L', value: `${totalPnlSEK >= 0 ? '+' : ''}${fmt(totalPnlSEK)} SEK`, color: totalPnlSEK >= 0 ? '#2ecc71' : '#e74c3c', sub: 'Öppna positioner' },
              { label: 'Realiserad P&L', value: `${totalRealizedSEK >= 0 ? '+' : ''}${fmt(totalRealizedSEK)} SEK`, color: totalRealizedSEK >= 0 ? '#2ecc71' : '#e74c3c', sub: 'Stängda affärer' },
              { label: 'Avkastning', value: `${pnlPctTotal >= 0 ? '+' : ''}${pnlPctTotal.toFixed(2)}%`, color: pnlPctTotal >= 0 ? '#2ecc71' : '#e74c3c', sub: 'Sedan köp' },
              { label: 'Positioner', value: enriched.length, color: '#3ecfff', sub: `${trades.length} trades` },
            ].map((s, i) => (
              <div key={i} style={{ padding: '12px 14px', borderRight: i < 5 ? '1px solid #1e2d3d' : 'none' }}>
                <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 5 }}>{s.label}</div>
                <div style={{ fontFamily: 'monospace', fontSize: 14, fontWeight: 700, color: s.color }}>{s.value}</div>
                <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', marginTop: 3 }}>{s.sub}</div>
              </div>
            ))}
          </div>

          {/* OVERVIEW TAB */}
          {tab === 'overview' && (
            <>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 18 }}>
                {[...enriched].sort((a, b) => b.valueSEK - a.valueSEK).map(h => {
                  const portfolioPct = totalValueSEK ? (h.valueSEK / totalValueSEK) * 100 : 0;
                  const pnlColor = h.pnlSEK == null ? '#5a7a94' : h.pnlSEK >= 0 ? '#2ecc71' : '#e74c3c';
                  const isHolding = !!h.holdingId;
                  return (
                    <div key={h.ticker} style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 10, padding: '14px 18px' }}>
                      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>

                        {/* Identity */}
                        <div style={{ minWidth: 120 }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                            <span style={{ fontFamily: 'monospace', fontWeight: 800, fontSize: 15 }}>{h.ticker}</span>
                            {h.hasLive && <span style={{ fontFamily: 'monospace', fontSize: 9, color: '#2ecc71' }}>● LIVE</span>}
                            {isHolding && <span style={{ fontFamily: 'monospace', fontSize: 9, color: '#9b59b6' }}>AI</span>}
                          </div>
                          <div style={{ fontSize: 11, color: '#5a7a94', marginTop: 2, maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{h.company_name}</div>
                          <span style={{ fontFamily: 'monospace', fontSize: 9, padding: '2px 5px', borderRadius: 3, marginTop: 5, display: 'inline-block', background: `${SECTOR_COLORS[h.sector] || '#5a7a94'}22`, color: SECTOR_COLORS[h.sector] || '#5a7a94', textTransform: 'uppercase' }}>
                            {h.sector || 'Övrigt'}
                          </span>
                        </div>

                        {/* Inköpsdata */}
                        <div style={{ flex: 1, display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', background: '#080c10', borderRadius: 8, border: '1px solid #1e2d3d', overflow: 'hidden' }}>
                          {[
                            { label: 'Antal', value: h.shares % 1 === 0 ? h.shares : fmtDec(h.shares), sub: 'aktier' },
                            { label: 'Snittköp', value: fmtDec(h.avgCost), sub: h.currency },
                            { label: 'Inköpsvärde', value: fmt(h.costSEK), sub: 'SEK' },
                          ].map((c, i) => (
                            <div key={i} style={{ padding: '10px 14px', borderRight: i < 2 ? '1px solid #1e2d3d' : 'none' }}>
                              <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 4 }}>{c.label}</div>
                              <div style={{ fontFamily: 'monospace', fontSize: 13, fontWeight: 700, color: '#dce8f5' }}>{c.value}</div>
                              <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', marginTop: 2 }}>{c.sub}</div>
                            </div>
                          ))}
                        </div>

                        {/* Dagsvärde + P&L */}
                        <div style={{ flex: 1, display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', background: '#080c10', borderRadius: 8, overflow: 'hidden', border: `1px solid ${h.pnlSEK == null ? '#1e2d3d' : h.pnlSEK >= 0 ? 'rgba(46,204,113,0.2)' : 'rgba(231,76,60,0.2)'}` }}>
                          {[
                            { label: 'Dagskurs', value: h.hasLive ? fmtDec(h.currentPrice) : '—', sub: h.hasLive ? h.currency : 'Hämta data', color: '#dce8f5' },
                            { label: 'Dagsvärde', value: fmt(h.valueSEK), sub: 'SEK', color: '#dce8f5' },
                            { label: 'Vinst / Förlust', value: h.pnlSEK != null ? `${h.pnlSEK >= 0 ? '+' : ''}${fmt(h.pnlSEK)} SEK` : '—', sub: h.pnlPct != null ? `${h.pnlPct >= 0 ? '+' : ''}${fmtDec(h.pnlPct)}%` : '—', color: pnlColor },
                          ].map((c, i) => (
                            <div key={i} style={{ padding: '10px 14px', borderRight: i < 2 ? '1px solid #1e2d3d' : 'none' }}>
                              <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 4 }}>{c.label}</div>
                              <div style={{ fontFamily: 'monospace', fontSize: 13, fontWeight: 700, color: c.color }}>{c.value}</div>
                              <div style={{ fontFamily: 'monospace', fontSize: 9, color: i === 2 ? pnlColor : '#3d5a72', marginTop: 2, fontWeight: i === 2 ? 700 : 400 }}>{c.sub}</div>
                            </div>
                          ))}
                        </div>

                        {/* Weight + delete */}
                        <div style={{ minWidth: 65, textAlign: 'right' }}>
                          <div style={{ fontFamily: 'monospace', fontSize: 12, fontWeight: 700, color: portfolioPct > 20 ? '#f1c40f' : '#5a7a94' }}>{fmtDec(portfolioPct, 1)}%</div>
                          <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', marginBottom: 6 }}>portfölj</div>
                          <div style={{ height: 3, background: '#1e2d3d', borderRadius: 2 }}>
                            <div style={{ height: '100%', width: `${Math.min(portfolioPct, 100)}%`, background: portfolioPct > 20 ? '#f1c40f' : '#3ecfff', borderRadius: 2 }} />
                          </div>
                          <button onClick={() => isHolding ? handleDeleteHolding(h.holdingId) : handleDelete(trades.find(t => t.ticker === h.ticker)?.id)} style={{ marginTop: 8, background: 'rgba(231,76,60,0.07)', border: '1px solid rgba(231,76,60,0.15)', color: '#e74c3c', padding: '2px 7px', borderRadius: 4, cursor: 'pointer', fontSize: 9 }}>✕</button>
                        </div>
                      </div>
                      {h.realizedPnlSEK !== 0 && (
                        <div style={{ marginTop: 10, paddingTop: 10, borderTop: '1px solid #1e2d3d', fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>
                          Realiserad: <span style={{ color: h.realizedPnlSEK >= 0 ? '#2ecc71' : '#e74c3c', fontWeight: 700 }}>{h.realizedPnlSEK >= 0 ? '+' : ''}{fmt(h.realizedPnlSEK)} SEK</span>
                          {h.md?.rsi && <span style={{ marginLeft: 14 }}>RSI: <span style={{ color: h.md.rsi > 70 ? '#e74c3c' : h.md.rsi < 30 ? '#2ecc71' : '#dce8f5' }}>{h.md.rsi.toFixed(0)}</span></span>}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Charts */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 260px', gap: 14, marginBottom: 18 }}>
                <PnLBarChart enriched={enriched} />
                <AllocationPieChart enriched={enriched} totalValueSEK={totalValueSEK} />
                <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, padding: 16 }}>
                  <div style={{ fontFamily: 'monospace', fontSize: 10, letterSpacing: 1.5, color: '#3d5a72', textTransform: 'uppercase', marginBottom: 12 }}>Sektorfördelning</div>
                  {sectorBreakdown.map(s => (
                    <div key={s.sector} style={{ marginBottom: 9 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
                        <span style={{ fontSize: 11, color: '#dce8f5' }}>{s.sector}</span>
                        <span style={{ fontFamily: 'monospace', fontSize: 11, color: SECTOR_COLORS[s.sector] || '#5a7a94' }}>{s.pct.toFixed(1)}%</span>
                      </div>
                      <div style={{ height: 4, background: '#1e2d3d', borderRadius: 2 }}>
                        <div style={{ height: '100%', width: `${s.pct}%`, background: SECTOR_COLORS[s.sector] || '#5a7a94', borderRadius: 2 }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* AI Analysis */}
              {analyzing && (
                <div style={{ padding: 20, textAlign: 'center', color: '#5a7a94', fontFamily: 'monospace', fontSize: 12, border: '1px solid #1e2d3d', borderRadius: 9 }}>
                  ⏳ AI analyserar portföljen…
                </div>
              )}
              {analysis && !analyzing && (
                <div style={{ background: '#0d1219', border: '1px solid rgba(62,207,255,0.2)', borderRadius: 10, padding: 22 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
                    <div style={{ fontWeight: 800, fontSize: 15 }}>✦ AI-portföljanalys</div>
                    <span style={{ fontFamily: 'monospace', fontSize: 11, padding: '3px 10px', borderRadius: 20, background: analysis.overall_score >= 7 ? 'rgba(46,204,113,0.15)' : analysis.overall_score >= 5 ? 'rgba(241,196,15,0.15)' : 'rgba(231,76,60,0.15)', color: analysis.overall_score >= 7 ? '#2ecc71' : analysis.overall_score >= 5 ? '#f1c40f' : '#e74c3c' }}>Betyg: {analysis.overall_score}/10</span>
                    <span style={{ fontFamily: 'monospace', fontSize: 11, padding: '3px 10px', borderRadius: 20, background: 'rgba(62,207,255,0.08)', color: '#3ecfff' }}>{analysis.risk_profile}</span>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(240px,1fr))', gap: 12, marginBottom: 14 }}>
                    {[{ label: 'Sammanfattning', c: analysis.summary, icon: '📊' }, { label: 'Sektorer', c: analysis.sector_analysis, icon: '🏭' }, { label: 'Koncentrationsrisk', c: analysis.concentration_risk, icon: '⚠️' }, { label: 'Diversifiering', c: analysis.diversification, icon: '🌍' }].map(card => (
                      <div key={card.label} style={{ background: '#131b24', border: '1px solid #1e2d3d', borderRadius: 8, padding: 13 }}>
                        <div style={{ fontFamily: 'monospace', fontSize: 9, letterSpacing: 1.5, color: '#3d5a72', textTransform: 'uppercase', marginBottom: 7 }}>{card.icon} {card.label}</div>
                        <div style={{ fontSize: 12, color: '#dce8f5', lineHeight: 1.6 }}>{card.c}</div>
                      </div>
                    ))}
                  </div>
                  {analysis.recommendations?.length > 0 && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
                      {analysis.recommendations.map((r, i) => {
                        const pc = r.priority === 'Hög' ? '#e74c3c' : r.priority === 'Medium' ? '#f1c40f' : '#2ecc71';
                        return (
                          <div key={i} style={{ display: 'flex', gap: 12, background: '#131b24', border: '1px solid #1e2d3d', borderRadius: 8, padding: '11px 14px', alignItems: 'flex-start' }}>
                            <span style={{ fontFamily: 'monospace', fontSize: 9, padding: '2px 7px', borderRadius: 10, background: `${pc}18`, color: pc, border: `1px solid ${pc}44`, whiteSpace: 'nowrap' }}>{r.priority}</span>
                            <div>
                              <div style={{ fontSize: 12, fontWeight: 600, color: '#dce8f5', marginBottom: 3 }}>{r.action}</div>
                              <div style={{ fontSize: 11, color: '#5a7a94' }}>{r.reason}</div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </>
          )}

          {/* RECOMMENDATIONS TAB */}
          {tab === 'recommendations' && (
            <PortfolioRecommendations enriched={enriched} signals={signals} totalValueSEK={totalValueSEK} sectorBreakdown={sectorBreakdown} />
          )}

          {/* SIMULATE TAB */}
          {tab === 'simulate' && (
            <div>
              <div style={{ background: '#0d1219', border: '1px solid #253649', borderRadius: 10, padding: 20, marginBottom: 18 }}>
                <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 4 }}>⚗ Scenariosimulering</div>
                <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', marginBottom: 18 }}>Testa hur ett hypotetiskt köp eller sälj påverkar din portfölj utan att faktiskt utföra affären.</div>

                <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
                  {['BUY', 'SELL'].map(t => (
                    <button key={t} onClick={() => setSimType(t)} style={{
                      padding: '6px 18px', borderRadius: 5, cursor: 'pointer', fontWeight: 700, fontSize: 11,
                      border: simType === t ? `1px solid ${t === 'BUY' ? 'rgba(46,204,113,0.5)' : 'rgba(231,76,60,0.5)'}` : '1px solid #253649',
                      background: simType === t ? (t === 'BUY' ? 'rgba(46,204,113,0.12)' : 'rgba(231,76,60,0.12)') : 'transparent',
                      color: simType === t ? (t === 'BUY' ? '#2ecc71' : '#e74c3c') : '#5a7a94',
                    }}>
                      {t === 'BUY' ? '▲ KÖP' : '▼ SÄLJ'}
                    </button>
                  ))}
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr auto', gap: 12, alignItems: 'end' }}>
                  <div>
                    <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94', marginBottom: 4, letterSpacing: 1, textTransform: 'uppercase' }}>Ticker</div>
                    <input
                      list="sim-tickers"
                      type="text" placeholder="ERIC-B" value={simTicker}
                      onChange={e => setSimTicker(e.target.value)}
                      style={inputStyle}
                    />
                    <datalist id="sim-tickers">
                      {enriched.map(h => <option key={h.ticker} value={h.ticker}>{h.company_name}</option>)}
                    </datalist>
                  </div>
                  <div>
                    <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94', marginBottom: 4, letterSpacing: 1, textTransform: 'uppercase' }}>Antal aktier</div>
                    <input type="number" placeholder="100" value={simShares} onChange={e => setSimShares(e.target.value)} style={inputStyle} />
                  </div>
                  <div>
                    <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94', marginBottom: 4, letterSpacing: 1, textTransform: 'uppercase' }}>Pris per aktie</div>
                    <input type="number" placeholder="85.50" value={simPrice} onChange={e => setSimPrice(e.target.value)} style={inputStyle} />
                  </div>
                  <button onClick={runSimulation} style={{
                    background: simType === 'BUY' ? 'rgba(46,204,113,0.15)' : 'rgba(231,76,60,0.15)',
                    border: `1px solid ${simType === 'BUY' ? 'rgba(46,204,113,0.4)' : 'rgba(231,76,60,0.4)'}`,
                    color: simType === 'BUY' ? '#2ecc71' : '#e74c3c',
                    padding: '8px 18px', borderRadius: 6, cursor: 'pointer', fontWeight: 700, fontSize: 12,
                  }}>Simulera</button>
                </div>
              </div>

              {/* Sim Result */}
              {simResult && (
                simResult.error ? (
                  <div style={{ background: 'rgba(231,76,60,0.08)', border: '1px solid rgba(231,76,60,0.25)', borderRadius: 9, padding: 18, color: '#e74c3c', fontFamily: 'monospace', fontSize: 12 }}>
                    ⚠ {simResult.error}
                  </div>
                ) : (
                  <div style={{ background: '#0d1219', border: `1px solid ${simResult.newPnlPct >= pnlPctTotal ? 'rgba(46,204,113,0.2)' : 'rgba(231,76,60,0.2)'}`, borderRadius: 10, padding: 22 }}>
                    <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 18 }}>
                      Resultat: {simResult.type === 'BUY' ? '▲ Köp' : '▼ Sälj'} {simResult.shares} × {simResult.ticker} @ {fmtDec(simResult.price)} {simResult.currency}
                    </div>

                    {/* Before / After */}
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 18 }}>
                      {[
                        { label: 'NULÄGE', values: [
                          { l: 'Portföljvärde', v: `${fmt(totalValueSEK)} SEK`, c: '#dce8f5' },
                          { l: 'Orealiserad P&L', v: `${totalPnlSEK >= 0 ? '+' : ''}${fmt(totalPnlSEK)} SEK`, c: totalPnlSEK >= 0 ? '#2ecc71' : '#e74c3c' },
                          { l: 'Avkastning', v: `${pnlPctTotal >= 0 ? '+' : ''}${fmtDec(pnlPctTotal)}%`, c: pnlPctTotal >= 0 ? '#2ecc71' : '#e74c3c' },
                        ]},
                        { label: 'EFTER SCENARIOT', values: [
                          { l: 'Portföljvärde', v: `${fmt(simResult.newTotalValueSEK)} SEK`, c: '#dce8f5' },
                          { l: 'Orealiserad P&L', v: `${simResult.newPnlSEK >= 0 ? '+' : ''}${fmt(simResult.newPnlSEK)} SEK`, c: simResult.newPnlSEK >= 0 ? '#2ecc71' : '#e74c3c' },
                          { l: 'Avkastning', v: `${simResult.newPnlPct >= 0 ? '+' : ''}${fmtDec(simResult.newPnlPct)}%`, c: simResult.newPnlPct >= 0 ? '#2ecc71' : '#e74c3c' },
                        ]},
                      ].map(col => (
                        <div key={col.label} style={{ background: '#131b24', border: '1px solid #1e2d3d', borderRadius: 8, padding: 16 }}>
                          <div style={{ fontFamily: 'monospace', fontSize: 9, letterSpacing: 1.5, color: '#3d5a72', textTransform: 'uppercase', marginBottom: 12 }}>{col.label}</div>
                          {col.values.map(r => (
                            <div key={r.l} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                              <span style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94' }}>{r.l}</span>
                              <span style={{ fontFamily: 'monospace', fontSize: 12, fontWeight: 700, color: r.c }}>{r.v}</span>
                            </div>
                          ))}
                        </div>
                      ))}
                    </div>

                    {/* Delta summary */}
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
                      {[
                        { label: 'Förändring värde', value: `${simResult.deltaValueSEK >= 0 ? '+' : ''}${fmt(simResult.deltaValueSEK)} SEK`, color: simResult.deltaValueSEK >= 0 ? '#2ecc71' : '#e74c3c' },
                        { label: 'Förändring avkastning', value: `${simResult.deltaPnlPct >= 0 ? '+' : ''}${fmtDec(simResult.deltaPnlPct)}%`, color: simResult.deltaPnlPct >= 0 ? '#2ecc71' : '#e74c3c' },
                        { label: simResult.type === 'BUY' ? 'Nytt snittköp' : 'Snittköp', value: `${fmtDec(simResult.newAvgCost)} ${simResult.currency}`, color: '#dce8f5' },
                        { label: 'Ny portföljvikt', value: `${fmtDec(simResult.newWeight, 1)}%`, color: simResult.newWeight > 20 ? '#f1c40f' : '#3ecfff' },
                      ].map((s, i) => (
                        <div key={i} style={{ background: '#131b24', border: '1px solid #1e2d3d', borderRadius: 8, padding: '12px 14px', textAlign: 'center' }}>
                          <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 6 }}>{s.label}</div>
                          <div style={{ fontFamily: 'monospace', fontSize: 15, fontWeight: 700, color: s.color }}>{s.value}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )
              )}
            </div>
          )}

          {/* AI INSIGHTS TAB */}
          {tab === 'ai_insights' && (
            <div>
              {generatingInsights && (
                <div style={{ padding: 40, textAlign: 'center', color: '#5a7a94', fontFamily: 'monospace', fontSize: 12, border: '1px solid #1e2d3d', borderRadius: 9 }}>
                  ⏳ Genererar avancerade AI-insikter…
                </div>
              )}
              {aiInsights && !generatingInsights && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
                  {/* Price Scenarios */}
                  <div style={{ background: '#0d1219', border: '1px solid rgba(62,207,255,0.2)', borderRadius: 10, padding: 22 }}>
                    <div style={{ fontSize: 15, fontWeight: 800, marginBottom: 16 }}>🎯 Prisscenarier (3-6 mån)</div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                      {aiInsights.price_scenarios?.map((s, i) => (
                        <div key={i} style={{ background: '#131b24', border: '1px solid #1e2d3d', borderRadius: 8, padding: 14 }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}>
                            <span style={{ fontFamily: 'monospace', fontWeight: 700, fontSize: 14 }}>{s.ticker}</span>
                            <span style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94' }}>Aktuell: {fmtDec(s.current_price)}</span>
                          </div>
                          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                            <div>
                              <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', textTransform: 'uppercase', marginBottom: 4 }}>📈 Bullish</div>
                              <div style={{ fontFamily: 'monospace', fontSize: 13, fontWeight: 700, color: '#2ecc71', marginBottom: 6 }}>{fmtDec(s.bullish_target)}</div>
                              <div style={{ fontSize: 10, color: '#5a7a94', lineHeight: 1.4 }}>{s.bullish_reason}</div>
                            </div>
                            <div>
                              <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', textTransform: 'uppercase', marginBottom: 4 }}>📉 Bearish</div>
                              <div style={{ fontFamily: 'monospace', fontSize: 13, fontWeight: 700, color: '#e74c3c', marginBottom: 6 }}>{fmtDec(s.bearish_target)}</div>
                              <div style={{ fontSize: 10, color: '#5a7a94', lineHeight: 1.4 }}>{s.bearish_reason}</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Rebalancing Strategy */}
                  {aiInsights.rebalancing_strategy && (
                    <div style={{ background: '#0d1219', border: '1px solid rgba(155,89,182,0.2)', borderRadius: 10, padding: 22 }}>
                      <div style={{ fontSize: 15, fontWeight: 800, marginBottom: 12 }}>⚖️ Rebalanseringsstrategi</div>
                      <div style={{ fontSize: 12, color: '#dce8f5', marginBottom: 14, lineHeight: 1.6 }}>{aiInsights.rebalancing_strategy.summary}</div>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                        {aiInsights.rebalancing_strategy.actions?.map((action, i) => (
                          <div key={i} style={{ background: '#131b24', border: '1px solid #1e2d3d', borderRadius: 8, padding: 12 }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                              <span style={{ fontFamily: 'monospace', fontWeight: 700, fontSize: 12, color: '#9b59b6' }}>{action.action}</span>
                              <span style={{ fontFamily: 'monospace', fontSize: 11, color: '#3ecfff' }}>{action.ticker}</span>
                            </div>
                            <div style={{ fontSize: 10, color: '#5a7a94', marginBottom: 4 }}>{action.reason}</div>
                            <div style={{ fontSize: 10, color: '#2ecc71', fontFamily: 'monospace' }}>Impact: {action.impact}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Sector Alerts */}
                  {aiInsights.sector_alerts?.length > 0 && (
                    <div style={{ background: '#0d1219', border: '1px solid rgba(241,196,15,0.2)', borderRadius: 10, padding: 22 }}>
                      <div style={{ fontSize: 15, fontWeight: 800, marginBottom: 14 }}>⚠️ Sektorvarningar</div>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                        {aiInsights.sector_alerts.map((alert, i) => {
                          const statusColor = alert.status === 'overexposed' ? '#e74c3c' : alert.status === 'underexposed' ? '#f1c40f' : '#2ecc71';
                          return (
                            <div key={i} style={{ background: '#131b24', border: `1px solid ${statusColor}33`, borderRadius: 8, padding: 12 }}>
                              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                                <span style={{ fontFamily: 'monospace', fontWeight: 700, fontSize: 12 }}>{alert.sector}</span>
                                <span style={{ fontFamily: 'monospace', fontSize: 10, color: statusColor, fontWeight: 700 }}>{alert.current_weight?.toFixed(1)}% ({alert.status})</span>
                              </div>
                              <div style={{ fontSize: 10, color: '#5a7a94', marginBottom: 6 }}>{alert.risk}</div>
                              <div style={{ fontSize: 10, color: statusColor }}>{alert.recommendation}</div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Position Alerts */}
                  {aiInsights.position_alerts?.length > 0 && (
                    <div style={{ background: '#0d1219', border: '1px solid rgba(231,76,60,0.2)', borderRadius: 10, padding: 22 }}>
                      <div style={{ fontSize: 15, fontWeight: 800, marginBottom: 14 }}>🚨 Positionsvarningar</div>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                        {aiInsights.position_alerts.map((alert, i) => (
                          <div key={i} style={{ background: '#131b24', border: '1px solid rgba(231,76,60,0.2)', borderRadius: 8, padding: 12 }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                              <span style={{ fontFamily: 'monospace', fontWeight: 700, fontSize: 12, color: '#e74c3c' }}>{alert.ticker}</span>
                              <span style={{ fontSize: 9, color: '#5a7a94' }}>{alert.alert_type}</span>
                            </div>
                            <div style={{ fontSize: 10, color: '#dce8f5', marginBottom: 6 }}>{alert.message}</div>
                            <div style={{ fontSize: 10, color: '#f1c40f' }}>→ {alert.action}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
              {!generatingInsights && !aiInsights && (
                <div style={{ textAlign: 'center', padding: 40, color: '#5a7a94', fontFamily: 'monospace' }}>
                  Klicka "✦ AI" knappen för att generera avancerade insikter
                </div>
              )}
            </div>
          )}

          {/* RISK EXPOSURE STRIP */}
          {tab === 'overview' && enriched.length > 0 && <RiskExposureBar enriched={enriched} totalValueSEK={totalValueSEK} />}

          {/* HISTORY TAB */}
          {tab === 'history' && (
            <TradeHistory trades={trades} onEdit={handleEdit} onDelete={handleDelete} />
          )}
        </>
      )}
    </div>
  );
}