import React, { useState } from 'react';
import { MARKETS, ALL_INSTRUMENTS } from './instruments';
import { invokeFunction } from '@/api/supabaseClient';

export default function SettingsPage({ activeMarkets, onToggleMarket }) {
  const [syncing, setSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState('');

  const marketCounts = Object.fromEntries(
    Object.keys(MARKETS).map(mId => [mId, ALL_INSTRUMENTS.filter(i => i.market === mId).length])
  );

  const syncInstruments = async () => {
    setSyncing(true);
    setSyncResult('');
    try {
      const res = await invokeFunction('sync-instruments', {});
      setSyncResult(`✓ ${res.message || 'Sync klar'} (${res.total || '?'} totalt)`);
    } catch (e) {
      setSyncResult(`✗ Fel: ${e.message}`);
    }
    setSyncing(false);
  };

  return (
    <div style={{ padding: 24, maxWidth: 800, fontFamily: "'DM Sans', sans-serif" }}>
      <div style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>Inställningar</div>
      <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', marginBottom: 24 }}>Välj marknader och konfigurera datakällor</div>

      {/* Sync instruments */}
      <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, padding: 20, marginBottom: 18 }}>
        <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 8 }}>Instrumentregister</div>
        <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', marginBottom: 14, lineHeight: 1.7 }}>
          Synkar aktielistan från Nasdaq Nordic till databasen.<br />
          Kör detta första gången, eller när du vill uppdatera listan med nya noteringar.
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <button
            onClick={syncInstruments}
            disabled={syncing}
            style={{
              background: syncing ? '#131b24' : '#3ecfff', color: syncing ? '#5a7a94' : '#080c10',
              border: '1px solid #3ecfff', borderRadius: 7, padding: '8px 18px',
              fontWeight: 700, fontSize: 12, cursor: syncing ? 'not-allowed' : 'pointer',
            }}
          >
            {syncing ? '⟳ Synkar…' : '⟳ Synka instrument'}
          </button>
          {syncResult && (
            <span style={{ fontFamily: 'monospace', fontSize: 11, color: syncResult.startsWith('✓') ? '#2ecc71' : '#e74c3c' }}>
              {syncResult}
            </span>
          )}
        </div>
      </div>

      {/* Active markets */}
      <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, padding: 20, marginBottom: 18 }}>
        <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 16 }}>Aktiva marknader</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {Object.values(MARKETS).map(m => {
            const isActive = activeMarkets.includes(m.id);
            const count = marketCounts[m.id] || 0;
            return (
              <div
                key={m.id}
                onClick={() => onToggleMarket(m.id)}
                style={{
                  background: '#131b24', border: isActive ? '1px solid rgba(62,207,255,0.3)' : '1px solid #253649',
                  borderRadius: 8, padding: '13px 16px', cursor: 'pointer',
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  transition: 'all 0.15s', opacity: isActive ? 1 : 0.6,
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <span style={{ fontSize: 22 }}>{m.flag}</span>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 13 }}>{m.label}</div>
                    <div style={{ fontFamily: 'monospace', fontSize: 10, color: '#5a7a94', marginTop: 2 }}>
                      {count} aktier · {m.currency}
                    </div>
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontFamily: 'monospace', fontSize: 11, fontWeight: 700, color: isActive ? '#2ecc71' : '#5a7a94' }}>
                    {isActive ? '● PÅ' : '○ AV'}
                  </span>
                  <div style={{ width: 36, height: 20, borderRadius: 10, background: isActive ? '#3ecfff' : '#253649', position: 'relative', transition: 'background 0.2s' }}>
                    <div style={{ position: 'absolute', top: 3, left: isActive ? 18 : 3, width: 14, height: 14, borderRadius: '50%', background: '#080c10', transition: 'left 0.2s' }} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div style={{ marginTop: 16, padding: '10px 14px', background: 'rgba(62,207,255,0.05)', border: '1px solid rgba(62,207,255,0.15)', borderRadius: 8, fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', lineHeight: 1.7 }}>
          Aktiva marknader: <span style={{ color: '#3ecfff' }}>{activeMarkets.length}</span> st ·{' '}
          Totalt aktier: <span style={{ color: '#3ecfff' }}>{activeMarkets.reduce((sum, mId) => sum + (marketCounts[mId] || 0), 0)}</span>
        </div>
      </div>

      {/* Data source info */}
      <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, padding: 20 }}>
        <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 12 }}>Datakällor</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          {[
            { label: 'Primär källa', value: 'Twelve Data' },
            { label: 'Fallback', value: 'Finnhub' },
            { label: 'Sista utväg', value: 'Yahoo Finance' },
            { label: 'Exchange (Sverige)', value: 'XSTO (korrekt)' },
            { label: 'AI-motor', value: 'Claude (Anthropic)' },
            { label: 'Historik', value: '200 dagar' },
          ].map(({ label, value }) => (
            <div key={label} style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'monospace', fontSize: 11, padding: '5px 0', borderBottom: '1px solid rgba(30,45,61,0.4)' }}>
              <span style={{ color: '#5a7a94' }}>{label}</span>
              <span style={{ color: '#dce8f5' }}>{value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
