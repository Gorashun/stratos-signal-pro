import React, { useState } from 'react';
import { invokeFunction, Trade, Watchlist, Instrument } from '@/api/supabaseClient';
import { MARKETS } from '../instruments';

const inputStyle = {
  background: '#131b24', border: '1px solid #253649', borderRadius: 6,
  color: '#dce8f5', padding: '8px 11px', fontSize: 12, outline: 'none', width: '100%',
};

// ─── Modal Shell ────────────────────────────────────────────────────────────
function Modal({ title, onClose, children }) {
  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        zIndex: 9999, backdropFilter: 'blur(4px)',
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: '#0d1219', border: '1px solid #253649', borderRadius: 12,
          padding: 24, width: 420, maxWidth: '95vw', boxShadow: '0 20px 60px rgba(0,0,0,0.6)',
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
          <div style={{ fontWeight: 800, fontSize: 15, color: '#dce8f5' }}>{title}</div>
          <button onClick={onClose} style={{ background: 'transparent', border: 'none', color: '#5a7a94', fontSize: 18, cursor: 'pointer', lineHeight: 1 }}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ─── Add to Watchlist Modal ──────────────────────────────────────────────────
export function AddToWatchlistModal({ inst, existingWatchlist, onClose, onAdded }) {
  const [category, setCategory] = useState('');
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  const m = MARKETS[inst.market];
  const alreadyAdded = existingWatchlist?.some(
    w => w.ticker === inst.ticker && w.market === inst.market
  );

  const handleAdd = async () => {
    setSaving(true);
    // Ensure instrument exists in DB
    const existing = await Instrument.filter(
      { ticker: inst.ticker, market: inst.market }, '-created_date', 1
    );
    if (existing.length === 0) {
      await Instrument.create({
        ticker: inst.ticker,
        yahoo_symbol: inst.yahoo_symbol || inst.ticker,
        company_name: inst.company_name,
        market: inst.market,
        segment: inst.segment || '',
        sector: inst.sector || '',
        currency: inst.currency || (inst.market === 'sweden' ? 'SEK' : 'USD'),
      });
    }
    const record = await Watchlist.create({
      ticker: inst.ticker,
      company_name: inst.company_name,
      market: inst.market,
      segment: inst.segment || '',
      sector: inst.sector || '',
      category: category.trim(),
    });
    setSaving(false);
    setDone(true);
    onAdded && onAdded(record);
    setTimeout(onClose, 900);
  };

  return (
    <Modal title="★ Lägg till i bevakningslista" onClose={onClose}>
      {/* Instrument info */}
      <div style={{ background: '#131b24', borderRadius: 8, padding: '10px 14px', marginBottom: 16, display: 'flex', gap: 12, alignItems: 'center' }}>
        <div>
          <div style={{ fontFamily: 'monospace', fontWeight: 800, fontSize: 16, color: '#3ecfff' }}>{inst.ticker}</div>
          <div style={{ fontSize: 11, color: '#90aabf', marginTop: 2 }}>{inst.company_name}</div>
        </div>
        <div style={{ marginLeft: 'auto', textAlign: 'right' }}>
          <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94' }}>{m?.flag} {m?.label || inst.market}</div>
          {inst.sector && <div style={{ fontSize: 10, color: '#3d5a72', marginTop: 2 }}>{inst.sector}</div>}
        </div>
      </div>

      {alreadyAdded ? (
        <div style={{ textAlign: 'center', padding: '16px 0', color: '#2ecc71', fontFamily: 'monospace', fontSize: 13 }}>
          ✓ Redan i bevakningslistan
        </div>
      ) : done ? (
        <div style={{ textAlign: 'center', padding: '16px 0', color: '#2ecc71', fontFamily: 'monospace', fontSize: 13 }}>
          ✓ Tillagd!
        </div>
      ) : (
        <>
          <div style={{ marginBottom: 14 }}>
            <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94', marginBottom: 5, letterSpacing: 1, textTransform: 'uppercase' }}>Kategori (valfritt)</div>
            <input
              type="text"
              placeholder="T.ex. Egna picks, Momentum, Hälsa…"
              value={category}
              onChange={e => setCategory(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleAdd()}
              style={inputStyle}
              autoFocus
            />
          </div>
          <button
            onClick={handleAdd}
            disabled={saving}
            style={{
              width: '100%', background: '#3ecfff', color: '#080c10', border: 'none',
              padding: '10px 0', borderRadius: 7, cursor: 'pointer', fontWeight: 800, fontSize: 13,
              opacity: saving ? 0.6 : 1,
            }}
          >
            {saving ? '…' : '★ Lägg till i bevakningslista'}
          </button>
        </>
      )}
    </Modal>
  );
}

// ─── Add Trade Modal ─────────────────────────────────────────────────────────
export function AddTradeModal({ inst, onClose, onAdded }) {
  const today = new Date().toISOString().split('T')[0];
  const m = MARKETS[inst.market];
  const defaultCurrency = inst.currency || (inst.market === 'sweden' ? 'SEK' : inst.market === 'usa' ? 'USD' : inst.market === 'uk' ? 'GBP' : 'EUR');

  const [form, setForm] = useState({
    type: 'BUY',
    shares: '',
    price: inst.last_price || '',
    date: today,
    note: '',
    currency: defaultCurrency,
  });
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  const total = form.shares && form.price ? (+form.shares * +form.price) : null;

  const handleSave = async () => {
    if (!form.shares || !form.price) return;
    setSaving(true);
    await Trade.create({
      ticker: inst.ticker,
      company_name: inst.company_name,
      market: inst.market,
      sector: inst.sector || '',
      currency: form.currency,
      type: form.type,
      shares: +form.shares,
      price: +form.price,
      date: form.date,
      note: form.note,
    });
    setSaving(false);
    setDone(true);
    onAdded && onAdded();
    setTimeout(onClose, 900);
  };

  return (
    <Modal title={`▲ Registrera affär`} onClose={onClose}>
      {/* Instrument info */}
      <div style={{ background: '#131b24', borderRadius: 8, padding: '10px 14px', marginBottom: 16, display: 'flex', gap: 12, alignItems: 'center' }}>
        <div>
          <div style={{ fontFamily: 'monospace', fontWeight: 800, fontSize: 16, color: '#3ecfff' }}>{inst.ticker}</div>
          <div style={{ fontSize: 11, color: '#90aabf', marginTop: 2 }}>{inst.company_name}</div>
        </div>
        <div style={{ marginLeft: 'auto', textAlign: 'right' }}>
          <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94' }}>{m?.flag} {m?.label || inst.market}</div>
          {inst.last_price && (
            <div style={{ fontFamily: 'monospace', fontSize: 12, color: '#dce8f5', marginTop: 2, fontWeight: 700 }}>
              {inst.last_price.toFixed(2)} {defaultCurrency}
            </div>
          )}
        </div>
      </div>

      {done ? (
        <div style={{ textAlign: 'center', padding: '16px 0', color: '#2ecc71', fontFamily: 'monospace', fontSize: 13 }}>
          ✓ Affär registrerad!
        </div>
      ) : (
        <>
          {/* Buy / Sell toggle */}
          <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
            {['BUY', 'SELL'].map(t => (
              <button key={t} onClick={() => setForm(p => ({ ...p, type: t }))} style={{
                flex: 1, padding: '8px 0', borderRadius: 6, cursor: 'pointer', fontWeight: 700, fontSize: 12,
                border: form.type === t
                  ? `1px solid ${t === 'BUY' ? 'rgba(46,204,113,0.5)' : 'rgba(231,76,60,0.5)'}`
                  : '1px solid #253649',
                background: form.type === t
                  ? (t === 'BUY' ? 'rgba(46,204,113,0.12)' : 'rgba(231,76,60,0.12)')
                  : 'transparent',
                color: form.type === t ? (t === 'BUY' ? '#2ecc71' : '#e74c3c') : '#5a7a94',
              }}>
                {t === 'BUY' ? '▲ KÖP' : '▼ SÄLJ'}
              </button>
            ))}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
            <div>
              <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94', marginBottom: 4, letterSpacing: 1, textTransform: 'uppercase' }}>Antal aktier</div>
              <input type="number" placeholder="100" value={form.shares}
                onChange={e => setForm(p => ({ ...p, shares: e.target.value }))} style={inputStyle} autoFocus />
            </div>
            <div>
              <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94', marginBottom: 4, letterSpacing: 1, textTransform: 'uppercase' }}>Pris per aktie</div>
              <input type="number" placeholder="85.50" value={form.price}
                onChange={e => setForm(p => ({ ...p, price: e.target.value }))} style={inputStyle} />
            </div>
            <div>
              <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94', marginBottom: 4, letterSpacing: 1, textTransform: 'uppercase' }}>Datum</div>
              <input type="date" value={form.date} onChange={e => setForm(p => ({ ...p, date: e.target.value }))} style={inputStyle} />
            </div>
            <div>
              <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94', marginBottom: 4, letterSpacing: 1, textTransform: 'uppercase' }}>Valuta</div>
              <select value={form.currency} onChange={e => setForm(p => ({ ...p, currency: e.target.value }))} style={inputStyle}>
                {['SEK', 'USD', 'EUR', 'GBP', 'JPY', 'HKD'].map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
          </div>

          <div style={{ marginBottom: 14 }}>
            <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94', marginBottom: 4, letterSpacing: 1, textTransform: 'uppercase' }}>Anteckning (valfritt)</div>
            <input type="text" placeholder="T.ex. Utdelningsstrategi…" value={form.note}
              onChange={e => setForm(p => ({ ...p, note: e.target.value }))} style={inputStyle} />
          </div>

          {/* Total preview */}
          {total && (
            <div style={{ background: '#131b24', borderRadius: 6, padding: '8px 12px', marginBottom: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>TOTALT VÄRDE</span>
              <span style={{ fontFamily: 'monospace', fontSize: 14, fontWeight: 800, color: form.type === 'BUY' ? '#2ecc71' : '#e74c3c' }}>
                {total.toLocaleString('sv-SE', { maximumFractionDigits: 2 })} {form.currency}
              </span>
            </div>
          )}

          <button
            onClick={handleSave}
            disabled={saving || !form.shares || !form.price}
            style={{
              width: '100%', border: 'none',
              background: form.type === 'BUY' ? '#2ecc71' : '#e74c3c',
              color: '#080c10', padding: '10px 0', borderRadius: 7,
              cursor: (!form.shares || !form.price) ? 'not-allowed' : 'pointer',
              fontWeight: 800, fontSize: 13,
              opacity: (saving || !form.shares || !form.price) ? 0.5 : 1,
            }}
          >
            {saving ? '…' : form.type === 'BUY' ? '▲ Registrera köp' : '▼ Registrera sälj'}
          </button>
        </>
      )}
    </Modal>
  );
}