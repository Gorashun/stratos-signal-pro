import React from 'react';

export default function TradeHistory({ trades, onEdit, onDelete }) {
  if (!trades.length) return null;

  const sorted = [...trades].sort((a, b) => b.date.localeCompare(a.date));

  return (
    <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, overflow: 'hidden', marginTop: 18 }}>
      <div style={{ padding: '10px 15px', background: '#131b24', borderBottom: '1px solid #1e2d3d', fontFamily: 'monospace', fontSize: 10, letterSpacing: 1.5, color: '#3d5a72', textTransform: 'uppercase' }}>
        Transaktionshistorik · {trades.length} poster
      </div>
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 600 }}>
          <thead>
            <tr style={{ background: '#0f161e' }}>
              {['Datum', 'Typ', 'Ticker', 'Antal', 'Pris', 'Total', 'Anteckning', ''].map(h => (
                <th key={h} style={{ padding: '7px 12px', textAlign: 'left', fontFamily: 'monospace', fontSize: 9, letterSpacing: 1.2, color: '#3d5a72', textTransform: 'uppercase', borderBottom: '1px solid #1e2d3d', whiteSpace: 'nowrap' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sorted.map(t => {
              const total = t.shares * t.price;
              return (
                <tr key={t.id} style={{ borderBottom: '1px solid rgba(30,45,61,0.4)' }}>
                  <td style={{ padding: '7px 12px', fontFamily: 'monospace', fontSize: 11, color: '#5a7a94' }}>{t.date}</td>
                  <td style={{ padding: '7px 12px' }}>
                    <span style={{
                      fontFamily: 'monospace', fontSize: 9, fontWeight: 700, padding: '2px 7px', borderRadius: 3,
                      background: t.type === 'BUY' ? 'rgba(46,204,113,0.12)' : 'rgba(231,76,60,0.12)',
                      color: t.type === 'BUY' ? '#2ecc71' : '#e74c3c',
                      border: `1px solid ${t.type === 'BUY' ? 'rgba(46,204,113,0.3)' : 'rgba(231,76,60,0.3)'}`,
                    }}>
                      {t.type === 'BUY' ? '▲ KÖP' : '▼ SÄLJ'}
                    </span>
                  </td>
                  <td style={{ padding: '7px 12px', fontFamily: 'monospace', fontWeight: 700, fontSize: 12 }}>{t.ticker}</td>
                  <td style={{ padding: '7px 12px', fontFamily: 'monospace', fontSize: 12 }}>{t.shares}</td>
                  <td style={{ padding: '7px 12px', fontFamily: 'monospace', fontSize: 12, color: '#dce8f5' }}>
                    {t.price?.toFixed(2)}
                    <span style={{ fontSize: 9, color: '#3d5a72', marginLeft: 4 }}>{t.currency}</span>
                  </td>
                  <td style={{ padding: '7px 12px', fontFamily: 'monospace', fontSize: 12, color: t.type === 'BUY' ? '#5a7a94' : '#2ecc71' }}>
                    {t.type === 'SELL' ? '+' : ''}{total.toLocaleString('sv-SE', { maximumFractionDigits: 0 })} {t.currency}
                  </td>
                  <td style={{ padding: '7px 12px', fontSize: 11, color: '#5a7a94', maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.note || '—'}</td>
                  <td style={{ padding: '7px 12px' }}>
                    <div style={{ display: 'flex', gap: 4 }}>
                      <button onClick={() => onEdit(t)} style={{ background: 'rgba(62,207,255,0.07)', border: '1px solid rgba(62,207,255,0.15)', color: '#3ecfff', padding: '2px 7px', borderRadius: 4, cursor: 'pointer', fontSize: 10 }}>✎</button>
                      <button onClick={() => onDelete(t.id)} style={{ background: 'rgba(231,76,60,0.07)', border: '1px solid rgba(231,76,60,0.15)', color: '#e74c3c', padding: '2px 7px', borderRadius: 4, cursor: 'pointer', fontSize: 10 }}>✕</button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}