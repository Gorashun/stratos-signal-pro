import React from 'react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend,
} from 'recharts';

const COLORS = ['#3ecfff', '#2ecc71', '#9b59b6', '#f1c40f', '#ff6b35', '#e74c3c', '#1abc9c', '#e67e22', '#3498db', '#5a7a94'];

const tooltipStyle = {
  background: '#131b24', border: '1px solid #253649', borderRadius: 6,
  color: '#dce8f5', fontSize: 11, fontFamily: 'monospace',
};

function fmt(n) {
  if (Math.abs(n) >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (Math.abs(n) >= 1000) return (n / 1000).toFixed(0) + 'k';
  return n.toFixed(0);
}

export function PnLBarChart({ enriched }) {
  const data = enriched
    .filter(h => h.pnlSEK != null)
    .sort((a, b) => b.pnlSEK - a.pnlSEK)
    .map(h => ({ name: h.ticker, pnl: Math.round(h.pnlSEK), pct: h.pnlPct }));

  if (!data.length) return null;

  return (
    <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, padding: 16 }}>
      <div style={{ fontFamily: 'monospace', fontSize: 10, letterSpacing: 1.5, color: '#3d5a72', textTransform: 'uppercase', marginBottom: 14 }}>
        P&L per aktie (SEK)
      </div>
      <ResponsiveContainer width="100%" height={200}>
        <BarChart data={data} margin={{ top: 4, right: 4, left: 0, bottom: 20 }}>
          <XAxis dataKey="name" tick={{ fill: '#5a7a94', fontSize: 9, fontFamily: 'monospace' }} angle={-35} textAnchor="end" interval={0} />
          <YAxis tick={{ fill: '#5a7a94', fontSize: 9, fontFamily: 'monospace' }} tickFormatter={fmt} />
          <Tooltip
            contentStyle={tooltipStyle}
            formatter={(v, n, props) => [`${v >= 0 ? '+' : ''}${v.toLocaleString('sv-SE')} SEK (${props.payload.pct?.toFixed(1)}%)`, 'P&L']}
            labelStyle={{ color: '#3ecfff' }}
          />
          <Bar dataKey="pnl" radius={[3, 3, 0, 0]}>
            {data.map((entry, i) => (
              <Cell key={i} fill={entry.pnl >= 0 ? '#2ecc71' : '#e74c3c'} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function AllocationPieChart({ enriched, totalValueSEK }) {
  const data = enriched
    .filter(h => h.valueSEK > 0)
    .sort((a, b) => b.valueSEK - a.valueSEK)
    .map(h => ({ name: h.ticker, value: Math.round(h.valueSEK), pct: totalValueSEK ? (h.valueSEK / totalValueSEK * 100) : 0 }));

  if (!data.length) return null;

  return (
    <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, padding: 16 }}>
      <div style={{ fontFamily: 'monospace', fontSize: 10, letterSpacing: 1.5, color: '#3d5a72', textTransform: 'uppercase', marginBottom: 14 }}>
        Portföljfördelning
      </div>
      <ResponsiveContainer width="100%" height={220}>
        <PieChart>
          <Pie data={data} cx="50%" cy="50%" innerRadius={55} outerRadius={85} paddingAngle={2} dataKey="value">
            {data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
          </Pie>
          <Tooltip
            contentStyle={tooltipStyle}
            formatter={(v, n, props) => [`${v.toLocaleString('sv-SE')} SEK (${props.payload.pct?.toFixed(1)}%)`, props.payload.name]}
          />
          <Legend
            formatter={(value) => <span style={{ color: '#dce8f5', fontSize: 10, fontFamily: 'monospace' }}>{value}</span>}
            iconSize={8}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}