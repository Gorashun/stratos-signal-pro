import React from 'react';

const MARKET_FLAG = { sweden: '🇸🇪', usa: '🇺🇸', europe: '🇪🇺', asia: '🌏' };

export default function PortfolioRecommendations({ enriched, signals, totalValueSEK, sectorBreakdown }) {
  const approvedSignals = signals.filter(s => s.status === 'APPROVED');

  // Match signals to existing portfolio holdings
  const holdingTickers = new Set(enriched.map(h => h.ticker.toUpperCase()));

  // Signals for stocks already held (possible add-to / trim)
  const portfolioSignals = approvedSignals.filter(s => holdingTickers.has(s.ticker.toUpperCase()));

  // Signals for new potential additions
  const newSignals = approvedSignals.filter(s => !holdingTickers.has(s.ticker.toUpperCase()));

  // Concentration risk: positions > 15% of portfolio
  const concentrated = enriched.filter(h => totalValueSEK > 0 && (h.valueSEK / totalValueSEK) * 100 > 15);

  // Underperformers: pnlPct < -10%
  const underperformers = enriched.filter(h => h.pnlPct != null && h.pnlPct < -10);

  // Overallocated sectors (> 35%)
  const overweightSectors = sectorBreakdown.filter(s => s.pct > 35);

  const fmtDec = (n, d = 2) => n.toLocaleString('sv-SE', { minimumFractionDigits: d, maximumFractionDigits: d });

  const cardStyle = {
    background: '#131b24', border: '1px solid #1e2d3d', borderRadius: 8, padding: '12px 16px', marginBottom: 8,
  };

  const labelStyle = {
    fontFamily: 'monospace', fontSize: 9, letterSpacing: 1.5, color: '#3d5a72',
    textTransform: 'uppercase', marginBottom: 10,
  };

  const Tag = ({ children, color }) => (
    <span style={{
      fontFamily: 'monospace', fontSize: 9, padding: '2px 7px', borderRadius: 10,
      background: `${color}18`, border: `1px solid ${color}44`, color,
    }}>{children}</span>
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>

      {/* Portfolio signal matches */}
      <div style={{ background: '#0d1219', border: '1px solid rgba(62,207,255,0.2)', borderRadius: 9, padding: 18 }}>
        <div style={labelStyle}>⚡ Aktiva signaler — befintliga innehav</div>
        {portfolioSignals.length === 0 ? (
          <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#3d5a72', padding: '12px 0' }}>
            Inga aktiva signaler för dina nuvarande innehav just nu.
          </div>
        ) : portfolioSignals.map((s, i) => {
          const holding = enriched.find(h => h.ticker.toUpperCase() === s.ticker.toUpperCase());
          const portfolioPct = holding && totalValueSEK > 0 ? (holding.valueSEK / totalValueSEK) * 100 : 0;
          const pnlColor = holding?.pnlPct == null ? '#5a7a94' : holding.pnlPct >= 0 ? '#2ecc71' : '#e74c3c';
          return (
            <div key={i} style={{ ...cardStyle, borderColor: 'rgba(46,204,113,0.2)' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
                <div style={{ background: 'rgba(46,204,113,0.1)', border: '1px solid rgba(46,204,113,0.25)', borderRadius: 6, padding: '8px 12px', textAlign: 'center', minWidth: 64 }}>
                  <div style={{ fontFamily: 'monospace', fontSize: 14, fontWeight: 800, color: '#2ecc71' }}>▲ KÖP</div>
                  <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#2ecc71', marginTop: 2 }}>SIGNAL</div>
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 5 }}>
                    <span style={{ fontFamily: 'monospace', fontWeight: 700, fontSize: 14 }}>{s.ticker}</span>
                    <Tag color="#3ecfff">{s.rule_name || s.rule}</Tag>
                    {s.market && <span>{MARKET_FLAG[s.market]}</span>}
                  </div>
                  <div style={{ fontSize: 11, color: '#90aabf', marginBottom: 6 }}>
                    Ingång: <strong style={{ color: '#dce8f5' }}>{s.entry?.toFixed(2)}</strong> &nbsp;|&nbsp;
                    Stop: <strong style={{ color: '#e74c3c' }}>{s.stop?.toFixed(2)}</strong> &nbsp;|&nbsp;
                    TP: <strong style={{ color: '#2ecc71' }}>{(s.tp || s.take_profit)?.toFixed(2)}</strong>
                  </div>
                  <div style={{ fontSize: 11, color: '#5a7a94' }}>
                    Du äger redan <strong style={{ color: '#dce8f5' }}>{holding?.shares} aktier</strong> ({fmtDec(portfolioPct, 1)}% av portföljen).
                    {holding?.pnlPct != null && (
                      <span> Nuläge: <span style={{ color: pnlColor, fontWeight: 700 }}>{holding.pnlPct >= 0 ? '+' : ''}{fmtDec(holding.pnlPct)}%</span>.</span>
                    )}
                    {' '}Signalen stöder att <strong>öka positionen</strong> om du vill utöka exponeringen.
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* New signal opportunities */}
      <div style={{ background: '#0d1219', border: '1px solid rgba(241,196,15,0.15)', borderRadius: 9, padding: 18 }}>
        <div style={labelStyle}>🆕 Nya köpmöjligheter — ej i portföljen</div>
        {newSignals.length === 0 ? (
          <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#3d5a72', padding: '12px 0' }}>
            Inga aktiva köpsignaler för aktier utanför din portfölj just nu.
          </div>
        ) : newSignals.slice(0, 8).map((s, i) => (
          <div key={i} style={cardStyle}>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
              <div style={{ background: 'rgba(241,196,15,0.08)', border: '1px solid rgba(241,196,15,0.2)', borderRadius: 6, padding: '8px 12px', textAlign: 'center', minWidth: 64 }}>
                <div style={{ fontFamily: 'monospace', fontSize: 13, fontWeight: 800, color: '#f1c40f' }}>NY</div>
                <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#f1c40f', marginTop: 2 }}>MÖJLIGHET</div>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 5 }}>
                  <span style={{ fontFamily: 'monospace', fontWeight: 700, fontSize: 14 }}>{s.ticker}</span>
                  <span style={{ fontSize: 11, color: '#90aabf' }}>{s.company_name}</span>
                  <Tag color="#f1c40f">{s.rule_name || s.rule}</Tag>
                  {s.market && <span>{MARKET_FLAG[s.market]}</span>}
                </div>
                <div style={{ fontSize: 11, color: '#90aabf', marginBottom: 4 }}>
                  Ingång: <strong style={{ color: '#dce8f5' }}>{s.entry?.toFixed(2)}</strong> &nbsp;|&nbsp;
                  Stop: <strong style={{ color: '#e74c3c' }}>{s.stop?.toFixed(2)}</strong> &nbsp;|&nbsp;
                  TP: <strong style={{ color: '#2ecc71' }}>{(s.tp || s.take_profit)?.toFixed(2)}</strong> &nbsp;|&nbsp;
                  RSI: <strong style={{ color: s.rsi > 70 ? '#e74c3c' : '#dce8f5' }}>{s.rsi?.toFixed(0)}</strong>
                </div>
                {s.sector && (
                  <div style={{ fontSize: 10, color: '#5a7a94' }}>
                    Sektor: <strong style={{ color: '#dce8f5' }}>{s.sector}</strong>
                    {sectorBreakdown.find(sb => sb.sector === s.sector) && (
                      <span> — din nuvarande exponering: <strong style={{ color: '#3ecfff' }}>
                        {fmtDec(sectorBreakdown.find(sb => sb.sector === s.sector)?.pct || 0, 1)}%
                      </strong></span>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
        {newSignals.length > 8 && (
          <div style={{ fontFamily: 'monospace', fontSize: 10, color: '#3d5a72', marginTop: 6 }}>
            + {newSignals.length - 8} fler signaler — se Signaler-sidan
          </div>
        )}
      </div>

      {/* Concentration warnings */}
      {(concentrated.length > 0 || underperformers.length > 0 || overweightSectors.length > 0) && (
        <div style={{ background: '#0d1219', border: '1px solid rgba(231,76,60,0.2)', borderRadius: 9, padding: 18 }}>
          <div style={labelStyle}>⚠ Riskvarningar</div>

          {concentrated.map((h, i) => {
            const pct = totalValueSEK > 0 ? (h.valueSEK / totalValueSEK) * 100 : 0;
            return (
              <div key={`conc-${i}`} style={{ ...cardStyle, borderColor: 'rgba(231,76,60,0.2)' }}>
                <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                  <span style={{ fontFamily: 'monospace', fontSize: 9, padding: '2px 7px', borderRadius: 10, background: 'rgba(231,76,60,0.12)', border: '1px solid rgba(231,76,60,0.3)', color: '#e74c3c', whiteSpace: 'nowrap' }}>Koncentration</span>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 600, color: '#dce8f5', marginBottom: 3 }}>
                      {h.ticker} utgör {fmtDec(pct, 1)}% av portföljen
                    </div>
                    <div style={{ fontSize: 11, color: '#5a7a94' }}>
                      Överväg att minska positionen till max 10–15% för bättre riskspridning.
                    </div>
                  </div>
                </div>
              </div>
            );
          })}

          {underperformers.map((h, i) => (
            <div key={`under-${i}`} style={{ ...cardStyle, borderColor: 'rgba(231,76,60,0.15)' }}>
              <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                <span style={{ fontFamily: 'monospace', fontSize: 9, padding: '2px 7px', borderRadius: 10, background: 'rgba(231,76,60,0.12)', border: '1px solid rgba(231,76,60,0.3)', color: '#e74c3c', whiteSpace: 'nowrap' }}>Underpresterare</span>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: '#dce8f5', marginBottom: 3 }}>
                    {h.ticker}: <span style={{ color: '#e74c3c' }}>{fmtDec(h.pnlPct, 1)}%</span> sedan köp
                  </div>
                  <div style={{ fontSize: 11, color: '#5a7a94' }}>
                    Stor förlust. Inga aktiva köpsignaler stöder ett utökat innehav. Utvärdera stopp-nivån.
                  </div>
                </div>
              </div>
            </div>
          ))}

          {overweightSectors.map((s, i) => (
            <div key={`ow-${i}`} style={{ ...cardStyle, borderColor: 'rgba(241,196,15,0.15)' }}>
              <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                <span style={{ fontFamily: 'monospace', fontSize: 9, padding: '2px 7px', borderRadius: 10, background: 'rgba(241,196,15,0.1)', border: '1px solid rgba(241,196,15,0.25)', color: '#f1c40f', whiteSpace: 'nowrap' }}>Sektorvikt</span>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: '#dce8f5', marginBottom: 3 }}>
                    {s.sector} = {fmtDec(s.pct, 1)}% av portföljen
                  </div>
                  <div style={{ fontSize: 11, color: '#5a7a94' }}>
                    Hög koncentration i en sektor ökar risken. Överväg diversifiering till andra sektorer.
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {approvedSignals.length === 0 && enriched.length === 0 && (
        <div style={{ padding: 40, textAlign: 'center', color: '#3d5a72', fontFamily: 'monospace', fontSize: 12 }}>
          Lägg till innehav och generera signaler för att se rekommendationer.
        </div>
      )}
    </div>
  );
}