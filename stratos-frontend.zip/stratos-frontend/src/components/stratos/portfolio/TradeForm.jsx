import React, { useState, useEffect, useRef } from 'react';
import { invokeFunction, Trade, Watchlist, Instrument } from '@/api/supabaseClient';
import { ALL_INSTRUMENTS, MARKETS } from '../instruments';

const inputStyle = {
  background: '#0d1219', border: '1px solid #253649', borderRadius: 6,
  color: '#dce8f5', padding: '7px 10px', fontSize: 12, outline: 'none', width: '100%',
};

export default function TradeForm({ trade, onSave, onCancel }) {
  const today = new Date().toISOString().split('T')[0];
  const [form, setForm] = useState(trade || {
    ticker: '', company_name: '', market: 'sweden', sector: '',
    currency: 'SEK', type: 'BUY', shares: '', price: '', date: today, note: '',
  });
  const [tickerSearch, setTickerSearch] = useState(trade ? `${trade.ticker} – ${trade.company_name || ''}` : '');
  const [results, setResults] = useState([]);
  const [showDrop, setShowDrop] = useState(false);
  const [dbInstruments, setDbInstruments] = useState([]);
  const ref = useRef(null);

  useEffect(() => {
    Instrument.list('-created_date', 10000).then(setDbInstruments);
  }, []);

  useEffect(() => {
    const q = tickerSearch.toLowerCase();
    if (!q.trim()) { setResults([]); setShowDrop(false); return; }
    const hc = ALL_INSTRUMENTS.filter(i => i.t.toLowerCase().includes(q) || i.n.toLowerCase().includes(q)).slice(0, 6);
    const db = dbInstruments
      .filter(i => i.ticker?.toLowerCase().includes(q) || i.company_name?.toLowerCase().includes(q))
      .map(i => ({ t: i.ticker, n: i.company_name, market: i.market, s: i.sector, currency: i.currency }))
      .slice(0, 6);
    const seen = new Set(hc.map(i => i.t));
    const merged = [...hc, ...db.filter(i => !seen.has(i.t))].slice(0, 8);
    setResults(merged);
    setShowDrop(merged.length > 0);
  }, [tickerSearch, dbInstruments]);

  const select = (inst) => {
    const currency = inst.currency || MARKETS[inst.market]?.currency || 'SEK';
    setForm(p => ({ ...p, ticker: inst.t, company_name: inst.n, market: inst.market || 'sweden', currency, sector: inst.s || '' }));
    setTickerSearch(`${inst.t} – ${inst.n}`);
    setShowDrop(false);
  };

  const handleSave = () => {
    if (!form.ticker || !form.shares || !form.price || !form.date) return;
    onSave({ ...form, shares: +form.shares, price: +form.price });
  };

  return (
    <div style={{ background: '#0d1219', border: '1px solid #253649', borderRadius: 10, padding: 18, marginBottom: 18 }}>
      <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 14, color: '#dce8f5' }}>
        {trade ? 'Redigera transaktion' : 'Ny transaktion'}
      </div>

      {/* Buy / Sell toggle */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
        {['BUY', 'SELL'].map(t => (
          <button key={t} onClick={() => setForm(p => ({ ...p, type: t }))} style={{
            padding: '5px 18px', borderRadius: 5, cursor: 'pointer', fontWeight: 700, fontSize: 11,
            border: form.type === t
              ? `1px solid ${t === 'BUY' ? 'rgba(46,204,113,0.5)' : 'rgba(231,76,60,0.5)'}`
              : '1px solid #253649',
            background: form.type === t
              ? (t === 'BUY' ? 'rgba(46,204,113,0.12)' : 'rgba(231,76,60,0.12)')
              : 'transparent',
            color: form.type === t ? (t === 'BUY' ? '#2ecc71' : '#e74c3c') : '#5a7a94',
          }}>
            {t === 'BUY' ? '▲ KÖP' : '▼ SÄLJ'}
          </button>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: 10 }}>
        {/* Ticker search */}
        <div style={{ position: 'relative', gridColumn: 'span 2' }} ref={ref}>
          <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94', marginBottom: 4, letterSpacing: 1, textTransform: 'uppercase' }}>Aktie</div>
          <input
            type="text"
            placeholder="Sök ticker eller bolagsnamn…"
            value={tickerSearch}
            onChange={e => { setTickerSearch(e.target.value); setForm(p => ({ ...p, ticker: e.target.value.split(' ')[0] })); }}
            onFocus={() => results.length > 0 && setShowDrop(true)}
            style={inputStyle}
          />
          {showDrop && (
            <div style={{ position: 'absolute', top: '100%', left: 0, right: 0, background: '#131b24', border: '1px solid #253649', borderRadius: 6, zIndex: 100, marginTop: 2 }}>
              {results.map((inst, i) => (
                <div key={i} onMouseDown={() => select(inst)} style={{
                  padding: '7px 12px', cursor: 'pointer', display: 'flex', gap: 10, alignItems: 'center',
                  borderBottom: i < results.length - 1 ? '1px solid #1e2d3d' : 'none',
                }}
                  onMouseEnter={e => e.currentTarget.style.background = '#1a2535'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                >
                  <span style={{ fontFamily: 'monospace', fontWeight: 700, fontSize: 12, color: '#3ecfff', minWidth: 65 }}>{inst.t}</span>
                  <span style={{ fontSize: 11, color: '#dce8f5', flex: 1 }}>{inst.n}</span>
                  <span style={{ fontSize: 10, color: '#5a7a94' }}>{MARKETS[inst.market]?.flag}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {[
          { label: 'Antal aktier', key: 'shares', placeholder: '100', type: 'number' },
          { label: 'Pris per aktie', key: 'price', placeholder: '85.50', type: 'number' },
        ].map(f => (
          <div key={f.key}>
            <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94', marginBottom: 4, letterSpacing: 1, textTransform: 'uppercase' }}>{f.label}</div>
            <input type={f.type} placeholder={f.placeholder} value={form[f.key]}
              onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))} style={inputStyle} />
          </div>
        ))}

        <div>
          <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94', marginBottom: 4, letterSpacing: 1, textTransform: 'uppercase' }}>Datum</div>
          <input type="date" value={form.date} onChange={e => setForm(p => ({ ...p, date: e.target.value }))} style={inputStyle} />
        </div>

        <div>
          <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94', marginBottom: 4, letterSpacing: 1, textTransform: 'uppercase' }}>Valuta</div>
          <select value={form.currency} onChange={e => setForm(p => ({ ...p, currency: e.target.value }))} style={inputStyle}>
            {['SEK', 'USD', 'EUR', 'GBP', 'JPY', 'HKD'].map(c => <option key={c}>{c}</option>)}
          </select>
        </div>

        <div style={{ gridColumn: 'span 2' }}>
          <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94', marginBottom: 4, letterSpacing: 1, textTransform: 'uppercase' }}>Anteckning (valfritt)</div>
          <input type="text" placeholder="T.ex. Utdelningsstrategi…" value={form.note}
            onChange={e => setForm(p => ({ ...p, note: e.target.value }))} style={inputStyle} />
        </div>
      </div>

      {/* Total preview */}
      {form.shares && form.price && (
        <div style={{ marginTop: 12, fontFamily: 'monospace', fontSize: 11, color: '#5a7a94' }}>
          Total: <span style={{ color: form.type === 'BUY' ? '#2ecc71' : '#e74c3c', fontWeight: 700 }}>
            {(+form.shares * +form.price).toLocaleString('sv-SE', { maximumFractionDigits: 2 })} {form.currency}
          </span>
        </div>
      )}

      <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
        <button onClick={handleSave} style={{
          background: form.type === 'BUY' ? '#2ecc71' : '#e74c3c', border: 'none',
          color: '#080c10', padding: '7px 18px', borderRadius: 6, cursor: 'pointer', fontWeight: 700, fontSize: 12,
        }}>
          {trade ? 'Spara' : form.type === 'BUY' ? '▲ Lägg till köp' : '▼ Lägg till sälj'}
        </button>
        <button onClick={onCancel} style={{ background: 'transparent', border: '1px solid #253649', color: '#5a7a94', padding: '7px 14px', borderRadius: 6, cursor: 'pointer', fontSize: 12 }}>Avbryt</button>
      </div>
    </div>
  );
}