import React from 'react';

export default function RiskExposureBar({ enriched, totalValueSEK }) {
  if (!enriched.length || totalValueSEK === 0) return null;

  // Biggest single position
  const sorted = [...enriched].sort((a, b) => b.valueSEK - a.valueSEK);
  const top = sorted[0];
  const topPct = (top.valueSEK / totalValueSEK) * 100;

  // Count positions with live data
  const liveCount = enriched.filter(h => h.hasLive).length;

  // Weighted avg P&L
  const weightedPnl = enriched.reduce((s, h) => {
    const w = totalValueSEK > 0 ? h.valueSEK / totalValueSEK : 0;
    return s + (h.pnlPct ?? 0) * w;
  }, 0);

  // Diversification score: penalise concentration
  const herfindahl = enriched.reduce((s, h) => {
    const w = h.valueSEK / totalValueSEK;
    return s + w * w;
  }, 0);
  const divScore = Math.round((1 - herfindahl) * 100);

  const fmtDec = (n, d = 1) => n.toLocaleString('sv-SE', { minimumFractionDigits: d, maximumFractionDigits: d });

  const metrics = [
    {
      label: 'Diversifieringspoäng',
      value: `${divScore}/100`,
      sub: divScore >= 80 ? 'Välspridd' : divScore >= 60 ? 'OK' : 'Koncentrerad',
      color: divScore >= 80 ? '#2ecc71' : divScore >= 60 ? '#f1c40f' : '#e74c3c',
      bar: divScore,
    },
    {
      label: 'Största position',
      value: `${fmtDec(topPct)}%`,
      sub: top.ticker,
      color: topPct > 25 ? '#e74c3c' : topPct > 15 ? '#f1c40f' : '#2ecc71',
      bar: Math.min(topPct, 100),
    },
    {
      label: 'Vägt snitt P&L',
      value: `${weightedPnl >= 0 ? '+' : ''}${fmtDec(weightedPnl)}%`,
      sub: 'portföljviktat',
      color: weightedPnl >= 0 ? '#2ecc71' : '#e74c3c',
      bar: null,
    },
    {
      label: 'Live-kurser',
      value: `${liveCount}/${enriched.length}`,
      sub: liveCount === enriched.length ? 'Alla live' : 'Hämta data',
      color: liveCount === enriched.length ? '#2ecc71' : '#f1c40f',
      bar: enriched.length > 0 ? (liveCount / enriched.length) * 100 : 0,
    },
  ];

  return (
    <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, padding: '14px 18px', marginBottom: 18 }}>
      <div style={{ fontFamily: 'monospace', fontSize: 9, letterSpacing: 1.5, color: '#3d5a72', textTransform: 'uppercase', marginBottom: 12 }}>
        Riskexponering
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
        {metrics.map((m, i) => (
          <div key={i}>
            <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 5 }}>{m.label}</div>
            <div style={{ fontFamily: 'monospace', fontSize: 16, fontWeight: 700, color: m.color, marginBottom: 4 }}>{m.value}</div>
            <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94', marginBottom: 6 }}>{m.sub}</div>
            {m.bar != null && (
              <div style={{ height: 4, background: '#1a2535', borderRadius: 2, overflow: 'hidden' }}>
                <div style={{ width: `${Math.min(m.bar, 100)}%`, height: '100%', background: m.color, borderRadius: 2 }} />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}