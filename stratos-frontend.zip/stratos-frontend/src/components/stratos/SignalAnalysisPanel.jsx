import React, { useState, useEffect } from 'react';
import { invokeFunction, Trade, Watchlist, Instrument } from '@/api/supabaseClient';

const STRENGTH_CONFIG = {
  strong: { label: 'Stark signal', color: '#2ecc71', bg: 'rgba(46,204,113,0.1)', bar: 3 },
  medium: { label: 'Medel signal', color: '#f1c40f', bg: 'rgba(241,196,15,0.1)', bar: 2 },
  weak: { label: 'Svag signal', color: '#e74c3c', bg: 'rgba(231,76,60,0.1)', bar: 1 },
};

function SignalStrengthBar({ strength }) {
  const cfg = STRENGTH_CONFIG[strength] || STRENGTH_CONFIG.medium;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <div style={{ display: 'flex', gap: 3 }}>
        {[1, 2, 3].map(i => (
          <div key={i} style={{
            width: 18, height: 10, borderRadius: 2,
            background: i <= cfg.bar ? cfg.color : '#1e2d3d',
          }} />
        ))}
      </div>
      <span style={{ fontFamily: 'monospace', fontSize: 11, color: cfg.color, fontWeight: 700 }}>
        {cfg.label}
      </span>
    </div>
  );
}

function Section({ icon, title, color, children }) {
  return (
    <div style={{
      background: '#0d1219', border: `1px solid ${color}22`,
      borderRadius: 7, padding: '12px 14px',
    }}>
      <div style={{
        fontFamily: 'monospace', fontSize: 9, letterSpacing: 1.5,
        color: color, textTransform: 'uppercase', marginBottom: 10,
      }}>
        {icon} {title}
      </div>
      {children}
    </div>
  );
}

function BulletList({ items, color = '#3ecfff', icon = '▸' }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      {(items || []).map((item, i) => (
        <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
          <span style={{ color, fontSize: 10, marginTop: 2, flexShrink: 0 }}>{icon}</span>
          <span style={{ fontSize: 12, color: '#dce8f5', lineHeight: 1.6 }}>{item}</span>
        </div>
      ))}
    </div>
  );
}

export default function SignalAnalysisPanel({ ticker, signal, marketData, onClose }) {
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAnalysis = async () => {
      try {
        setLoading(true);
        // Build market data object from signal + passed marketData
        const md = marketData || {};
        const signalData = {
          ...md,
          name: signal?.company_name || ticker,
          price: signal?.entry || md.price,
          ema20: signal?.ema20 || md.ema20,
          ema50: signal?.ema50 || md.ema50,
          rsi: signal?.rsi || md.rsi,
          atr: signal?.atr || md.atr,
          sector: signal?.sector || md.sector,
          currency: signal?.currency || md.currency || 'SEK',
        };
        const res = await invokeFunction('analyzeStockSignal', {
          ticker,
          marketData: signalData,
        });
        setAnalysis(res.data?.analysis);
        setError(null);
      } catch (err) {
        setError(err.message || 'Kunde inte analysera signal');
      } finally {
        setLoading(false);
      }
    };
    fetchAnalysis();
  }, [ticker]);

  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', zIndex: 1000,
      display: 'flex', alignItems: 'flex-start', justifyContent: 'center',
      padding: 20, overflowY: 'auto',
    }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div style={{
        background: '#080c10', border: '1px solid #1e2d3d', borderRadius: 10,
        padding: 24, maxWidth: 700, width: '100%', marginTop: 40, marginBottom: 40,
        fontFamily: "'DM Sans', sans-serif",
        boxShadow: '0 0 60px rgba(62,207,255,0.08)',
      }}>
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
              <span style={{ fontFamily: 'monospace', fontSize: 22, fontWeight: 800, color: '#dce8f5' }}>{ticker}</span>
              {signal?.company_name && (
                <span style={{ fontSize: 13, color: '#5a7a94' }}>{signal.company_name}</span>
              )}
            </div>
            <p style={{ fontSize: 11, color: '#3ecfff', margin: 0, fontFamily: 'monospace', letterSpacing: 1 }}>
              ✦ AI KÖPSIGNALANALYS
            </p>
          </div>
          <button onClick={onClose} style={{
            background: 'rgba(255,255,255,0.05)', border: '1px solid #1e2d3d', color: '#5a7a94',
            fontSize: 16, cursor: 'pointer', padding: '4px 10px', borderRadius: 6,
          }}>✕</button>
        </div>

        {loading && (
          <div style={{ textAlign: 'center', padding: '60px 20px', color: '#5a7a94' }}>
            <div style={{ fontSize: 24, marginBottom: 12 }}>⟳</div>
            <div style={{ fontFamily: 'monospace', fontSize: 12 }}>Analyserar signaldata…</div>
          </div>
        )}

        {error && (
          <div style={{
            background: 'rgba(231,76,60,0.08)', border: '1px solid rgba(231,76,60,0.2)',
            borderRadius: 6, padding: 14, color: '#e74c3c', fontSize: 12,
          }}>
            Fel: {error}
          </div>
        )}

        {analysis && !loading && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {/* Signal strength + summary */}
            <div style={{
              background: 'rgba(62,207,255,0.05)', border: '1px solid rgba(62,207,255,0.15)',
              borderRadius: 7, padding: '14px 16px',
            }}>
              <div style={{ marginBottom: 8 }}>
                <SignalStrengthBar strength={analysis.signal_strength} />
              </div>
              <p style={{ fontSize: 13, color: '#dce8f5', lineHeight: 1.7, margin: 0 }}>
                {analysis.summary}
              </p>
            </div>

            {/* Technical reasons */}
            {analysis.technical_reasons?.length > 0 && (
              <Section icon="📈" title="Tekniska skäl till signalen" color="#3ecfff">
                <BulletList items={analysis.technical_reasons} color="#3ecfff" />
              </Section>
            )}

            {/* Strengths + Risks side by side */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              {analysis.strengths?.length > 0 && (
                <Section icon="✓" title="Styrkor" color="#2ecc71">
                  <BulletList items={analysis.strengths} color="#2ecc71" icon="✓" />
                </Section>
              )}
              {analysis.risks?.length > 0 && (
                <Section icon="⚠" title="Risker" color="#e74c3c">
                  <BulletList items={analysis.risks} color="#e74c3c" icon="⚠" />
                </Section>
              )}
            </div>

            {/* Entry advice */}
            {analysis.entry_advice && (
              <Section icon="🎯" title="Ingångsstrategi" color="#f1c40f">
                <p style={{ fontSize: 12, color: '#dce8f5', lineHeight: 1.7, margin: 0 }}>
                  {analysis.entry_advice}
                </p>
              </Section>
            )}

            {/* Outlook */}
            {analysis.outlook && (
              <Section icon="🔭" title="Utsikt" color="#9b59b6">
                <p style={{ fontSize: 12, color: '#dce8f5', lineHeight: 1.7, margin: 0 }}>
                  {analysis.outlook}
                </p>
              </Section>
            )}

            {/* Signal key data */}
            {signal && (
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {[
                  { label: 'Ingång', value: signal.entry?.toFixed(2), color: '#dce8f5' },
                  { label: 'Stop', value: signal.stop?.toFixed(2), color: '#e74c3c' },
                  { label: 'TP', value: (signal.tp || signal.take_profit)?.toFixed(2), color: '#2ecc71' },
                  { label: 'RSI', value: signal.rsi?.toFixed(1), color: signal.rsi > 70 ? '#e74c3c' : signal.rsi < 30 ? '#2ecc71' : '#3ecfff' },
                  { label: 'EMA20', value: signal.ema20?.toFixed(2), color: '#3ecfff' },
                  { label: 'EMA50', value: signal.ema50?.toFixed(2), color: '#f1c40f' },
                ].filter(i => i.value).map(item => (
                  <div key={item.label} style={{
                    background: '#131b24', border: '1px solid #1e2d3d',
                    borderRadius: 6, padding: '6px 12px', textAlign: 'center',
                  }}>
                    <div style={{ fontFamily: 'monospace', fontSize: 8, color: '#3d5a72', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 2 }}>{item.label}</div>
                    <div style={{ fontFamily: 'monospace', fontSize: 13, fontWeight: 700, color: item.color }}>{item.value}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}