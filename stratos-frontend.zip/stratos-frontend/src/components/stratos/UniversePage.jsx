import React, { useState, useEffect } from 'react';
import { invokeFunction, Trade, Watchlist, Instrument, Signal } from '@/api/supabaseClient';
import { MARKETS, ALL_INSTRUMENTS, SEG_LABELS } from './instruments';
import { AddToWatchlistModal, AddTradeModal } from './universe/QuickAddModal';

const SOURCE_COLORS = {
  yahoo: '#3ecfff',
  twelvedata: '#9b59b6',
  finnhub: '#f1c40f',
  manual: '#ff6b35',
};

const SEG_TAG_COLORS = {
  large: { bg: 'rgba(62,207,255,0.1)', color: '#3ecfff' },
  mid:   { bg: 'rgba(155,89,182,0.12)', color: '#9b59b6' },
  small: { bg: 'rgba(241,196,15,0.1)',  color: '#f1c40f' },
  fn:    { bg: 'rgba(255,107,53,0.1)',  color: '#ff6b35' },
};

const PAGE_SIZE = 100;

function ManualPriceInput({ inst, onSaved }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState('');
  const [saving, setSaving] = useState(false);

  if (!inst.id) return null; // only DB instruments

  if (!editing) {
    return (
      <button onClick={() => { setVal(inst.manual_price || ''); setEditing(true); }}
        style={{ fontFamily: 'monospace', fontSize: 10, color: inst.manual_price ? '#ff6b35' : '#3d5a72', background: 'transparent', border: 'none', cursor: 'pointer', padding: 0 }}>
        {inst.manual_price ? `${inst.manual_price} ✎` : '+ manuell'}
      </button>
    );
  }

  const save = async () => {
    const price = parseFloat(val);
    if (isNaN(price)) { setEditing(false); return; }
    setSaving(true);
    const updated = await Instrument.update(inst.id, {
      manual_price: price,
      manual_price_updated: new Date().toISOString(),
      last_price: price,
      last_price_source: 'manual',
    });
    onSaved({ ...inst, ...updated, manual_price: price, last_price: price, last_price_source: 'manual' });
    setSaving(false);
    setEditing(false);
  };

  return (
    <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
      <input autoFocus type="number" value={val} onChange={e => setVal(e.target.value)}
        onKeyDown={e => { if (e.key === 'Enter') save(); if (e.key === 'Escape') setEditing(false); }}
        style={{ width: 70, padding: '2px 6px', background: '#131b24', border: '1px solid #ff6b35', borderRadius: 4, color: '#dce8f5', fontSize: 11, fontFamily: 'monospace', outline: 'none' }} />
      <button onClick={save} disabled={saving} style={{ fontFamily: 'monospace', fontSize: 10, color: '#2ecc71', background: 'transparent', border: 'none', cursor: 'pointer' }}>✓</button>
      <button onClick={() => setEditing(false)} style={{ fontFamily: 'monospace', fontSize: 10, color: '#e74c3c', background: 'transparent', border: 'none', cursor: 'pointer' }}>✗</button>
    </div>
  );
}

export default function UniversePage({ activeMarkets, marketData }) {
  const [marketFilter, setMarketFilter] = useState('all');
  const [segFilter, setSegFilter]       = useState('all');
  const [search, setSearch]             = useState('');
  const [dbInstruments, setDbInstruments] = useState([]);
  const [dbLoaded, setDbLoaded]         = useState(false);
  const [page, setPage]                 = useState(0);
  const [syncing, setSyncing]           = useState(null);
  const [syncResult, setSyncResult]     = useState({});
  const [watchlist, setWatchlist]       = useState([]);
  const [watchlistModal, setWatchlistModal] = useState(null); // inst
  const [tradeModal, setTradeModal]     = useState(null); // inst

  useEffect(() => {
    Promise.all([
      Instrument.list('-created_date', 10000),
      Watchlist.list(),
    ]).then(([instData, wlData]) => {
      setDbInstruments(instData);
      setWatchlist(wlData);
      setDbLoaded(true);
    }).catch(err => {
      console.error('Failed to load instruments:', err);
      setDbLoaded(true);
    });
  }, []);

  // Merge DB + hardcoded, DB takes priority
  const hardcodedMapped = ALL_INSTRUMENTS.map(i => ({
    ticker: i.t,
    yahoo_symbol: i.yahooSymbol || i.t,
    company_name: i.n,
    market: i.market,
    segment: i.seg,
    sector: i.s,
    currency: MARKETS[i.market]?.currency || 'SEK',
    _source: 'local',
  }));

  const dbSymbols = new Set(dbInstruments.map(d => d.ticker + ':' + d.market));
  const allInstruments = [
    ...dbInstruments.map(d => ({ ...d, _source: 'db' })),
    ...hardcodedMapped.filter(h => !dbSymbols.has(h.ticker + ':' + h.market)),
  ];

  const q = search.trim().toLowerCase();
  const filtered = allInstruments.filter(i => {
    if (marketFilter !== 'all' && i.market !== marketFilter) return false;
    if (segFilter !== 'all' && i.segment !== segFilter) return false;
    if (q && !i.ticker?.toLowerCase().includes(q) && !i.company_name?.toLowerCase().includes(q)) return false;
    return true;
  });

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const pageData   = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  const marketCounts = {};
   allInstruments.forEach(i => { marketCounts[i.market] = (marketCounts[i.market] || 0) + 1; });

   // Sort by signals first, then by most recent
   const signalTickers = new Set(marketData ? Object.values(marketData).filter(d => d.signal).map(d => d.t) : []);
   const pageDataSorted = pageData.sort((a, b) => {
     const aHasSignal = signalTickers.has(a.ticker);
     const bHasSignal = signalTickers.has(b.ticker);
     if (aHasSignal !== bHasSignal) return aHasSignal ? -1 : 1;
     return 0;
   });

   const resetPage = (fn) => { fn(); setPage(0); };

  const syncMarket = async (marketId) => {
    setSyncing(marketId);
    setSyncResult(prev => ({ ...prev, [marketId]: null }));
    try {
      const res = await invokeFunction('syncInstruments', { market: marketId });
      const data = res.data || {};
      setSyncResult(prev => ({ ...prev, [marketId]: data }));
      // Reload DB instruments after sync
      const updated = await Instrument.list('-created_date', 10000);
      setDbInstruments(updated);
    } catch (e) {
      setSyncResult(prev => ({ ...prev, [marketId]: { error: e.message } }));
    }
    setSyncing(null);
  };

  const seedLocalToDB = async () => {
    setSyncing('local');
    try {
      const res = await invokeFunction('seedLocalInstrumentsToDB', {});
      // Reload DB instruments
      const updated = await Instrument.list('-created_date', 10000);
      setDbInstruments(updated);
      setSyncResult(prev => ({ ...prev, local: res.data }));
    } catch (e) {
      setSyncResult(prev => ({ ...prev, local: { error: e.message } }));
    }
    setSyncing(null);
  };

  return (
    <div style={{ padding: 24 }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20 }}>
         <div>
           <div style={{ fontSize: 22, fontWeight: 800 }}>Universum</div>
           <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', marginTop: 3 }}>
             {allInstruments.length.toLocaleString('sv-SE')} instrument totalt
             {dbLoaded && <span style={{ color: '#2ecc71', marginLeft: 8 }}>● {dbInstruments.length.toLocaleString('sv-SE')} i databas</span>}
           </div>
         </div>
         <button
           onClick={seedLocalToDB}
           disabled={syncing === 'local'}
           title="Seed all local instruments to database"
           style={{
             fontFamily: 'monospace', fontSize: 11, padding: '6px 12px', borderRadius: 6,
             background: 'rgba(46,204,113,0.1)', border: '1px solid rgba(46,204,113,0.3)',
             color: '#2ecc71', cursor: syncing === 'local' ? 'not-allowed' : 'pointer',
             fontWeight: 700, opacity: syncing === 'local' ? 0.6 : 1,
           }}
         >
           {syncing === 'local' ? '⟳ Seeding…' : '⬇ Seed Local'}
         </button>
       </div>

      {/* Market summary cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: 10, marginBottom: 18 }}>
        {Object.values(MARKETS).map(m => {
          const count  = marketCounts[m.id] || 0;
          const loaded = Object.values(marketData).filter(d => d.market === m.id).length;
          const isSyncing = syncing === m.id;
          const result = syncResult[m.id];
          return (
            <div key={m.id} style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, padding: '11px 13px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div style={{ fontSize: 20 }}>{m.flag}</div>
                <button
                  onClick={() => syncMarket(m.id)}
                  disabled={!!syncing}
                  title={`Synka ${m.label} från börsen`}
                  style={{
                    background: isSyncing ? 'rgba(62,207,255,0.05)' : 'rgba(62,207,255,0.08)',
                    border: '1px solid rgba(62,207,255,0.2)',
                    color: '#3ecfff', borderRadius: 4, cursor: syncing ? 'not-allowed' : 'pointer',
                    fontSize: 10, padding: '2px 7px', fontFamily: 'monospace', fontWeight: 700,
                    opacity: syncing && !isSyncing ? 0.4 : 1,
                  }}
                >
                  {isSyncing ? '⟳ Synkar…' : '⟳ Sync'}
                </button>
              </div>
              <div style={{ fontWeight: 700, fontSize: 13, marginTop: 4 }}>{m.label}</div>
              <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', marginTop: 2 }}>{count.toLocaleString('sv-SE')} aktier</div>
              {loaded > 0 && <div style={{ fontFamily: 'monospace', fontSize: 10, color: '#2ecc71', marginTop: 2 }}>{loaded} laddade</div>}
              {result && !result.error && (
                <div style={{ fontFamily: 'monospace', fontSize: 10, color: '#2ecc71', marginTop: 3 }}>
                  +{result.created} nya · {result.total} totalt
                </div>
              )}
              {result?.error && (
                <div style={{ fontFamily: 'monospace', fontSize: 10, color: '#e74c3c', marginTop: 3 }}>
                  Fel: {result.error}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Search + Filters */}
      <div style={{ marginBottom: 12 }}>
        <input
          type="text"
          placeholder="Sök ticker eller bolagsnamn…"
          value={search}
          onChange={e => { setSearch(e.target.value); setPage(0); }}
          style={{
            width: '100%', marginBottom: 10, padding: '9px 14px',
            background: '#0d1219', border: '1px solid #253649', borderRadius: 7,
            color: '#dce8f5', fontSize: 12, outline: 'none',
          }}
        />
        <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
          {[{ id: 'all', label: 'Alla marknader' }, ...Object.values(MARKETS).map(m => ({ id: m.id, label: m.flag + ' ' + m.label }))].map(f => (
            <button key={f.id} onClick={() => resetPage(() => setMarketFilter(f.id))} style={{
              fontFamily: 'monospace', fontSize: 11, padding: '4px 10px', borderRadius: 4, cursor: 'pointer',
              border: marketFilter === f.id ? '1px solid #3ecfff' : '1px solid #253649',
              background: marketFilter === f.id ? 'rgba(62,207,255,0.06)' : 'transparent',
              color: marketFilter === f.id ? '#3ecfff' : '#5a7a94',
            }}>{f.label}</button>
          ))}
          <div style={{ width: 1, height: 28, background: '#1e2d3d', margin: '0 4px' }} />
          {['all', 'large', 'mid', 'small', 'fn'].map(s => (
            <button key={s} onClick={() => resetPage(() => setSegFilter(s))} style={{
              fontFamily: 'monospace', fontSize: 11, padding: '4px 10px', borderRadius: 4, cursor: 'pointer',
              border: segFilter === s ? '1px solid #3ecfff' : '1px solid #253649',
              background: segFilter === s ? 'rgba(62,207,255,0.06)' : 'transparent',
              color: segFilter === s ? '#3ecfff' : '#5a7a94',
            }}>{s === 'all' ? 'Alla segment' : SEG_LABELS[s] || s}</button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, overflow: 'hidden' }}>
        <div style={{ padding: '10px 15px', borderBottom: '1px solid #1e2d3d', background: '#131b24', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94' }}>{filtered.length.toLocaleString('sv-SE')} instrument visas</span>
          {totalPages > 1 && (
            <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
              <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0} style={{ fontFamily: 'monospace', fontSize: 11, padding: '2px 8px', borderRadius: 4, border: '1px solid #253649', background: 'transparent', color: page === 0 ? '#3d5a72' : '#dce8f5', cursor: page === 0 ? 'default' : 'pointer' }}>←</button>
              <span style={{ fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>{page + 1} / {totalPages}</span>
              <button onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))} disabled={page === totalPages - 1} style={{ fontFamily: 'monospace', fontSize: 11, padding: '2px 8px', borderRadius: 4, border: '1px solid #253649', background: 'transparent', color: page === totalPages - 1 ? '#3d5a72' : '#dce8f5', cursor: page === totalPages - 1 ? 'default' : 'pointer' }}>→</button>
            </div>
          )}
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: '#131b24' }}>
                {['Ticker', 'Yahoo', 'Bolag', 'Marknad', 'Segment', 'Sektor', 'Kurs', 'Källa', 'Manuellt pris', 'Status'].map(h => (
                  <th key={h} style={{ padding: '9px 13px', textAlign: 'left', fontFamily: 'monospace', fontSize: 9, letterSpacing: 1.5, color: '#3d5a72', textTransform: 'uppercase', borderBottom: '1px solid #1e2d3d' }}>{h}</th>
                  ))}
                  <th style={{ padding: '9px 13px', borderBottom: '1px solid #1e2d3d' }} />
                  </tr>
                  </thead>
                  <tbody>
                  {pageDataSorted.map((inst, i) => {
                   const d = marketData[`${inst.market}:${inst.ticker}`];
                   const m = MARKETS[inst.market];
                   const segStyle = SEG_TAG_COLORS[inst.segment] || {};
                   const inWatchlist = watchlist.some(w => w.ticker === inst.ticker && w.market === inst.market);
                   const hasSignal = signalTickers.has(inst.ticker);
                   const price = d?.price || inst.last_price || inst.manual_price;
                   const priceColor = d?.price ? '#2ecc71' : inst.last_price ? '#9b59b6' : inst.manual_price ? '#ff6b35' : '#3d5a72';
                   return (
                   <tr key={i} style={{ borderBottom: '1px solid rgba(30,45,61,0.5)', background: hasSignal ? 'rgba(46,204,113,0.05)' : 'transparent' }}>
                     <td style={{ padding: '9px 13px', fontFamily: 'monospace', fontWeight: 700, fontSize: 12, color: hasSignal ? '#2ecc71' : '#dce8f5' }}>{inst.ticker} {hasSignal && '⭐'}</td>
                     <td style={{ padding: '9px 13px', fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>{inst.yahoo_symbol !== inst.ticker ? inst.yahoo_symbol : '—'}</td>
                     <td style={{ padding: '9px 13px', fontSize: 11, color: '#dce8f5', maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{inst.company_name}</td>
                     <td style={{ padding: '9px 13px', fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', whiteSpace: 'nowrap' }}>{m?.flag} {m?.label || inst.market}</td>
                     <td style={{ padding: '9px 13px' }}>
                       {inst.segment && (
                         <span style={{ display: 'inline-block', fontFamily: 'monospace', fontSize: 9, padding: '2px 6px', borderRadius: 3, textTransform: 'uppercase', background: segStyle.bg || 'rgba(62,207,255,0.1)', color: segStyle.color || '#3ecfff' }}>
                           {SEG_LABELS[inst.segment] || inst.segment}
                         </span>
                       )}
                     </td>
                     <td style={{ padding: '9px 13px', fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>{inst.sector || inst.pe_ratio ? `${inst.pe_ratio ? 'P/E:' + inst.pe_ratio.toFixed(1) : ''}` : '—'}</td>
                     <td style={{ padding: '9px 13px', fontFamily: 'monospace', fontSize: 12, color: priceColor }}>
                       {price ? `${price.toFixed(2)} ${inst.currency || ''}` : '—'}
                     </td>
                     <td style={{ padding: '9px 13px', fontFamily: 'monospace', fontSize: 10 }}>
                       {d ? <span style={{ color: '#2ecc71' }}>●</span> : inst.last_price ? <span style={{ color: '#9b59b6' }}>●</span> : inst.manual_price ? <span style={{ color: '#ff6b35' }}>●</span> : <span style={{ color: '#3d5a72' }}>○</span>}
                     </td>
                     <td style={{ padding: '9px 13px' }}>
                       <ManualPriceInput inst={inst} onSaved={(updated) => {
                         setDbInstruments(prev => prev.map(x => x.id === updated.id ? updated : x));
                       }} />
                     </td>
                     <td style={{ padding: '9px 13px' }}>
                       {hasSignal && <span style={{ color: '#2ecc71', fontFamily: 'monospace', fontSize: 10 }}>⭐ Signal</span>}
                     </td>
                    {/* Action buttons */}
                    <td style={{ padding: '9px 13px' }}>
                      <div style={{ display: 'flex', gap: 5 }}>
                        <button
                          onClick={() => setWatchlistModal(inst)}
                          title="Lägg till i bevakningslista"
                          style={{
                            background: inWatchlist ? 'rgba(46,204,113,0.1)' : 'rgba(62,207,255,0.07)',
                            border: inWatchlist ? '1px solid rgba(46,204,113,0.3)' : '1px solid rgba(62,207,255,0.2)',
                            color: inWatchlist ? '#2ecc71' : '#3ecfff',
                            padding: '3px 8px', borderRadius: 4, cursor: 'pointer', fontSize: 11, fontWeight: 700,
                            whiteSpace: 'nowrap',
                          }}
                        >
                          {inWatchlist ? '★' : '☆'}
                        </button>
                        <button
                          onClick={() => setTradeModal(inst)}
                          title="Registrera affär"
                          style={{
                            background: 'rgba(46,204,113,0.07)',
                            border: '1px solid rgba(46,204,113,0.2)',
                            color: '#2ecc71',
                            padding: '3px 8px', borderRadius: 4, cursor: 'pointer', fontSize: 11, fontWeight: 700,
                          }}
                        >
                          ▲
                        </button>
                      </div>
                    </td>
                  </tr>
                  );
                  })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modals */}
      {watchlistModal && (
        <AddToWatchlistModal
          inst={watchlistModal}
          existingWatchlist={watchlist}
          onClose={() => setWatchlistModal(null)}
          onAdded={(record) => setWatchlist(prev => [...prev, record])}
        />
      )}
      {tradeModal && (
        <AddTradeModal
          inst={tradeModal}
          onClose={() => setTradeModal(null)}
          onAdded={() => {}}
        />
      )}
    </div>
  );
}