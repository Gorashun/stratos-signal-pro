import React from 'react';
import { useAuth } from '@/lib/AuthContext';

export default function TopBar({ regime, fetching, fetchProgress, onRunCycle, onFetchData, onGenerateSignals }) {
  const { user, signOut } = useAuth();
  const regimeColor = regime === 'bull' ? '#2ecc71' : regime === 'bear' ? '#e74c3c' : '#f1c40f';
  const regimeLabel = regime === 'bull' ? '📈 BULL' : regime === 'bear' ? '📉 BEAR' : '➡ NEUTRAL';

  return (
    <div style={{
      position: 'sticky', top: 0, zIndex: 100,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 24px', height: 54,
      background: 'rgba(8,12,16,0.97)', borderBottom: '1px solid #1e2d3d',
      backdropFilter: 'blur(12px)',
    }}>
      <div style={{ fontWeight: 800, fontSize: 20, letterSpacing: '-0.5px', fontFamily: "'DM Sans', sans-serif" }}>
        Strat<span style={{ color: '#3ecfff' }}>OS</span>
        <span style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', fontWeight: 400, marginLeft: 8 }}>
          // Signal Intelligence
        </span>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        {fetching && fetchProgress.total > 0 && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontFamily: 'monospace', fontSize: 11, color: '#3ecfff' }}>
            <span style={{ display: 'inline-block', width: 10, height: 10, border: '2px solid rgba(62,207,255,0.25)', borderTopColor: '#3ecfff', borderRadius: '50%', animation: 'spin 0.5s linear infinite' }} />
            <span>{fetchProgress.current || 'Hämtar…'}</span>
            <div style={{ width: 100, height: 3, background: '#1a2535', borderRadius: 2, overflow: 'hidden' }}>
              <div style={{ height: '100%', background: '#3ecfff', width: `${(fetchProgress.done / fetchProgress.total) * 100}%`, transition: 'width 0.3s' }} />
            </div>
            <span>{fetchProgress.done}/{fetchProgress.total}</span>
          </div>
        )}

        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontFamily: 'monospace', fontSize: 11 }}>
          <span style={{ color: '#5a7a94' }}>Regime:</span>
          <span style={{ color: regimeColor, fontWeight: 700 }}>{regimeLabel}</span>
        </div>

        <button onClick={onFetchData} disabled={fetching}
          style={{ background: 'transparent', border: '1px solid #253649', color: '#dce8f5', padding: '6px 14px', borderRadius: 6, cursor: fetching ? 'not-allowed' : 'pointer', fontSize: 12, fontWeight: 700, opacity: fetching ? 0.4 : 1 }}>
          ⟳ Hämta data
        </button>

        <button onClick={onGenerateSignals} disabled={fetching}
          style={{ background: 'transparent', border: '1px solid #253649', color: '#dce8f5', padding: '6px 14px', borderRadius: 6, cursor: fetching ? 'not-allowed' : 'pointer', fontSize: 12, fontWeight: 700, opacity: fetching ? 0.4 : 1 }}>
          ⚡ Signaler
        </button>

        <button onClick={onRunCycle} disabled={fetching}
          style={{ background: '#3ecfff', border: '1px solid #3ecfff', color: '#080c10', padding: '6px 14px', borderRadius: 6, cursor: fetching ? 'not-allowed' : 'pointer', fontSize: 12, fontWeight: 700, opacity: fetching ? 0.4 : 1 }}>
          ▶ Kör cykel
        </button>

        <div style={{ width: 1, height: 24, background: '#1e2d3d' }} />

        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>{user?.email}</span>
          <button onClick={signOut}
            style={{ background: 'transparent', border: '1px solid #253649', color: '#5a7a94', padding: '4px 10px', borderRadius: 5, cursor: 'pointer', fontSize: 11 }}>
            Logga ut
          </button>
        </div>
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
