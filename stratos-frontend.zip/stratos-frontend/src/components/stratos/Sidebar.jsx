import React from 'react';

const NAV = [
  { id: 'dashboard', icon: '◈', label: 'Dashboard' },
  { id: 'signals', icon: '⚡', label: 'Signaler' },
  { id: 'portfolio', icon: '◐', label: 'Portföljanalys' },
  { id: 'portfolio_suggestion', icon: '◆', label: 'Portföljförslag' },
  { id: 'strategy', icon: '✦', label: 'Strategi' },
  { id: 'universe', icon: '◉', label: 'Universum' },
  { id: 'watchlist', icon: '★', label: 'Bevakningslista' },
  { id: 'logs', icon: '≡', label: 'Loggar' },
  { id: 'settings', icon: '⚙', label: 'Inställningar' },
];

export default function Sidebar({ activePage, onNavigate, signals, marketDataCount }) {
  const approvedCount = signals.filter(s => s.status === 'APPROVED').length;

  return (
    <aside style={{
      width: 210, flexShrink: 0, borderRight: '1px solid #1e2d3d',
      padding: '14px 10px', display: 'flex', flexDirection: 'column', gap: 1,
      background: '#0d1219',
    }}>
      <div style={{ fontFamily: 'monospace', fontSize: 9, letterSpacing: 2, color: '#3d5a72', textTransform: 'uppercase', padding: '8px 8px 4px' }}>Översikt</div>
      {NAV.slice(0, 2).map(item => (
        <NavItem key={item.id} item={item} active={activePage === item.id} onClick={() => onNavigate(item.id)}
          badge={item.id === 'signals' ? approvedCount : null} />
      ))}

      <div style={{ fontFamily: 'monospace', fontSize: 9, letterSpacing: 2, color: '#3d5a72', textTransform: 'uppercase', padding: '11px 8px 4px' }}>Konfiguration</div>
      {NAV.slice(2, 6).map(item => (
        <NavItem key={item.id} item={item} active={activePage === item.id} onClick={() => onNavigate(item.id)}
          badge={item.id === 'universe' ? marketDataCount || null : null} />
      ))}

      <div style={{ fontFamily: 'monospace', fontSize: 9, letterSpacing: 2, color: '#3d5a72', textTransform: 'uppercase', padding: '11px 8px 4px' }}>System</div>
      {NAV.slice(6).map(item => (
        <NavItem key={item.id} item={item} active={activePage === item.id} onClick={() => onNavigate(item.id)} />
      ))}

      <div style={{ marginTop: 'auto', paddingTop: 14, borderTop: '1px solid #1e2d3d', fontFamily: 'monospace', fontSize: 9, color: '#3d5a72', lineHeight: 1.9 }}>
        DATA: Yahoo Finance<br />
        SUFFIX: .ST / .L / .DE<br />
        <span style={{ color: '#2ecc71' }}>GRATIS · Ingen nyckel</span>
      </div>
    </aside>
  );
}

function NavItem({ item, active, onClick, badge }) {
  return (
    <div
      onClick={onClick}
      style={{
        display: 'flex', alignItems: 'center', gap: 8,
        padding: '7px 8px', borderRadius: 5, fontSize: 13, fontWeight: 500,
        cursor: 'pointer', transition: 'all 0.1s',
        border: active ? '1px solid rgba(62,207,255,0.15)' : '1px solid transparent',
        background: active ? 'rgba(62,207,255,0.07)' : 'transparent',
        color: active ? '#3ecfff' : '#5a7a94',
      }}
    >
      <span>{item.icon}</span>
      <span style={{ flex: 1 }}>{item.label}</span>
      {badge != null && badge > 0 && (
        <span style={{
          background: '#3ecfff', color: '#080c10', fontFamily: 'monospace',
          fontSize: 9, fontWeight: 700, padding: '1px 6px', borderRadius: 9, minWidth: 18, textAlign: 'center',
        }}>{badge}</span>
      )}
    </div>
  );
}