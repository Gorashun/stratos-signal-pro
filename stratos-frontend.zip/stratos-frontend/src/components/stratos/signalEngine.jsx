// ── SIGNAL ENGINE ──────────────────────────────────────────────────────

export function evalEntry(d, rules) {
  for (const entry of (rules?.entries || [])) {
    const pass = (entry.all_of || []).every(c => {
      if (c.indicator === 'ema20_gt_ema50') return d.e20gE50 === c.value;
      if (c.indicator === 'close_gt_sma200') return d.closeGtS200 === c.value;
      if (c.indicator === 'price_gt_ema50') return d.price > d.ema50;
      if (c.indicator === 'rsi14') {
        if (c.op === '>') return d.rsi > c.value;
        if (c.op === '<') return d.rsi < c.value;
        if (c.op === 'between') return d.rsi >= c.min && d.rsi <= c.max;
      }
      return true;
    });
    if (pass) {
      const atr = d.atr || d.price * 0.02;
      const sm = rules.exits?.[0]?.atr_mult || 2.5;
      const tm = rules.exits?.[1]?.atr_mult || 3.5;
      return {
        type: 'KÖP',
        entry: d.price,
        stop: +(d.price - sm * atr).toFixed(2),
        tp: +(d.price + tm * atr).toFixed(2),
        riskPct: rules.position_sizing?.risk_per_trade || 0.005,
        rule: entry.name,
      };
    }
  }
  return null;
}

export function defRules() {
  return {
    name: 'TrendSwing Standard',
    description: 'Trendföljning + swing för globala marknader',
    entries: [
      {
        name: 'TrendBreakout',
        all_of: [
          { indicator: 'ema20_gt_ema50', value: true },
          { indicator: 'close_gt_sma200', value: true },
          { indicator: 'rsi14', op: '>', value: 50 },
        ],
      },
      {
        name: 'SwingSetup',
        all_of: [
          { indicator: 'ema20_gt_ema50', value: true },
          { indicator: 'rsi14', op: 'between', min: 40, max: 65 },
          { indicator: 'price_gt_ema50', value: true },
        ],
      },
    ],
    exits: [
      { type: 'atr_stop', atr_mult: 2.5 },
      { type: 'trailing_atr', atr_mult: 3.5 },
    ],
    position_sizing: {
      risk_per_trade: 0.005,
      max_positions: 10,
      max_sector_exposure: 0.25,
    },
    risk: { max_drawdown: 0.12, daily_loss_limit: 0.02 },
    regime: { bear: { allow_longs: false } },
  };
}

export function detectRegime(marketData) {
  const lc = Object.values(marketData).filter(d => d.market === 'sweden' && d.seg === 'large');
  if (!lc.length) return 'neutral';
  const bull = lc.filter(d => d.e20gE50 && d.closeGtS200).length / lc.length;
  const avgRsi = lc.reduce((a, d) => a + (d.rsi || 50), 0) / lc.length;
  if (bull > 0.55 && avgRsi > 50) return 'bull';
  if (bull < 0.35 && avgRsi < 45) return 'bear';
  return 'neutral';
}

export function runSignalEngine(marketData, rules, regime, volLimits, minPrice = 2) {
  const signals = [];
  for (const d of Object.values(marketData)) {
    if (!d || !d.price || !d.rsi) continue;
    if (regime === 'bear' && rules.regime?.bear?.allow_longs === false && d.market === 'sweden') continue;

    const sig = evalEntry(d, rules);
    if (!sig) continue;

    const marketLimits = volLimits[d.market] || {};
    const minVol = marketLimits[d.seg] || 200000;
    let status = 'APPROVED', reason = '';

    if ((d.avgVol || 0) < minVol) {
      status = 'REJECTED';
      reason = `Volym < ${(minVol / 1000).toFixed(0)}k`;
    } else if ((d.price || 0) < minPrice && d.market === 'sweden') {
      status = 'REJECTED';
      reason = `Kurs < ${minPrice} SEK`;
    }

    signals.push({
      ...sig,
      ticker: d.t,
      name: d.n,
      market: d.market,
      seg: d.seg,
      sector: d.s,
      price: d.price,
      change: d.change,
      currency: d.currency || 'SEK',
      rsi: d.rsi,
      ema20: d.ema20,
      ema50: d.ema50,
      atr: d.atr,
      status,
      reason,
    });
  }
  // Sort: APPROVED first, then by market (sweden first)
  return signals.sort((a, b) => {
    if (a.status === b.status) return a.market === 'sweden' ? -1 : 1;
    return a.status === 'APPROVED' ? -1 : 1;
  });
}