import React, { useState } from 'react';
import { invokeFunction, Trade, Watchlist, Instrument } from '@/api/supabaseClient';

export default function AddToPortfolioModal({ watchitem, realtimeData, onClose, onAdded }) {
  const [shares, setShares] = useState('');
  const [price, setPrice] = useState(realtimeData?.[`${watchitem.market}:${watchitem.ticker}`]?.price?.toString() || '');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const mdKey = `${watchitem.market}:${watchitem.ticker}`;
  const data = realtimeData?.[mdKey];
  const currency = data?.currency || watchitem.currency || 'SEK';
  const totalValue = shares && price ? (parseFloat(shares) * parseFloat(price)).toFixed(2) : '0';

  const handleSubmit = async () => {
    if (!shares || !price) {
      setError('Antal och pris måste fyllas i');
      return;
    }

    setSaving(true);
    setError('');
    try {
      const holding = await Trade.create({
        ticker: watchitem.ticker,
        company_name: watchitem.company_name,
        market: watchitem.market,
        sector: watchitem.sector || '',
        shares: parseFloat(shares),
        avg_price: parseFloat(price),
        currency,
      });
      onAdded?.(holding);
      onClose();
    } catch (err) {
      setError('Fel vid sparande: ' + err.message);
    }
    setSaving(false);
  };

  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      background: 'rgba(0,0,0,0.7)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000,
    }}>
      <div style={{
        background: '#0d1219',
        border: '1px solid #1e2d3d',
        borderRadius: 10,
        padding: 20,
        minWidth: 320,
        maxWidth: 400,
      }}>
        <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 14 }}>
          Lägg till {watchitem.ticker} i portföljen
        </div>

        <div style={{ marginBottom: 14 }}>
          <div style={{ fontFamily: 'monospace', fontSize: 10, color: '#5a7a94', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 1 }}>
            Antal aktier
          </div>
          <input
            type="number"
            placeholder="0"
            value={shares}
            onChange={e => setShares(e.target.value)}
            style={{
              width: '100%',
              padding: '8px 10px',
              background: '#131b24',
              border: '1px solid #253649',
              borderRadius: 6,
              color: '#dce8f5',
              fontSize: 12,
              outline: 'none',
              boxSizing: 'border-box',
            }}
          />
        </div>

        <div style={{ marginBottom: 14 }}>
          <div style={{ fontFamily: 'monospace', fontSize: 10, color: '#5a7a94', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 1 }}>
            Inköpspris ({currency})
          </div>
          <input
            type="number"
            placeholder="0"
            value={price}
            onChange={e => setPrice(e.target.value)}
            step="0.01"
            style={{
              width: '100%',
              padding: '8px 10px',
              background: '#131b24',
              border: '1px solid #253649',
              borderRadius: 6,
              color: '#dce8f5',
              fontSize: 12,
              outline: 'none',
              boxSizing: 'border-box',
            }}
          />
        </div>

        {shares && price && (
          <div style={{
            background: '#131b24',
            border: '1px solid #253649',
            borderRadius: 6,
            padding: 10,
            marginBottom: 14,
            fontFamily: 'monospace',
            fontSize: 11,
          }}>
            <div style={{ color: '#5a7a94', marginBottom: 3 }}>Totalt värde:</div>
            <div style={{ color: '#2ecc71', fontWeight: 700, fontSize: 13 }}>
              {totalValue} {currency}
            </div>
          </div>
        )}

        {error && (
          <div style={{
            background: 'rgba(231,76,60,0.1)',
            border: '1px solid rgba(231,76,60,0.3)',
            color: '#e74c3c',
            padding: 8,
            borderRadius: 4,
            fontSize: 11,
            marginBottom: 14,
          }}>
            {error}
          </div>
        )}

        <div style={{ display: 'flex', gap: 8 }}>
          <button
            onClick={onClose}
            disabled={saving}
            style={{
              flex: 1,
              background: 'transparent',
              border: '1px solid #253649',
              color: '#5a7a94',
              padding: '8px 14px',
              borderRadius: 6,
              cursor: saving ? 'not-allowed' : 'pointer',
              fontSize: 12,
              fontWeight: 700,
              opacity: saving ? 0.5 : 1,
            }}
          >
            Avbryt
          </button>
          <button
            onClick={handleSubmit}
            disabled={saving || !shares || !price}
            style={{
              flex: 1,
              background: '#2ecc71',
              border: 'none',
              color: '#080c10',
              padding: '8px 14px',
              borderRadius: 6,
              cursor: saving || !shares || !price ? 'not-allowed' : 'pointer',
              fontSize: 12,
              fontWeight: 700,
              opacity: saving || !shares || !price ? 0.5 : 1,
            }}
          >
            {saving ? '…' : 'Lägg till'}
          </button>
        </div>
      </div>
    </div>
  );
}