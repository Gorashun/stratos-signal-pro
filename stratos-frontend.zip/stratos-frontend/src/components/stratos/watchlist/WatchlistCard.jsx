import React, { useState } from 'react';
import { MARKETS } from '../instruments';
import AlertManager from './AlertManager';
import AddToPortfolioModal from './AddToPortfolioModal';
import { invokeFunction, Trade, Watchlist, Instrument } from '@/api/supabaseClient';

export default function WatchlistCard({ watchitem, realtimeData, alerts, onAlertsChange, onRemove, onUpdate, signals = [] }) {
  const [expanded, setExpanded] = useState(false);
  const [confirmRemove, setConfirmRemove] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editName, setEditName] = useState(watchitem.company_name || '');
  const [editCategory, setEditCategory] = useState(watchitem.category || '');
  const [showPortfolioModal, setShowPortfolioModal] = useState(false);
  const m = MARKETS[watchitem.market];
  const data = realtimeData[`${watchitem.market}:${watchitem.ticker}`];

  const changeColor = data?.change > 0 ? '#2ecc71' : data?.change < 0 ? '#e74c3c' : '#5a7a94';

  // Hitta aktiva signaler för denna aktie
  const activeSignals = signals.filter(
    s => s.ticker?.toUpperCase() === watchitem.ticker?.toUpperCase() && s.status === 'APPROVED'
  );
  const hasSignal = activeSignals.length > 0;
  const signalType = activeSignals[0]?.signal_type === 'SELL' ? 'SELL' : 'BUY';

  const handleSaveEdit = async () => {
    await Watchlist.update(watchitem.id, {
      company_name: editName,
      category: editCategory,
    });
    onUpdate && onUpdate(watchitem.id, { company_name: editName, category: editCategory });
    setEditing(false);
  };

  const handleRemove = () => {
    if (confirmRemove) {
      onRemove(watchitem.id);
    } else {
      setConfirmRemove(true);
      setTimeout(() => setConfirmRemove(false), 3000);
    }
  };

  // Remove handleAddToPortfolio - replaced by modal

  return (
    <div style={{
      background: '#0d1219',
      border: hasSignal
        ? `1px solid ${signalType === 'SELL' ? 'rgba(231,76,60,0.5)' : 'rgba(46,204,113,0.5)'}`
        : '1px solid #1e2d3d',
      borderRadius: 9,
      overflow: 'hidden',
      marginBottom: 10,
    }}>
      {/* Signal banner */}
      {hasSignal && (
        <div style={{
          background: signalType === 'SELL' ? 'rgba(231,76,60,0.12)' : 'rgba(46,204,113,0.12)',
          borderBottom: `1px solid ${signalType === 'SELL' ? 'rgba(231,76,60,0.3)' : 'rgba(46,204,113,0.3)'}`,
          padding: '5px 14px',
          display: 'flex',
          alignItems: 'center',
          gap: 10,
        }}>
          <span style={{ fontFamily: 'monospace', fontSize: 10, fontWeight: 800, color: signalType === 'SELL' ? '#e74c3c' : '#2ecc71' }}>
            ⚡ {signalType === 'SELL' ? 'SÄLJSIGNAL' : 'KÖPSIGNAL'} AKTIV
          </span>
          <span style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94' }}>
            {activeSignals[0]?.rule_name || activeSignals[0]?.rule} — Ingång: {activeSignals[0]?.entry?.toFixed(2)} | TP: {(activeSignals[0]?.tp || activeSignals[0]?.take_profit)?.toFixed(2)} | SL: {activeSignals[0]?.stop?.toFixed(2)}
          </span>
        </div>
      )}

      {/* Main row */}
      <div style={{
        padding: '12px 14px',
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        flexWrap: 'wrap',
      }}>
        {/* Ticker + bolag */}
        <div onClick={() => setExpanded(!expanded)} style={{ cursor: 'pointer', flex: '1 1 120px', minWidth: 100 }}>
          <div style={{ fontFamily: 'monospace', fontWeight: 700, fontSize: 14 }}>{watchitem.ticker}</div>
          <div style={{ fontSize: 10, color: '#5a7a94', marginTop: 2 }}>{watchitem.company_name}</div>
        </div>

        {/* Marknad */}
        <div onClick={() => setExpanded(!expanded)} style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', cursor: 'pointer', flex: '0 0 100px' }}>
          {m?.flag || '🌐'} {m?.label || watchitem.market}
        </div>

        {/* Kurs */}
        <div onClick={() => setExpanded(!expanded)} style={{ cursor: 'pointer', flex: '0 0 90px' }}>
          <div style={{ fontFamily: 'monospace', fontSize: 13, fontWeight: 700, color: data?.price ? '#dce8f5' : '#3d5a72' }}>
            {data?.price ? data.price.toFixed(2) : '—'}
          </div>
          <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#5a7a94', marginTop: 2 }}>
            {data?.price ? (data.currency || watchitem.currency || 'SEK') : 'Hämtar…'}
          </div>
        </div>

        {/* Förändring */}
        <div onClick={() => setExpanded(!expanded)} style={{ cursor: 'pointer', fontFamily: 'monospace', fontSize: 12, fontWeight: 700, color: changeColor, flex: '0 0 70px' }}>
          {data?.change != null ? `${data.change > 0 ? '+' : ''}${data.change.toFixed(2)}%` : '—'}
        </div>

        {/* Aviseringar + expand */}
        <div onClick={() => setExpanded(!expanded)} style={{ cursor: 'pointer', fontSize: 10, color: '#5a7a94', flex: '0 0 70px' }}>
          <div>{alerts.filter(a => a.ticker === watchitem.ticker && a.enabled).length} aviser.</div>
          <div style={{ fontSize: 9, color: '#3d5a72', marginTop: 2 }}>{expanded ? '▲ Stäng' : '▼ Mer'}</div>
        </div>

        {/* Lägg till + Redigera + Ta bort knappar */}
        <div style={{ display: 'flex', gap: 5, marginLeft: 'auto' }}>
          <button
            onClick={() => setShowPortfolioModal(true)}
            title="Lägg till i portföljinnehav"
            style={{
              background: 'rgba(46,204,113,0.07)',
              border: '1px solid rgba(46,204,113,0.2)',
              color: '#2ecc71',
              padding: '4px 10px',
              borderRadius: 5,
              cursor: 'pointer',
              fontSize: 11,
              fontWeight: 700,
            }}
          >▲</button>
          <button
            onClick={() => { setEditing(!editing); setExpanded(true); }}
            title="Redigera"
            style={{
              background: editing ? 'rgba(62,207,255,0.15)' : 'rgba(62,207,255,0.07)',
              border: `1px solid ${editing ? 'rgba(62,207,255,0.5)' : 'rgba(62,207,255,0.2)'}`,
              color: '#3ecfff',
              padding: '4px 10px',
              borderRadius: 5,
              cursor: 'pointer',
              fontSize: 11,
              fontWeight: 700,
            }}
          >✎</button>
          <button
            onClick={handleRemove}
            title="Ta bort från bevakningslista"
            style={{
              background: confirmRemove ? 'rgba(231,76,60,0.2)' : 'rgba(231,76,60,0.07)',
              border: `1px solid ${confirmRemove ? 'rgba(231,76,60,0.5)' : 'rgba(231,76,60,0.2)'}`,
              color: '#e74c3c',
              padding: '4px 10px',
              borderRadius: 5,
              cursor: 'pointer',
              fontSize: confirmRemove ? 10 : 12,
              fontWeight: 700,
              whiteSpace: 'nowrap',
              transition: 'all 0.2s',
            }}
          >
            {confirmRemove ? 'Säker?' : '✕'}
          </button>
        </div>
      </div>

      {/* Redigera-formulär */}
      {editing && (
        <div style={{ padding: '10px 14px', borderTop: '1px solid #1e2d3d', background: '#080c10', display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <input
            value={editName}
            onChange={e => setEditName(e.target.value)}
            placeholder="Bolagsnamn"
            style={{ flex: '2 1 160px', padding: '7px 10px', background: '#131b24', border: '1px solid #253649', borderRadius: 5, color: '#dce8f5', fontSize: 12, outline: 'none' }}
          />
          <input
            value={editCategory}
            onChange={e => setEditCategory(e.target.value)}
            placeholder="Kategori (t.ex. Egna picks)"
            style={{ flex: '1 1 140px', padding: '7px 10px', background: '#131b24', border: '1px solid #253649', borderRadius: 5, color: '#dce8f5', fontSize: 12, outline: 'none' }}
          />
          <button onClick={handleSaveEdit} style={{ background: '#3ecfff', color: '#080c10', border: 'none', padding: '7px 14px', borderRadius: 5, cursor: 'pointer', fontWeight: 700, fontSize: 12 }}>Spara</button>
          <button onClick={() => setEditing(false)} style={{ background: 'transparent', color: '#5a7a94', border: '1px solid #253649', padding: '7px 12px', borderRadius: 5, cursor: 'pointer', fontSize: 12 }}>Avbryt</button>
        </div>
      )}

      {/* Expanded section */}
      {expanded && (
        <div style={{ padding: '12px 14px', borderTop: '1px solid #1e2d3d', background: '#080c10' }}>

          {/* Signal-detaljer om aktiv */}
          {hasSignal && (
            <div style={{ background: signalType === 'SELL' ? 'rgba(231,76,60,0.07)' : 'rgba(46,204,113,0.07)', border: `1px solid ${signalType === 'SELL' ? 'rgba(231,76,60,0.2)' : 'rgba(46,204,113,0.2)'}`, borderRadius: 7, padding: '10px 14px', marginBottom: 14 }}>
              <div style={{ fontFamily: 'monospace', fontSize: 9, letterSpacing: 1.5, color: signalType === 'SELL' ? '#e74c3c' : '#2ecc71', textTransform: 'uppercase', marginBottom: 8 }}>
                ⚡ Aktiv signal — {signalType === 'SELL' ? 'Sälj' : 'Köp'}
              </div>
              <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap' }}>
                {[
                  { label: 'Ingång', value: activeSignals[0]?.entry?.toFixed(2), color: '#dce8f5' },
                  { label: 'Stop', value: activeSignals[0]?.stop?.toFixed(2), color: '#e74c3c' },
                  { label: 'Mål (TP)', value: (activeSignals[0]?.tp || activeSignals[0]?.take_profit)?.toFixed(2), color: '#2ecc71' },
                  { label: 'RSI', value: activeSignals[0]?.rsi?.toFixed(1), color: '#f1c40f' },
                  { label: 'Regel', value: activeSignals[0]?.rule_name || '—', color: '#3ecfff' },
                ].map(item => (
                  <div key={item.label}>
                    <div style={{ fontFamily: 'monospace', fontSize: 8, color: '#3d5a72', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 3 }}>{item.label}</div>
                    <div style={{ fontFamily: 'monospace', fontSize: 12, fontWeight: 700, color: item.color }}>{item.value || '—'}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Kursinfo */}
          <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap', marginBottom: 14 }}>
            {[
              { label: 'Kurs', value: data?.price?.toFixed(2), color: '#dce8f5' },
              { label: 'Förändring', value: data?.change != null ? `${data.change > 0 ? '+' : ''}${data.change.toFixed(2)}%` : null, color: changeColor },
              { label: 'Öppning/Stängning', value: data?.previous_close?.toFixed(2), color: '#90aabf' },
              { label: 'Högst idag', value: data?.high?.toFixed(2), color: '#2ecc71' },
              { label: 'Lägst idag', value: data?.low?.toFixed(2), color: '#e74c3c' },
            ].map(item => (
              <div key={item.label}>
                <div style={{ fontFamily: 'monospace', fontSize: 8, color: '#3d5a72', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 3 }}>{item.label}</div>
                <div style={{ fontFamily: 'monospace', fontSize: 13, fontWeight: 700, color: item.color || '#dce8f5' }}>{item.value || '—'}</div>
              </div>
            ))}
          </div>

          {/* Utlösta aviseringar */}
          {alerts.filter(a => a.ticker === watchitem.ticker && a.triggered).length > 0 && (
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#2ecc71', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 6 }}>✓ Utlösta aviseringar</div>
              {alerts.filter(a => a.ticker === watchitem.ticker && a.triggered).map(alert => (
                <div key={alert.id} style={{ background: '#131b24', padding: '6px 10px', borderRadius: 4, border: '1px solid rgba(46,204,113,0.2)', marginBottom: 4, fontFamily: 'monospace', fontSize: 10, color: '#2ecc71' }}>
                  {alert.alert_type === 'price_above' ? '▲' : '▼'} {alert.target_price.toFixed(2)} — utlöst @ {alert.triggered_price?.toFixed(2)}
                </div>
              ))}
            </div>
          )}

          <AlertManager
            ticker={watchitem.ticker}
            company_name={watchitem.company_name}
            market={watchitem.market}
            currency={watchitem.currency || 'SEK'}
            alerts={alerts}
            onAlertsChange={onAlertsChange}
          />
        </div>
      )}

      {showPortfolioModal && (
        <AddToPortfolioModal
          watchitem={watchitem}
          realtimeData={realtimeData}
          onClose={() => setShowPortfolioModal(false)}
          onAdded={() => setShowPortfolioModal(false)}
        />
      )}
    </div>
  );
}