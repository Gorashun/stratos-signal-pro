import React, { useState } from 'react';
import { Watchlist } from '@/api/supabaseClient';

export default function AlertManager({ watchlistId, ticker, company_name, market, currency = 'SEK', alertAbove, alertBelow, onUpdate }) {
  const [showForm, setShowForm] = useState(false);
  const [above, setAbove] = useState(alertAbove || '');
  const [below, setBelow] = useState(alertBelow || '');
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!watchlistId) return;
    setSaving(true);
    try {
      await Watchlist.update(watchlistId, {
        alert_above: above ? parseFloat(above) : null,
        alert_below: below ? parseFloat(below) : null,
      });
      onUpdate?.({ alert_above: above ? parseFloat(above) : null, alert_below: below ? parseFloat(below) : null });
      setShowForm(false);
    } catch (e) {
      console.error('Kunde inte spara avisering:', e);
    }
    setSaving(false);
  };

  const hasAlerts = alertAbove || alertBelow;

  return (
    <div style={{ background: '#131b24', border: '1px solid #1e2d3d', borderRadius: 8, padding: 12 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: hasAlerts ? 8 : 0 }}>
        <span style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94' }}>Prisaviseringar</span>
        <button onClick={() => setShowForm(f => !f)} style={{ fontFamily: 'monospace', fontSize: 10, color: '#3ecfff', background: 'transparent', border: 'none', cursor: 'pointer' }}>
          {showForm ? '✕ Stäng' : '+ Sätt avisering'}
        </button>
      </div>

      {hasAlerts && !showForm && (
        <div style={{ fontFamily: 'monospace', fontSize: 10, color: '#dce8f5', lineHeight: 1.8 }}>
          {alertAbove && <div>↑ Över: <span style={{ color: '#2ecc71' }}>{alertAbove} {currency}</span></div>}
          {alertBelow && <div>↓ Under: <span style={{ color: '#e74c3c' }}>{alertBelow} {currency}</span></div>}
        </div>
      )}

      {showForm && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 8 }}>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <span style={{ fontFamily: 'monospace', fontSize: 10, color: '#5a7a94', width: 60 }}>Över:</span>
            <input type="number" value={above} onChange={e => setAbove(e.target.value)} placeholder="pris"
              style={{ flex: 1, padding: '4px 8px', background: '#080c10', border: '1px solid #253649', borderRadius: 4, color: '#dce8f5', fontSize: 11, fontFamily: 'monospace', outline: 'none' }} />
            <span style={{ fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>{currency}</span>
          </div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <span style={{ fontFamily: 'monospace', fontSize: 10, color: '#5a7a94', width: 60 }}>Under:</span>
            <input type="number" value={below} onChange={e => setBelow(e.target.value)} placeholder="pris"
              style={{ flex: 1, padding: '4px 8px', background: '#080c10', border: '1px solid #253649', borderRadius: 4, color: '#dce8f5', fontSize: 11, fontFamily: 'monospace', outline: 'none' }} />
            <span style={{ fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>{currency}</span>
          </div>
          <button onClick={save} disabled={saving}
            style={{ background: '#3ecfff', color: '#080c10', border: 'none', borderRadius: 4, padding: '5px 12px', fontFamily: 'monospace', fontSize: 11, fontWeight: 700, cursor: 'pointer' }}>
            {saving ? 'Sparar…' : 'Spara'}
          </button>
        </div>
      )}
    </div>
  );
}
