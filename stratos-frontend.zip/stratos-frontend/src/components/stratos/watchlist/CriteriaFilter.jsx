import React, { useState } from 'react';

const SECTORS = ['Teknik', 'Finans', 'Hälsovård', 'Industrivaror', 'Konsument', 'Energi', 'Fastigheter', 'Material', 'Kommunikation', 'Transport'];
const MARKET_CAP = ['Mega (>1T)', 'Stor (100B-1T)', 'Mellan (10B-100B)', 'Liten (<10B)'];
const DIVIDEND_GROWTH = ['Hög (>10%)', 'Medel (5-10%)', 'Låg (<5%)', 'Ingen utdelning'];
const GROWTH_PROFILE = ['Aggressiv tillväxt', 'Balanserad', 'Defensiv/Utdelning'];
const RISK_LEVELS = ['Låg risk', 'Medel risk', 'Hög risk'];
const TECHNICAL_PREF = ['Starkt momentum', 'Trendföljning', 'Reversering/Bottnar', 'Breakout'];

export default function CriteriaFilter({ onCriteriaChange }) {
  const [expanded, setExpanded] = useState(false);
  const [marketCap, setMarketCap] = useState('');
  const [dividendGrowth, setDividendGrowth] = useState('');
  const [selectedSectors, setSelectedSectors] = useState([]);
  const [minYield, setMinYield] = useState('');
  const [growth, setGrowth] = useState('');
  const [maxPE, setMaxPE] = useState('');
  const [minRevenueGrowth, setMinRevenueGrowth] = useState('');
  const [riskLevel, setRiskLevel] = useState('');
  const [technicalPref, setTechnicalPref] = useState('');
  const [lowDebt, setLowDebt] = useState(false);

  const handleApply = () => {
    const criteria = {
      marketCap: marketCap || undefined,
      dividendGrowth: dividendGrowth || undefined,
      sectors: selectedSectors.length > 0 ? selectedSectors : undefined,
      minYield: minYield ? parseFloat(minYield) : undefined,
      growth: growth || undefined,
      maxPE: maxPE ? parseFloat(maxPE) : undefined,
      minRevenueGrowth: minRevenueGrowth ? parseFloat(minRevenueGrowth) : undefined,
      riskLevel: riskLevel || undefined,
      technicalPref: technicalPref || undefined,
      lowDebt: lowDebt || undefined,
    };
    onCriteriaChange(criteria);
    setExpanded(false);
  };

  const handleReset = () => {
    setMarketCap(''); setDividendGrowth(''); setSelectedSectors([]);
    setMinYield(''); setGrowth(''); setMaxPE(''); setMinRevenueGrowth('');
    setRiskLevel(''); setTechnicalPref(''); setLowDebt(false);
    onCriteriaChange({});
  };

  const activeCount = [marketCap, dividendGrowth, minYield, growth, maxPE, minRevenueGrowth, riskLevel, technicalPref]
    .filter(Boolean).length + selectedSectors.length + (lowDebt ? 1 : 0);

  const selectStyle = {
    width: '100%', padding: '8px 10px', background: '#131b24', border: '1px solid #253649',
    borderRadius: 6, color: '#dce8f5', fontSize: 12, outline: 'none',
  };
  const labelStyle = {
    fontFamily: 'monospace', fontSize: 10, color: '#3d5a72',
    textTransform: 'uppercase', display: 'block', marginBottom: 6,
  };
  const inputStyle = {
    width: '100%', padding: '8px 10px', background: '#131b24', border: '1px solid #253649',
    borderRadius: 6, color: '#dce8f5', fontSize: 12, outline: 'none',
  };

  return (
    <div style={{ marginBottom: 16 }}>
      <button
        onClick={() => setExpanded(!expanded)}
        style={{
          display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px',
          background: expanded ? 'rgba(62,207,255,0.1)' : '#131b24',
          border: expanded ? '1px solid rgba(62,207,255,0.3)' : '1px solid #253649',
          borderRadius: 7, color: expanded ? '#3ecfff' : '#90aabf', cursor: 'pointer',
          fontWeight: 700, fontSize: 12, fontFamily: 'monospace', width: '100%',
        }}
      >
        <span>⚙️ Avancerade kriterier</span>
        {activeCount > 0 && (
          <span style={{ background: 'rgba(241,196,15,0.15)', color: '#f1c40f', padding: '1px 8px', borderRadius: 4, fontSize: 10 }}>
            {activeCount} aktiva
          </span>
        )}
        <span style={{ marginLeft: 'auto', fontSize: 10, opacity: 0.5 }}>{expanded ? '▲' : '▼'}</span>
      </button>

      {expanded && (
        <div style={{
          marginTop: 8, padding: 16, background: '#0d1219', border: '1px solid #1e2d3d',
          borderRadius: 7, display: 'flex', flexDirection: 'column', gap: 14,
        }}>
          {/* Row 1: Market cap + Growth profile */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <div>
              <label style={labelStyle}>Marknadsvärde</label>
              <select value={marketCap} onChange={e => setMarketCap(e.target.value)} style={selectStyle}>
                <option value="">-- Alla --</option>
                {MARKET_CAP.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
            <div>
              <label style={labelStyle}>Tillväxtprofil</label>
              <select value={growth} onChange={e => setGrowth(e.target.value)} style={selectStyle}>
                <option value="">-- Alla --</option>
                {GROWTH_PROFILE.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          </div>

          {/* Row 2: PE + Revenue growth */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <div>
              <label style={labelStyle}>Max P/E-tal</label>
              <input
                type="number" min="0" step="1" placeholder="T.ex. 25"
                value={maxPE} onChange={e => setMaxPE(e.target.value)} style={inputStyle}
              />
            </div>
            <div>
              <label style={labelStyle}>Min omsättningstillväxt (%/år)</label>
              <input
                type="number" min="0" step="1" placeholder="T.ex. 10"
                value={minRevenueGrowth} onChange={e => setMinRevenueGrowth(e.target.value)} style={inputStyle}
              />
            </div>
          </div>

          {/* Row 3: Dividend */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <div>
              <label style={labelStyle}>Utdelningstillväxt</label>
              <select value={dividendGrowth} onChange={e => setDividendGrowth(e.target.value)} style={selectStyle}>
                <option value="">-- Alla --</option>
                {DIVIDEND_GROWTH.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
            <div>
              <label style={labelStyle}>Min utdelningsavkastning (%)</label>
              <input
                type="number" min="0" step="0.5" max="20" placeholder="T.ex. 3"
                value={minYield} onChange={e => setMinYield(e.target.value)} style={inputStyle}
              />
            </div>
          </div>

          {/* Row 4: Risk + Technical preference */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <div>
              <label style={labelStyle}>Risknivå</label>
              <select value={riskLevel} onChange={e => setRiskLevel(e.target.value)} style={selectStyle}>
                <option value="">-- Alla --</option>
                {RISK_LEVELS.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
            <div>
              <label style={labelStyle}>Teknisk preferens</label>
              <select value={technicalPref} onChange={e => setTechnicalPref(e.target.value)} style={selectStyle}>
                <option value="">-- Alla --</option>
                {TECHNICAL_PREF.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          </div>

          {/* Low debt toggle */}
          <div>
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
              <div
                onClick={() => setLowDebt(!lowDebt)}
                style={{
                  width: 36, height: 20, borderRadius: 10, position: 'relative', cursor: 'pointer',
                  background: lowDebt ? 'rgba(62,207,255,0.3)' : '#253649',
                  border: lowDebt ? '1px solid #3ecfff' : '1px solid #3d5a72',
                  transition: 'all 0.2s',
                }}
              >
                <div style={{
                  position: 'absolute', top: 2, left: lowDebt ? 16 : 2,
                  width: 14, height: 14, borderRadius: '50%',
                  background: lowDebt ? '#3ecfff' : '#5a7a94',
                  transition: 'left 0.2s',
                }} />
              </div>
              <span style={{ fontFamily: 'monospace', fontSize: 11, color: lowDebt ? '#3ecfff' : '#90aabf' }}>
                Prioritera lågt skuldsatta bolag
              </span>
            </label>
          </div>

          {/* Sectors */}
          <div>
            <label style={labelStyle}>Branscher (välj flera)</label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              {SECTORS.map(sector => (
                <button
                  key={sector}
                  onClick={() => setSelectedSectors(prev =>
                    prev.includes(sector) ? prev.filter(s => s !== sector) : [...prev, sector]
                  )}
                  style={{
                    padding: '5px 11px', borderRadius: 4, border: '1px solid',
                    background: selectedSectors.includes(sector) ? 'rgba(62,207,255,0.15)' : 'transparent',
                    borderColor: selectedSectors.includes(sector) ? '#3ecfff' : '#253649',
                    color: selectedSectors.includes(sector) ? '#3ecfff' : '#90aabf',
                    cursor: 'pointer', fontSize: 11, fontWeight: 600,
                  }}
                >
                  {selectedSectors.includes(sector) ? '✓ ' : ''}{sector}
                </button>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', borderTop: '1px solid #1e2d3d', paddingTop: 12 }}>
            <button onClick={handleReset} style={{
              padding: '8px 14px', borderRadius: 6, border: '1px solid #253649',
              background: 'transparent', color: '#90aabf', cursor: 'pointer', fontSize: 11, fontWeight: 700,
            }}>Återställ</button>
            <button onClick={handleApply} style={{
              padding: '8px 18px', borderRadius: 6, border: 'none',
              background: '#3ecfff', color: '#080c10', cursor: 'pointer', fontSize: 11, fontWeight: 700,
            }}>Applicera filter</button>
          </div>
        </div>
      )}
    </div>
  );
}