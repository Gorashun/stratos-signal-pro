import React, { useState, useEffect } from 'react';
import { invokeFunction, Trade, Watchlist, Instrument, Signal } from '@/api/supabaseClient';
import { ALL_INSTRUMENTS, MARKETS, SEG_LABELS } from './instruments';
import SignalCard from './SignalCard';
import SignalDetailedAnalysis from './SignalDetailedAnalysis';
import WatchlistCard from './watchlist/WatchlistCard';
import CriteriaFilter from './watchlist/CriteriaFilter';

// Komponenten för att visa alla kort
function WatchlistCards({ watchlist, alerts, onRemove, onUpdate, onAlertsChange, marketData = {}, regime = 'neutral', signals = [] }) {
  const [realtimeData, setRealtimeData] = useState({});
  const [fetching, setFetching] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      if (watchlist.length === 0) return;
      setFetching(true);
      try {
        // Slå upp yahoo_symbol från Instrument-databasen för varje ticker
        const instruments = await Instrument.filter({}, '-created_date', 5000);
        const instrumentMap = {};
        for (const inst of instruments) {
          const key = `${inst.market}:${inst.ticker}`;
          instrumentMap[key] = { yahoo_symbol: inst.yahoo_symbol, currency: inst.currency };
        }

        const res = await invokeFunction('finnhubRealtimeData', {
          tickers: watchlist.map(w => ({
            ticker: w.ticker,
            market: w.market,
            company_name: w.company_name,
            yahoo_symbol: instrumentMap[`${w.market}:${w.ticker}`]?.yahoo_symbol || null,
          })),
        });

        const data = {};
        (res.data?.results || []).forEach(r => {
          if (r.ok) {
            const key = `${r.market}:${r.ticker}`;
            // Use instrument DB currency if available, otherwise guess from market
            const instCurrency = instrumentMap[`${r.market}:${r.ticker}`]?.currency;
            const currency = instCurrency || (r.market === 'sweden' ? 'SEK' : r.market === 'usa' ? 'USD' : r.market === 'uk' ? 'GBP' : 'EUR');
            data[key] = { ...r, currency };
          }
        });
        setRealtimeData(data);
      } catch (e) {
        console.error('Kunde inte hämta realtidsdata:', e);
      }
      setFetching(false);
    };

    fetchData();
    const interval = setInterval(fetchData, 5 * 60 * 1000); // Uppdatera var 5:e minut
    return () => clearInterval(interval);
  }, [watchlist]);

  return (
    <div>
      <div style={{ fontFamily: 'monospace', fontSize: 10, color: '#5a7a94', marginBottom: 12 }}>
        {fetching ? '⟳ Uppdaterar priser…' : '✓ Senast uppdaterad'}
      </div>
      {watchlist.map(w => {
        const mdKey = `${w.market}:${w.ticker}`;
        return (
          <div key={w.id}>
            <WatchlistCard
              watchitem={w}
              realtimeData={realtimeData}
              alerts={alerts}
              onAlertsChange={onAlertsChange}
              onRemove={onRemove}
              onUpdate={onUpdate}
              signals={signals}
            />
            {marketData && marketData[mdKey] && (
              <div style={{ paddingLeft: 14, paddingBottom: 8, borderBottom: '1px solid #1e2d3d' }}>
                <SignalDetailedAnalysis 
                  signal={{
                    ticker: w.ticker,
                    company_name: w.company_name,
                    market: w.market,
                    sector: w.sector,
                    signal_type: 'ANALYZE',
                    entry: realtimeData[mdKey]?.price,
                    status: 'APPROVED'
                  }}
                  marketData={marketData}
                  regime={regime}
                />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

const SEG_TAG_COLORS = {
  large: { bg: 'rgba(62,207,255,0.1)', color: '#3ecfff' },
  mid: { bg: 'rgba(155,89,182,0.12)', color: '#9b59b6' },
  small: { bg: 'rgba(241,196,15,0.1)', color: '#f1c40f' },
  fn: { bg: 'rgba(255,107,53,0.1)', color: '#ff6b35' },
};

export default function WatchlistPage({ activeMarkets, marketData, signals = [], regime = 'neutral' }) {
  const [watchlist, setWatchlist] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState([]);
  const [tab, setTab] = useState('list'); // 'list' | 'search' | 'ai'
  const [manualTicker, setManualTicker] = useState('');
  const [manualName, setManualName] = useState('');
  const [manualMarket, setManualMarket] = useState('sweden');
  const [manualCategory, setManualCategory] = useState('');
  const [criteria, setCriteria] = useState({});
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [addCategory, setAddCategory] = useState('');

  useEffect(() => {
    Promise.all([
      Watchlist.list(),
      
    ]).then(([watchlistData, alertsData]) => {
      setWatchlist(watchlistData);
      setAlerts(alertsData);
      setLoading(false);
    });
  }, []);

  // Search: DB-first, then Yahoo Finance live
  useEffect(() => {
    if (!searchQuery.trim()) { setSearchResults([]); return; }
    const q = searchQuery.toLowerCase();
    setSearchLoading(true);

    const timer = setTimeout(async () => {
      try {
        // Search Instrument DB
        const dbResults = await Instrument.filter({
          $or: [
            { ticker: { $regex: q, $options: 'i' } },
            { company_name: { $regex: q, $options: 'i' } },
          ]
        }, '-created_date', 50);

        const dbMapped = dbResults.map(r => ({
          t: r.ticker,
          n: r.company_name,
          market: r.market,
          seg: r.segment || '',
          s: r.sector || '',
          yahooSymbol: r.yahoo_symbol,
          isDb: true,
        }));

        // Live search fallback for new/unlisted
        let liveResults = [];
        try {
          const liveRes = await invokeFunction('searchTicker', { query: searchQuery });
          liveResults = (liveRes.data?.results || []).map(r => ({
            t: r.symbol,
            n: r.longName || r.shortName,
            market: r.market,
            seg: '',
            s: '',
            yahooSymbol: r.symbol,
            isLive: true,
          }));
        } catch {}

        // Merge: DB takes priority
        const seen = new Set(dbMapped.map(d => d.yahooSymbol || d.t));
        const merged = [...dbMapped];
        for (const r of liveResults) {
          const key = r.yahooSymbol || r.t;
          if (!seen.has(key)) { seen.add(key); merged.push(r); }
        }
        setSearchResults(merged.slice(0, 50));
      } catch (e) {
        console.error('Sökning misslyckades:', e);
      }
      setSearchLoading(false);
    }, 400);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const isInWatchlist = (ticker, market) => watchlist.some(w => w.ticker === ticker && w.market === market);

  // Sparar instrument i databasen om det inte finns där sedan tidigare
  const ensureInstrumentInDb = async (inst) => {
    const yahooSymbol = inst.yahooSymbol || inst.t;
    // Kolla om det redan finns i DB
    const existing = await Instrument.filter({ yahoo_symbol: yahooSymbol }, '-created_date', 1);
    if (existing.length === 0) {
      await Instrument.create({
        ticker: inst.t,
        yahoo_symbol: yahooSymbol,
        company_name: inst.n || inst.t,
        market: inst.market || 'unknown',
        segment: inst.seg || '',
        sector: inst.s || '',
        currency: inst.market === 'sweden' ? 'SEK' : inst.market === 'usa' ? 'USD' : 'EUR',
      });
    }
  };

  const addToWatchlist = async (inst, category = '') => {
    const ticker = inst.t;
    const market = inst.market || 'unknown';
    if (isInWatchlist(ticker, market)) return;
    await ensureInstrumentInDb(inst);
    const record = await Watchlist.create({
      ticker,
      company_name: inst.n,
      market,
      segment: inst.seg || '',
      sector: inst.s || '',
      category: category || addCategory || '',
    });
    setWatchlist(prev => [...prev, record]);
  };

  const addManual = async () => {
    if (!manualTicker.trim()) return;
    const ticker = manualTicker.trim().toUpperCase();
    if (isInWatchlist(ticker, manualMarket)) return;
    const yahooSymbol = manualMarket === 'sweden' && !ticker.includes('.') ? ticker + '.ST' : ticker;
    const inst = { t: ticker, n: manualName.trim() || ticker, market: manualMarket, yahooSymbol, seg: '', s: '' };
    await ensureInstrumentInDb(inst);
    const record = await Watchlist.create({
      ticker,
      company_name: manualName.trim() || ticker,
      market: manualMarket,
      segment: '',
      sector: '',
      category: manualCategory.trim() || '',
    });
    setWatchlist(prev => [...prev, record]);
    setManualTicker('');
    setManualName('');
    setManualCategory('');
  };

  const removeFromWatchlist = async (id) => {
    await Watchlist.delete(id);
    setWatchlist(prev => prev.filter(w => w.id !== id));
  };

  const updateWatchlistItem = (id, changes) => {
    setWatchlist(prev => prev.map(w => w.id === id ? { ...w, ...changes } : w));
  };

  const runAI = async () => {
    if (!aiPrompt.trim()) return;
    setAiLoading(true);
    setAiSuggestions([]);
    const res = await invokeFunction('aiWatchlistSuggestions', {
      prompt: aiPrompt,
      activeMarkets,
      criteria,
    });
    setAiSuggestions(res.data?.suggestions || []);
    setAiLoading(false);
  };

  const addAiSuggestion = async (s) => {
    const inst = ALL_INSTRUMENTS.find(i => i.t === s.ticker || i.yahooSymbol === s.ticker) || {
      t: s.ticker,
      n: s.company_name || s.name,
      market: s.market || 'unknown',
      yahooSymbol: s.ticker,
      seg: s.segment || '',
      s: s.sector || '',
    };
    await ensureInstrumentInDb(inst);
    const record = await Watchlist.create({
      ticker: s.ticker,
      company_name: s.company_name || s.name,
      market: inst.market,
      segment: inst.seg || '',
      sector: inst.s || '',
    });
    setWatchlist(prev => [...prev, record]);
  };

  const tabStyle = (id) => ({
    padding: '7px 16px', borderRadius: 5, cursor: 'pointer', fontSize: 12, fontWeight: 600,
    border: tab === id ? '1px solid rgba(62,207,255,0.3)' : '1px solid #253649',
    background: tab === id ? 'rgba(62,207,255,0.07)' : 'transparent',
    color: tab === id ? '#3ecfff' : '#5a7a94',
  });

  return (
    <div style={{ padding: 24 }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20 }}>
        <div>
          <div style={{ fontSize: 22, fontWeight: 800 }}>Bevakningslista</div>
          <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', marginTop: 3 }}>
            {watchlist.length} aktier bevakade
          </div>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          <button style={tabStyle('list')} onClick={() => setTab('list')}>★ Min lista</button>
          <button style={tabStyle('search')} onClick={() => setTab('search')}>🔍 Sök</button>
          <button style={tabStyle('ai')} onClick={() => setTab('ai')}>✦ AI-förslag</button>
        </div>
      </div>

      {/* MY LIST */}
      {tab === 'list' && (
        <div>
          {!loading && watchlist.length > 0 && (() => {
            const categories = ['all', ...Array.from(new Set(watchlist.map(w => w.category).filter(Boolean)))];
            const filtered = categoryFilter === 'all' ? watchlist : watchlist.filter(w => w.category === categoryFilter);
            return (
              <>
                {categories.length > 1 && (
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 14 }}>
                    {categories.map(c => (
                      <button key={c} onClick={() => setCategoryFilter(c)} style={{
                        padding: '5px 12px', borderRadius: 5, cursor: 'pointer', fontSize: 11, fontWeight: 600,
                        border: categoryFilter === c ? '1px solid rgba(62,207,255,0.4)' : '1px solid #253649',
                        background: categoryFilter === c ? 'rgba(62,207,255,0.08)' : 'transparent',
                        color: categoryFilter === c ? '#3ecfff' : '#5a7a94',
                      }}>{c === 'all' ? `Alla (${watchlist.length})` : `${c} (${watchlist.filter(w => w.category === c).length})`}</button>
                    ))}
                  </div>
                )}
                <WatchlistCards 
                  watchlist={filtered} 
                  alerts={alerts} 
                  onRemove={removeFromWatchlist}
                  onUpdate={updateWatchlistItem}
                  onAlertsChange={setAlerts}
                  marketData={marketData}
                  regime={regime}
                  signals={signals}
                />
              </>
            );
          })()}
          {!loading && watchlist.length === 0 && (
            <div style={{ textAlign: 'center', padding: 60, color: '#3d5a72', fontFamily: 'monospace', fontSize: 13 }}>
              Inga aktier än — använd Sök eller AI-förslag för att lägga till
            </div>
          )}
          {loading && (
            <div style={{ textAlign: 'center', padding: 40, color: '#5a7a94', fontFamily: 'monospace' }}>Laddar…</div>
          )}
        </div>
      )}

      {/* SEARCH */}
      {tab === 'search' && (
        <div>
          <div style={{ position: 'relative', marginBottom: 14 }}>
            <input
              type="text"
              placeholder="Sök ticker eller bolagsnamn (t.ex. NIBE, Volvo, AAPL)…"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              style={{
                width: '100%', padding: '10px 14px', background: '#0d1219', border: '1px solid #253649',
                borderRadius: 7, color: '#dce8f5', fontSize: 13, outline: 'none',
              }}
            />
            {searchLoading && (
              <span style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', fontFamily: 'monospace', fontSize: 10, color: '#3ecfff' }}>söker…</span>
            )}
          </div>

          {searchResults.length > 0 && (
            <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, overflow: 'hidden', marginBottom: 18 }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ background: '#131b24' }}>
                    {['Ticker', 'Bolag', 'Marknad', 'Källa', ''].map(h => (
                      <th key={h} style={{ padding: '9px 13px', textAlign: 'left', fontFamily: 'monospace', fontSize: 9, letterSpacing: 1.5, color: '#3d5a72', textTransform: 'uppercase', borderBottom: '1px solid #1e2d3d' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {searchResults.map((inst, i) => {
                    const m = MARKETS[inst.market];
                    const segStyle = SEG_TAG_COLORS[inst.seg] || {};
                    const inList = isInWatchlist(inst.t, inst.market);
                    return (
                      <tr key={i} style={{ borderBottom: '1px solid rgba(30,45,61,0.5)' }}>
                        <td style={{ padding: '10px 13px', fontFamily: 'monospace', fontWeight: 700, fontSize: 13 }}>{inst.t}</td>
                        <td style={{ padding: '10px 13px', fontSize: 12, color: '#dce8f5' }}>{inst.n}</td>
                        <td style={{ padding: '10px 13px', fontFamily: 'monospace', fontSize: 11, color: '#5a7a94' }}>{m?.flag || '🌐'} {m?.label || inst.market}</td>
                        <td style={{ padding: '10px 13px' }}>
                          {inst.isLive ? (
                            <span style={{ fontFamily: 'monospace', fontSize: 9, color: '#f1c40f' }}>⚡ Live</span>
                          ) : (
                            <span style={{ fontFamily: 'monospace', fontSize: 9, padding: '2px 6px', borderRadius: 3, textTransform: 'uppercase', background: segStyle.bg || 'rgba(62,207,255,0.1)', color: segStyle.color || '#3ecfff' }}>
                              {SEG_LABELS[inst.seg] || 'Databas'}
                            </span>
                          )}
                        </td>
                        <td style={{ padding: '10px 13px' }}>
                          <button onClick={() => addToWatchlist(inst)} disabled={inList} style={{
                            background: inList ? 'rgba(46,204,113,0.08)' : 'rgba(62,207,255,0.08)',
                            border: inList ? '1px solid rgba(46,204,113,0.2)' : '1px solid rgba(62,207,255,0.2)',
                            color: inList ? '#2ecc71' : '#3ecfff',
                            padding: '3px 10px', borderRadius: 4, cursor: inList ? 'default' : 'pointer', fontSize: 11, fontWeight: 700,
                          }}>{inList ? '✓ Lagd' : '+ Lägg till'}</button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {/* Manual add */}
          <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, padding: 16 }}>
            <div style={{ fontFamily: 'monospace', fontSize: 10, letterSpacing: 1.5, color: '#3d5a72', textTransform: 'uppercase', marginBottom: 10 }}>
              ➕ Lägg till aktie manuellt
            </div>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <input
                type="text"
                placeholder="Ticker (t.ex. NIBE-B)"
                value={manualTicker}
                onChange={e => setManualTicker(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addManual()}
                style={{ flex: '1 1 120px', padding: '8px 12px', background: '#131b24', border: '1px solid #253649', borderRadius: 6, color: '#dce8f5', fontSize: 12, outline: 'none' }}
              />
              <input
                type="text"
                placeholder="Bolagsnamn (valfritt)"
                value={manualName}
                onChange={e => setManualName(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addManual()}
                style={{ flex: '2 1 180px', padding: '8px 12px', background: '#131b24', border: '1px solid #253649', borderRadius: 6, color: '#dce8f5', fontSize: 12, outline: 'none' }}
              />
              <select
                value={manualMarket}
                onChange={e => setManualMarket(e.target.value)}
                style={{ flex: '1 1 110px', padding: '8px 10px', background: '#131b24', border: '1px solid #253649', borderRadius: 6, color: '#dce8f5', fontSize: 12, outline: 'none' }}
              >
                {Object.values(MARKETS).map(m => (
                  <option key={m.id} value={m.id}>{m.flag} {m.label}</option>
                ))}
              </select>
              <input
                type="text"
                placeholder="Kategori (t.ex. Egna picks)"
                value={manualCategory}
                onChange={e => setManualCategory(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addManual()}
                style={{ flex: '1 1 140px', padding: '8px 12px', background: '#131b24', border: '1px solid #253649', borderRadius: 6, color: '#dce8f5', fontSize: 12, outline: 'none' }}
              />
              <button onClick={addManual} disabled={!manualTicker.trim()} style={{
                background: '#3ecfff', color: '#080c10', border: 'none', padding: '8px 16px',
                borderRadius: 6, cursor: 'pointer', fontWeight: 700, fontSize: 12, opacity: !manualTicker.trim() ? 0.5 : 1,
              }}>Lägg till</button>
            </div>
            <div style={{ fontFamily: 'monospace', fontSize: 10, color: '#3d5a72', marginTop: 8 }}>
              Svenska aktier: använd Nasdaq Stockholm-ticker (t.ex. NIBE-B, VOLV-B). Yahoo hämtar kurser automatiskt.
            </div>
          </div>

          {searchQuery && searchResults.length === 0 && !searchLoading && (
            <div style={{ textAlign: 'center', padding: 30, color: '#3d5a72', fontFamily: 'monospace', fontSize: 12 }}>Inga träffar för "{searchQuery}" — lägg till manuellt nedan</div>
          )}
        </div>
      )}

      {/* AI SUGGESTIONS */}
      {tab === 'ai' && (
        <div>
          <CriteriaFilter onCriteriaChange={setCriteria} />
          
          <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
            <input
              type="text"
              placeholder='T.ex. "Teknikbolag med hög tillväxt" eller "Defensiva utdelningsaktier"'
              value={aiPrompt}
              onChange={e => setAiPrompt(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && runAI()}
              style={{
                flex: 1, padding: '10px 14px', background: '#0d1219', border: '1px solid #253649',
                borderRadius: 7, color: '#dce8f5', fontSize: 13, outline: 'none',
              }}
            />
            <button onClick={runAI} disabled={aiLoading || !aiPrompt.trim()} style={{
              background: '#3ecfff', color: '#080c10', border: 'none', padding: '10px 20px',
              borderRadius: 7, cursor: aiLoading ? 'not-allowed' : 'pointer', fontWeight: 700, fontSize: 12,
              opacity: aiLoading ? 0.6 : 1,
            }}>
              {aiLoading ? '…' : '✦ Generera'}
            </button>
          </div>

          {aiSuggestions.length > 0 && (
            <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ background: '#131b24' }}>
                    {['Ticker', 'Bolag', 'Motivering', ''].map(h => (
                      <th key={h} style={{ padding: '9px 13px', textAlign: 'left', fontFamily: 'monospace', fontSize: 9, letterSpacing: 1.5, color: '#3d5a72', textTransform: 'uppercase', borderBottom: '1px solid #1e2d3d' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {aiSuggestions.map((s, i) => {
                    const inList = isInWatchlist(s.ticker, s.market);
                    return (
                      <tr key={i} style={{ borderBottom: '1px solid rgba(30,45,61,0.5)' }}>
                        <td style={{ padding: '10px 13px', fontFamily: 'monospace', fontWeight: 700, fontSize: 13 }}>{s.ticker}</td>
                        <td style={{ padding: '10px 13px', fontSize: 12, color: '#dce8f5', whiteSpace: 'nowrap' }}>{s.company_name || s.name}</td>
                        <td style={{ padding: '10px 13px', fontSize: 11, color: '#5a7a94', maxWidth: 300 }}>
                          <div>{s.reason}</div>
                          {(s.dividend_yield || s.pe_ratio) && (
                            <div style={{ fontSize: 10, color: '#3d5a72', marginTop: 4, fontFamily: 'monospace' }}>
                              {s.dividend_yield && <span>Dividend: {s.dividend_yield} </span>}
                              {s.pe_ratio && <span>P/E: {s.pe_ratio}</span>}
                            </div>
                          )}
                        </td>
                        <td style={{ padding: '10px 13px' }}>
                          <button onClick={() => addAiSuggestion(s)} disabled={inList} style={{
                            background: inList ? 'rgba(46,204,113,0.08)' : 'rgba(62,207,255,0.08)',
                            border: inList ? '1px solid rgba(46,204,113,0.2)' : '1px solid rgba(62,207,255,0.2)',
                            color: inList ? '#2ecc71' : '#3ecfff',
                            padding: '3px 10px', borderRadius: 4, cursor: inList ? 'default' : 'pointer', fontSize: 11, fontWeight: 700,
                          }}>{inList ? '✓ Lagd' : '+ Lägg till'}</button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}