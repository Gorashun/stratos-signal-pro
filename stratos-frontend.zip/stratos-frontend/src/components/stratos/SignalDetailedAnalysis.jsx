import React, { useState, useEffect } from 'react';
import { invokeFunction, Trade, Watchlist, Instrument } from '@/api/supabaseClient';

const RiskSeverityColor = { 'Låg': '#2ecc71', 'Medel': '#f1c40f', 'Hög': '#e74c3c' };

export default function SignalDetailedAnalysis({ signal, marketData, regime }) {
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const fetchAnalysis = async () => {
    if (analysis) return; // Already loaded
    setLoading(true);
    try {
      const res = await invokeFunction('analyzeSignalDetailed', {
        signal,
        marketData,
        regime
      });
      setAnalysis(res.data?.analysis);
    } catch (e) {
      console.error('Kunde inte ladda detaljerad analys:', e);
    }
    setLoading(false);
  };

  useEffect(() => {
    if (expanded && !analysis && !loading) {
      fetchAnalysis();
    }
  }, [expanded]);

  return (
    <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, marginTop: 12, overflow: 'hidden' }}>
      {/* Toggle button */}
      <button
        onClick={() => setExpanded(!expanded)}
        style={{
          width: '100%',
          background: 'transparent',
          border: 'none',
          color: '#3ecfff',
          padding: '12px 14px',
          textAlign: 'left',
          cursor: 'pointer',
          fontSize: 13,
          fontWeight: 700,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          borderBottom: expanded ? '1px solid #1e2d3d' : 'none',
        }}
      >
        <span>✦ Djupgående AI-analys</span>
        <span style={{ fontSize: 11 }}>{expanded ? '▲' : '▼'}</span>
      </button>

      {/* Expanded content */}
      {expanded && (
        <div style={{ padding: '14px 16px', background: '#080c10' }}>
          {loading ? (
            <div style={{ textAlign: 'center', color: '#5a7a94', fontFamily: 'monospace', fontSize: 12, padding: 20 }}>
              ⏳ Analyserar signal…
            </div>
          ) : analysis ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {/* Why chosen */}
              {analysis.why_chosen && (
                <div>
                  <div style={{ fontFamily: 'monospace', fontSize: 10, letterSpacing: 1, color: '#3ecfff', textTransform: 'uppercase', marginBottom: 8 }}>
                    🎯 Varför denna aktie
                  </div>
                  <div style={{ fontSize: 12, color: '#dce8f5', lineHeight: 1.6 }}>{analysis.why_chosen}</div>
                </div>
              )}

              {/* Risks */}
              {analysis.risks && analysis.risks.length > 0 && (
                <div>
                  <div style={{ fontFamily: 'monospace', fontSize: 10, letterSpacing: 1, color: '#e74c3c', textTransform: 'uppercase', marginBottom: 8 }}>
                    ⚠️ Risker
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                    {analysis.risks.map((risk, i) => (
                      <div key={i} style={{ background: '#131b24', border: `1px solid ${RiskSeverityColor[risk.severity]}33`, borderLeft: `3px solid ${RiskSeverityColor[risk.severity]}`, borderRadius: 6, padding: 10 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                          <span style={{ fontFamily: 'monospace', fontSize: 9, padding: '2px 7px', borderRadius: 4, background: `${RiskSeverityColor[risk.severity]}22`, color: RiskSeverityColor[risk.severity], fontWeight: 700 }}>
                            {risk.severity}
                          </span>
                          <span style={{ fontSize: 12, fontWeight: 700, color: '#dce8f5' }}>{risk.risk}</span>
                        </div>
                        <div style={{ fontSize: 11, color: '#5a7a94', marginTop: 6 }}>Mitigation: {risk.mitigation}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Opportunities */}
              {analysis.opportunities && analysis.opportunities.length > 0 && (
                <div>
                  <div style={{ fontFamily: 'monospace', fontSize: 10, letterSpacing: 1, color: '#2ecc71', textTransform: 'uppercase', marginBottom: 8 }}>
                    💡 Möjligheter
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                    {analysis.opportunities.map((opp, i) => (
                      <div key={i} style={{ background: '#131b24', border: '1px solid rgba(46,204,113,0.2)', borderRadius: 6, padding: 10 }}>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
                          <span style={{ fontSize: 12, fontWeight: 700, color: '#dce8f5' }}>{opp.opportunity}</span>
                          <span style={{ fontFamily: 'monospace', fontSize: 12, fontWeight: 700, color: '#2ecc71' }}>+{opp.potential_upside_pct?.toFixed(1)}%</span>
                        </div>
                        <div style={{ fontSize: 10, color: '#5a7a94' }}>Tidshorisont: {opp.timeframe}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Sector Analysis */}
              {analysis.sector_analysis && (
                <div>
                  <div style={{ fontFamily: 'monospace', fontSize: 10, letterSpacing: 1, color: '#3ecfff', textTransform: 'uppercase', marginBottom: 8 }}>
                    📊 Sektoranalys
                  </div>
                  <div style={{ fontSize: 12, color: '#dce8f5', lineHeight: 1.6, background: '#131b24', padding: 12, borderRadius: 6 }}>
                    {analysis.sector_analysis}
                  </div>
                </div>
              )}

              {/* Recommended Levels */}
              {analysis.recommended_levels && (
                <div>
                  <div style={{ fontFamily: 'monospace', fontSize: 10, letterSpacing: 1, color: '#f1c40f', textTransform: 'uppercase', marginBottom: 8 }}>
                    📍 Rekommenderade nivåer
                  </div>
                  <div style={{ background: '#131b24', border: '1px solid #1e2d3d', borderRadius: 6, overflow: 'hidden' }}>
                    {[
                      { label: 'Entry', value: analysis.recommended_levels.entry, color: '#3ecfff' },
                      { label: 'Stop Loss', value: analysis.recommended_levels.stop_loss, color: '#e74c3c' },
                      { label: 'TP 1 (25%)', value: analysis.recommended_levels.take_profit_1?.level, color: '#2ecc71' },
                      { label: 'TP 2 (50%)', value: analysis.recommended_levels.take_profit_2?.level, color: '#2ecc71' },
                      { label: 'TP 3 (25%)', value: analysis.recommended_levels.take_profit_3?.level, color: '#2ecc71' },
                    ].map((level, i) => (
                      <div key={i} style={{
                        padding: '10px 14px',
                        borderBottom: i < 4 ? '1px solid #1e2d3d' : 'none',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center'
                      }}>
                        <span style={{ fontSize: 11, color: '#5a7a94' }}>{level.label}</span>
                        <span style={{ fontFamily: 'monospace', fontSize: 12, fontWeight: 700, color: level.color }}>
                          {level.value?.toFixed(2) || '—'}
                        </span>
                      </div>
                    ))}
                  </div>
                  {analysis.recommended_levels.motivation && (
                    <div style={{ fontSize: 10, color: '#5a7a94', marginTop: 8 }}>
                      Motivering: {analysis.recommended_levels.motivation}
                    </div>
                  )}
                </div>
              )}

              {/* Risk Profile */}
              {analysis.risk_profile && (
                <div>
                  <div style={{ fontFamily: 'monospace', fontSize: 10, letterSpacing: 1, color: '#9b59b6', textTransform: 'uppercase', marginBottom: 8 }}>
                    🎯 Riskprofil
                  </div>
                  <div style={{
                    background: analysis.risk_profile === 'Låg risk' ? 'rgba(46,204,113,0.1)' :
                      analysis.risk_profile === 'Medel risk' ? 'rgba(241,196,15,0.1)' :
                      'rgba(231,76,60,0.1)',
                    border: `1px solid ${analysis.risk_profile === 'Låg risk' ? 'rgba(46,204,113,0.3)' :
                      analysis.risk_profile === 'Medel risk' ? 'rgba(241,196,15,0.3)' :
                      'rgba(231,76,60,0.3)'}`,
                    borderRadius: 6,
                    padding: 12
                  }}>
                    <div style={{
                      fontFamily: 'monospace',
                      fontSize: 13,
                      fontWeight: 700,
                      color: analysis.risk_profile === 'Låg risk' ? '#2ecc71' :
                        analysis.risk_profile === 'Medel risk' ? '#f1c40f' :
                        '#e74c3c',
                      marginBottom: 6
                    }}>
                      {analysis.risk_profile}
                    </div>
                    <div style={{ fontSize: 11, color: '#dce8f5' }}>{analysis.risk_profile_reason}</div>
                  </div>
                </div>
              )}

              {/* Conclusion */}
              {analysis.conclusion && (
                <div>
                  <div style={{ fontFamily: 'monospace', fontSize: 10, letterSpacing: 1, color: '#3ecfff', textTransform: 'uppercase', marginBottom: 8 }}>
                    ✓ Slutsats
                  </div>
                  <div style={{ fontSize: 12, color: '#dce8f5', lineHeight: 1.6 }}>{analysis.conclusion}</div>
                </div>
              )}

              {/* Action plan */}
              {analysis.action_plan && (
                <div style={{ background: '#131b24', border: '1px solid rgba(62,207,255,0.2)', borderRadius: 6, padding: 12 }}>
                  <div style={{ fontFamily: 'monospace', fontSize: 10, letterSpacing: 1, color: '#3ecfff', textTransform: 'uppercase', marginBottom: 6 }}>
                    📋 Nästa steg
                  </div>
                  <div style={{ fontSize: 11, color: '#dce8f5' }}>{analysis.action_plan}</div>
                </div>
              )}
            </div>
          ) : (
            <div style={{ textAlign: 'center', color: '#5a7a94', fontFamily: 'monospace', fontSize: 11, padding: 15 }}>
              Kunde inte ladda analys
            </div>
          )}
        </div>
      )}
    </div>
  );
}