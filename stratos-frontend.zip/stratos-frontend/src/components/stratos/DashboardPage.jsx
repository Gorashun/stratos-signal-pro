import React, { useEffect, useState } from 'react';
import { invokeFunction, Trade, Watchlist, Instrument, Signal } from '@/api/supabaseClient';
import { MARKETS } from './instruments';

export default function DashboardPage({ marketData, signals, regime, fetchData }) {
  const [watchlist, setWatchlist] = useState([]);

  useEffect(() => {
    // Load watchlist
    Watchlist.list().then(setWatchlist).catch(err => console.error('Failed to load watchlist:', err));
    
    // Subscribe to watchlist updates
    const unsub = Watchlist.subscribe((event) => {
      Watchlist.list().then(setWatchlist);
    });
    
    return unsub;
  }, []);

  // Auto-fetch market data on mount
  useEffect(() => {
    if (Object.keys(marketData).length === 0) {
      fetchData();
    }
  }, []);

  const approvedSignals = signals.filter(s => s.status === 'APPROVED').slice(0, 10);
  const dataCount = Object.keys(marketData).length;
  const regimeColor = regime === 'bull' ? '#2ecc71' : regime === 'bear' ? '#e74c3c' : '#f1c40f';

  // Market overview sorted by signal status
  const marketOverview = Object.values(marketData).sort((a, b) => {
    const aHasSignal = signals.some(s => s.ticker === a.t && s.status === 'APPROVED');
    const bHasSignal = signals.some(s => s.ticker === b.t && s.status === 'APPROVED');
    return (bHasSignal ? 1 : 0) - (aHasSignal ? 1 : 0);
  }).slice(0, 20);

  return (
    <div style={{ padding: 24 }}>
      {/* Top stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 20 }}>
        <StatCard label="Signaler aktiva" value={approvedSignals.length} color="#3ecfff" />
        <StatCard label="Aktier laddade" value={dataCount} color="#2ecc71" />
        <StatCard label="Marknadsläge" value={regime === 'bull' ? 'Tjur' : regime === 'bear' ? 'Björn' : 'Neutral'} color={regimeColor} sub={regime === 'bull' ? 'Uppåttrend' : regime === 'bear' ? 'Nedåttrend' : 'Osäker'} />
      </div>

      {/* Market Overview - Full data with signals */}
      {dataCount > 0 && (
        <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, overflow: 'hidden', marginBottom: 20 }}>
          <div style={{ padding: '13px 16px', borderBottom: '1px solid #1e2d3d', background: '#131b24' }}>
            <div style={{ fontWeight: 700, fontSize: 13 }}>Marknadsöversikt ({dataCount})</div>
          </div>
          <div style={{ maxHeight: 450, overflowY: 'auto' }}>
            <table style={{ width: '100%' }}>
              <thead>
                <tr style={{ background: '#131b24', position: 'sticky', top: 0 }}>
                  <th style={{ padding: '9px 13px', textAlign: 'left', fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>Ticker</th>
                  <th style={{ padding: '9px 13px', textAlign: 'left', fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>Bolag</th>
                  <th style={{ padding: '9px 13px', textAlign: 'center', fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>Kurs</th>
                  <th style={{ padding: '9px 13px', textAlign: 'center', fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>P/E</th>
                  <th style={{ padding: '9px 13px', textAlign: 'center', fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>Div %</th>
                  <th style={{ padding: '9px 13px', textAlign: 'center', fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>Signal</th>
                </tr>
              </thead>
              <tbody>
                {marketOverview.map(d => {
                  const sig = signals.find(s => s.ticker === d.t && s.status === 'APPROVED');
                  const m = MARKETS[d.market];
                  return (
                    <tr key={`${d.market}:${d.t}`} style={{ borderBottom: '1px solid rgba(30,45,61,0.5)', background: sig ? 'rgba(46,204,113,0.05)' : 'transparent' }}>
                      <td style={{ padding: '10px 13px', fontFamily: 'monospace', fontWeight: 700, color: sig ? '#2ecc71' : '#dce8f5' }}>{d.t} {sig && '⭐'}</td>
                      <td style={{ padding: '10px 13px', fontSize: 11, color: '#dce8f5', maxWidth: 150, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d.n}</td>
                      <td style={{ padding: '10px 13px', fontFamily: 'monospace', fontSize: 12, color: '#2ecc71', textAlign: 'center' }}>{d.price?.toFixed(2)}</td>
                      <td style={{ padding: '10px 13px', fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', textAlign: 'center' }}>{d.pe_ratio ? d.pe_ratio.toFixed(1) : '—'}</td>
                      <td style={{ padding: '10px 13px', fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', textAlign: 'center' }}>{d.dividend_yield ? d.dividend_yield.toFixed(2) + '%' : '—'}</td>
                      <td style={{ padding: '10px 13px', textAlign: 'center', color: sig ? '#2ecc71' : '#3d5a72' }}>
                        {sig ? <span style={{ fontFamily: 'monospace', fontSize: 10, fontWeight: 700 }}>↑ {sig.signal_type || 'KÖP'}</span> : '—'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Watchlist - Full width */}
      <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, overflow: 'hidden', marginBottom: 20 }}>
        <div style={{ padding: '13px 16px', borderBottom: '1px solid #1e2d3d', background: '#131b24' }}>
          <div style={{ fontWeight: 700, fontSize: 13 }}>Bevakningar ({watchlist.length})</div>
        </div>
        <div style={{ maxHeight: 350, overflowY: 'auto' }}>
          {watchlist.length === 0 ? (
            <div style={{ padding: 24, textAlign: 'center', color: '#5a7a94', fontSize: 12 }}>Ingen bevakningar</div>
          ) : (
            <table style={{ width: '100%' }}>
              <thead>
                <tr style={{ background: '#131b24' }}>
                  <th style={{ padding: '9px 13px', textAlign: 'left', fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>Ticker</th>
                  <th style={{ padding: '9px 13px', textAlign: 'left', fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>Bolag</th>
                  <th style={{ padding: '9px 13px', textAlign: 'center', fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>Marknad</th>
                  <th style={{ padding: '9px 13px', textAlign: 'right', fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>Kurs</th>
                  <th style={{ padding: '9px 13px', textAlign: 'right', fontFamily: 'monospace', fontSize: 10, color: '#5a7a94' }}>P/E</th>
                </tr>
              </thead>
              <tbody>
                {watchlist.slice(0, 15).map(w => {
                  const md = marketData[`${w.market}:${w.ticker}`];
                  const m = MARKETS[w.market];
                  return (
                    <tr key={`${w.market}:${w.ticker}`} style={{ borderBottom: '1px solid rgba(30,45,61,0.5)' }}>
                      <td style={{ padding: '10px 13px', fontFamily: 'monospace', fontWeight: 700 }}>{w.ticker}</td>
                      <td style={{ padding: '10px 13px', fontSize: 11, color: '#dce8f5', maxWidth: 140, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{w.company_name}</td>
                      <td style={{ padding: '10px 13px', textAlign: 'center', fontSize: 11, color: '#5a7a94' }}>{m?.flag}</td>
                      <td style={{ padding: '10px 13px', fontFamily: 'monospace', fontSize: 12, color: md?.price ? '#2ecc71' : '#3d5a72', textAlign: 'right' }}>
                        {md?.price ? md.price.toFixed(2) : '—'}
                      </td>
                      <td style={{ padding: '10px 13px', fontFamily: 'monospace', fontSize: 11, color: '#5a7a94', textAlign: 'right' }}>
                        {md?.pe_ratio ? md.pe_ratio.toFixed(1) : '—'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Active Signals */}
      <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, overflow: 'hidden' }}>
        <div style={{ padding: '13px 16px', borderBottom: '1px solid #1e2d3d', background: '#131b24' }}>
          <div style={{ fontWeight: 700, fontSize: 13 }}>Aktiva signaler</div>
        </div>
        <div style={{ maxHeight: 400, overflowY: 'auto' }}>
          {approvedSignals.length === 0 ? (
            <div style={{ padding: 24, textAlign: 'center', color: '#5a7a94' }}>Inga signaler</div>
          ) : (
            <table style={{ width: '100%' }}>
              <tbody>
                {approvedSignals.map((sig, i) => {
                  const m = MARKETS[sig.market];
                  return (
                    <tr key={i} style={{ borderBottom: '1px solid rgba(30,45,61,0.5)' }}>
                      <td style={{ padding: '11px 13px' }}>
                        <div style={{ fontFamily: 'monospace', fontWeight: 700, fontSize: 12 }}>{sig.ticker}</div>
                        <div style={{ fontSize: 10, color: '#5a7a94' }}>{m?.flag} {sig.rule_name || 'Signal'}</div>
                      </td>
                      <td style={{ padding: '11px 13px', fontFamily: 'monospace', fontSize: 11 }}>
                        Entry: <span style={{ color: '#2ecc71' }}>{sig.entry?.toFixed(2)}</span>
                      </td>
                      <td style={{ padding: '11px 13px', fontFamily: 'monospace', fontSize: 11 }}>
                        Stop: <span style={{ color: '#e74c3c' }}>{sig.stop?.toFixed(2)}</span>
                      </td>
                      <td style={{ padding: '11px 13px', fontFamily: 'monospace', fontSize: 11, textAlign: 'right' }}>
                        TP: <span style={{ color: '#f1c40f' }}>{sig.take_profit?.toFixed(2)}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, color, sub }) {
  return (
    <div style={{ background: '#0d1219', border: '1px solid #1e2d3d', borderRadius: 9, padding: '13px 16px', position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 1, background: color }} />
      <div style={{ fontFamily: 'monospace', fontSize: 10, color: '#5a7a94', textTransform: 'uppercase', marginBottom: 6 }}>{label}</div>
      <div style={{ fontSize: 28, fontWeight: 800, color }}>{value}</div>
      {sub && <div style={{ fontFamily: 'monospace', fontSize: 10, color: '#5a7a94', marginTop: 3 }}>{sub}</div>}
    </div>
  );
}